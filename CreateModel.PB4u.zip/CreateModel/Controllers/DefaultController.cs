﻿using CreateModel.UserModel;
using GGDTO.Contract;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CreateModel.Controllers
{
    public class DefaultController : Controller
    {
        // GET: Default
        public ActionResult Index()
        {
            umModel objModel = new umModel();
            objModel = HelpDbTables.GetModelDtl();
            ViewBag.ReturnVal = 0;
            return View(objModel);
        }

        [HttpPost]
        public ActionResult Index(umModel objModel)
        {
            LogErrorToLogFile objLog = new LogErrorToLogFile();

            objLog.DbModel(objModel);
            ViewBag.ReturnVal = 1;
            ViewBag.FileName = objModel.ClassName + ".cs";
            objModel = new umModel();
            objModel = HelpDbTables.GetModelDtl();
            return View(objModel);
        }

        public ActionResult SpParameter()
        {
            umModel objModel = new umModel();
            objModel = HelpDbTables.GetParameterDtl();
            ViewBag.ReturnVal = 0;
            return View(objModel);
        }

        [HttpPost]
        public ActionResult SpParameter(umModel objModel)
        {
            LogErrorToLogFile objLog = new LogErrorToLogFile();

            objLog.DbParameter(objModel);
            ViewBag.ReturnVal = 1;
            ViewBag.FileName = objModel.ClassName + ".cs";
            objModel = new umModel();
            objModel = HelpDbTables.GetModelDtl();
            return View(objModel);
        }
    }
}