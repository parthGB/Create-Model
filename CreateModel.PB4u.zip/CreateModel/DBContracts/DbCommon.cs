﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GGDTO.DBContracts
{
    public class DbCommon
    {
        SqlHelper objSqlHelper = new SqlHelper();
        private bool getSqlObjectInfo(string SqlObjectName_1, ref DataTable dtTbl_Retu, ref string eStr_Retu)
        {
            bool functionReturnValue = false;
            string qStr = "";

            try
            {
                SqlObjectName_1 = "'" + SqlObjectName_1.ToUpper() + "'";

                qStr = "Select SysColumns.Name as ColName, SysColumns.Colid as ColIndex, " +
                    "       Type_Name(SysColumns.xType) as ColDbType, " +
                    "       ColumnProperty(SysColumns.id, SysColumns.Name,'IsOutParam') as IsOutPut, " +
                    "       ColumnProperty(SysColumns.id, SysColumns.Name,'IsIdentity') as IsAutoId, " +
                    "       SysColumns.Length " + " From SysColumns " +
                    " Where SysColumns.Id= Object_Id(" + SqlObjectName_1 + ")" + " " +
                    " Order by SysColumns.Colid";

                dtTbl_Retu = objSqlHelper.ExecuteQuery_DataSet(qStr).Tables[0];
                functionReturnValue = true;

            }
            catch (Exception Ex)
            {
                functionReturnValue = false;
                eStr_Retu = Ex.Message;
            }
            return functionReturnValue;
        }

        public bool SaveInDb(string ProcedureName_1, DataTable tbl4Save, Int16 Choice_1, ref ArrayList ProcedureOutPutVal_Retu, ref string eStr_Retu)
        {
            bool functionReturnValue = false;

            DataTable tbl_ProcDtl = null;
            System.Data.SqlClient.SqlParameter SqlPara = null;
            ParameterReturnValue ParaRetuVal = new ParameterReturnValue();
            SqlCommand sqlCmd = null;
            ArrayList ParaRowArr = null;
            string Proc_ColName = "";
            int ColIndex_1 = -1;

            try
            {
                if (objSqlHelper.Connection1 == null)
                {
                    objSqlHelper.SetConnection();
                }

                ProcedureOutPutVal_Retu = new ArrayList();
                eStr_Retu = "";

                if (ProcedureName_1.Trim().Length == 0)
                {
                    eStr_Retu = "Procedure Name Is Invalid or Blank";
                    return functionReturnValue;
                }

                if (!getSqlObjectInfo(ProcedureName_1, ref tbl_ProcDtl, ref eStr_Retu))
                {
                    eStr_Retu += " " + "Error Occured While Retrieving Procedure Info.";
                    return functionReturnValue;
                }

                if (tbl_ProcDtl.Rows.Count == 0)
                {
                    eStr_Retu = "No Procedure Information is found for procedure = " + ProcedureName_1;
                    return functionReturnValue;
                }

                //AS PER DISCUSSION WITH GUNJAN BHAI

                //'viraj
                //If tbl4Save.Rows.Count = 0 Then
                //    eStr_Retu = "No data in table = "
                //    Exit Function
                //End If

                objSqlHelper.InOpenConnection(false);
                objSqlHelper.Begin_Transaction();

                foreach (DataRow dr_Save in tbl4Save.Rows)
                {
                    sqlCmd = new SqlCommand(ProcedureName_1, objSqlHelper.Connection1, objSqlHelper.Transaction);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    ParaRowArr = new ArrayList();

                    foreach (DataRow dr_P in tbl_ProcDtl.Rows)
                    {
                        Proc_ColName = dr_P["COLNAME"].ToString().Substring(1).ToUpper();
                        ColIndex_1 = Convert.ToInt32(dr_P["COLINDEX"]) - 1;

                        SqlPara = new SqlParameter();
                        SqlPara.ParameterName = dr_P["COLNAME"].ToString();
                        SqlPara.Direction = ParameterDirection.Input;


                        if (Proc_ColName == "DATAOPMODE")
                        {
                            //-- Change by Gunjan Gandhi as on 14/04/08
                            //
                            SqlPara.Value = dr_Save["DATAOPMODE"];
                            //Convert.ToInt32(Choice_1)

                            // when column is not output parameter
                        }
                        else if (Convert.ToInt32(dr_P["ISOUTPUT"]) == 0)
                        {

                            SqlPara.Value = dr_Save[Proc_ColName];

                            // when column is output parameter
                        }
                        else if (Convert.ToInt32(dr_P["ISOUTPUT"]) == 1)
                        {

                            SqlPara.Direction = ParameterDirection.Output;
                            SqlPara.Size = Convert.ToInt32(dr_P["LENGTH"]);

                            ParaRetuVal = new ParameterReturnValue();
                            ParaRetuVal.ParameterName = dr_P["COLNAME"].ToString();
                            ParaRetuVal.ParameterIndex = ColIndex_1;
                            ParaRowArr.Add(ParaRetuVal);

                        }

                        sqlCmd.Parameters.Add(SqlPara);

                    }

                    sqlCmd.ExecuteNonQuery();

                    ParaRetuVal.ParameterValue = (ParaRetuVal.ParameterName.Length == 0 ? "" : sqlCmd.Parameters[ParaRetuVal.ParameterName].Value.ToString());  //((System.Data.SqlClient.SqlParameter)(().Items[10])).Value;

                    ProcedureOutPutVal_Retu.Add(ParaRetuVal.ParameterValue);


                }
                objSqlHelper.Commit_Transaction();
                objSqlHelper.InCloseConnection(false);
                functionReturnValue = true;

            }
            catch (Exception ex)
            {
                objSqlHelper.RollBack_Transaction();
                functionReturnValue = false;
                ProcedureOutPutVal_Retu = null;
                eStr_Retu = ex.Message;
                return functionReturnValue;
            }
            return functionReturnValue;

        }

    }
}
