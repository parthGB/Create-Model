namespace UserModels.SPParameter 
{
  using System;
  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpSelectAmalgamationFee
      public class SpSelectAmalgamationFee
      {
         public string SPName = "SpSelectAmalgamationFee";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpSelectWaterDrainagePlanApplicationQueryDetails
      public class SpSelectWaterDrainagePlanApplicationQueryDetails
      {
         public string SPName = "SpSelectWaterDrainagePlanApplicationQueryDetails";
         public int ApplicationFormId = 0;
         public int ActionId = 1;
         public int ApplicationTypeId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectGeneralApplicationForLeaseByReferenceno
      public class SPSelectGeneralApplicationForLeaseByReferenceno
      {
         public string SPName = "SPSelectGeneralApplicationForLeaseByReferenceno";
         public int ReferenceNo = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectBuildingPlanApprovalDWG
      public class SPSelectBuildingPlanApprovalDWG
      {
         public string SPName = "SPSelectBuildingPlanApprovalDWG";
         public int DWGId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetPendingDayAtGIDCendForBuildingPlanApproval
      public class SPGetPendingDayAtGIDCendForBuildingPlanApproval
      {
         public string SPName = "SPGetPendingDayAtGIDCendForBuildingPlanApproval";
         public int ReferenceNo = 0;
         public int Days = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateDrainageApplication
      public class SPInsertUpdateDrainageApplication
      {
         public string SPName = "SPInsertUpdateDrainageApplication";
         public int ApplicationFormId = 0;
         public int ApplicationId = 1;
         public int ReferenceNo = 2;
         public int CreatedBy = 3;
         public int IsActive = 4;
         public int Operation = 5;
         public int SEZ = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPAODashboard
      public class SPAODashboard
      {
         public string SPName = "SPAODashboard";
         public int ApplicationId = 0;
         public int RegionId = 1;
         public int EstateId = 2;
         public int FromDate = 3;
         public int ToDate = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDEEEmailIdForReplyQueryForBuildingPlanApproval
      public class SPSelectDEEEmailIdForReplyQueryForBuildingPlanApproval
      {
         public string SPName = "SPSelectDEEEmailIdForReplyQueryForBuildingPlanApproval";
         public int EStateId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDRAINAGEDETAILSREPORTFOOTER
      public class SPDRAINAGEDETAILSREPORTFOOTER
      {
         public string SPName = "SPDRAINAGEDETAILSREPORTFOOTER";
         public int StatusId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGet2RModulePendingWithApplicant
      public class SPGet2RModulePendingWithApplicant
      {
         public string SPName = "SPGet2RModulePendingWithApplicant";
         public int RegionId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetStatusByReferenceNo
      public class SPGetStatusByReferenceNo
      {
         public string SPName = "SPGetStatusByReferenceNo";
         public int ReferenceNo = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTwoRTransactionForSameUnit01092016Report
      public class SPSelectTwoRTransactionForSameUnit01092016Report
      {
         public string SPName = "SPSelectTwoRTransactionForSameUnit01092016Report";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectROUModuleInvoiceByHeader
      public class SPSelectROUModuleInvoiceByHeader
      {
         public string SPName = "SPSelectROUModuleInvoiceByHeader";
         public int ApplicationFormId = 0;
         public int TxId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateBuildingplanApprovalApplicationForMailReminder04102016
      public class SPUpdateBuildingplanApprovalApplicationForMailReminder04102016
      {
         public string SPName = "SPUpdateBuildingplanApprovalApplicationForMailReminder04102016";
         public int ApplicationFormId = 0;
         public int IsPreemptiveReminderSend = 1;
         public int PreemptiveFormate = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubLettingModuleByApplicationFormIdForView02022017
      public class SPSelectSubLettingModuleByApplicationFormIdForView02022017
      {
         public string SPName = "SPSelectSubLettingModuleByApplicationFormIdForView02022017";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpSelectWaterDrainagePlanQueryApplicationType
      public class SpSelectWaterDrainagePlanQueryApplicationType
      {
         public string SPName = "SpSelectWaterDrainagePlanQueryApplicationType";
         public int UserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTwoRTransactionForSameUnit17032017
      public class SPSelectTwoRTransactionForSameUnit17032017
      {
         public string SPName = "SPSelectTwoRTransactionForSameUnit17032017";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpSaveDrainageReleaseConnectionDetails
      public class SpSaveDrainageReleaseConnectionDetails
      {
         public string SPName = "SpSaveDrainageReleaseConnectionDetails";
         public int ApplicationFormId = 0;
         public int InspectionDatetime = 1;
         public int ReleaseConnectionDocList = 2;
         public int OnlineFeesSubmissionReceiptAthmt = 3;
         public int SignedAgreementDocumentAthmt = 4;
         public int OtherDocumentsAthmt = 5;
         public int ApplicantReleaseRemarks = 6;
         public int UserId = 7;
         public int ActionId = 8;
         public int MeterNo = 9;
         public int MeterMake = 10;
         public int InitialReading = 11;
         public int TestReportAttached = 12;
         public int TOCMake = 13;
         public int pHMeter = 14;
         public int AutomationSystemReturn = 15;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubdivisionNOCReport
      public class SPSelectSubdivisionNOCReport
      {
         public string SPName = "SPSelectSubdivisionNOCReport";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPHelpdeskDeshboard
      public class SPHelpdeskDeshboard
      {
         public string SPName = "SPHelpdeskDeshboard";
         public int ApplicationId = 0;
         public int RegionId = 1;
         public int EstateId = 2;
         public int FromDate = 3;
         public int ToDate = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDEEEPBmailIdForReplyQueryForBuildingPlanApproval
      public class SPSelectDEEEPBmailIdForReplyQueryForBuildingPlanApproval
      {
         public string SPName = "SPSelectDEEEPBmailIdForReplyQueryForBuildingPlanApproval";
         public int EStateId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPWATERSUPPLYDETAILSREPORTFOOTER
      public class SPWATERSUPPLYDETAILSREPORTFOOTER
      {
         public string SPName = "SPWATERSUPPLYDETAILSREPORTFOOTER";
         public int StatusId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectEstatePriceForROUApplicationFormId
      public class SPSelectEstatePriceForROUApplicationFormId
      {
         public string SPName = "SPSelectEstatePriceForROUApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectROUModuleInvoice
      public class SPSelectROUModuleInvoice
      {
         public string SPName = "SPSelectROUModuleInvoice";
         public int ApplicationFormId = 0;
         public int UserId = 1;
         public int TxId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPaymentDetailsAmalgamationForTxId
      public class SPSelectPaymentDetailsAmalgamationForTxId
      {
         public string SPName = "SPSelectPaymentDetailsAmalgamationForTxId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectApplicantUserMasterByEmailId
      public class SPSelectApplicantUserMasterByEmailId
      {
         public string SPName = "SPSelectApplicantUserMasterByEmailId";
         public int EmailId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateGeneralApplicationForIFPPortalAsync
      public class SPUpdateGeneralApplicationForIFPPortalAsync
      {
         public string SPName = "SPUpdateGeneralApplicationForIFPPortalAsync";
         public int IFPApplicationId = 0;
         public int IsIFP_Sync = 1;
         public int ApplicationId = 2;
         public int ReferenceNo = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateSublettingDACalculation
      public class SPInsertUpdateSublettingDACalculation
      {
         public string SPName = "SPInsertUpdateSublettingDACalculation";
         public int Mode = 0;
         public int ApplicationFormId = 1;
         public int userId = 2;
         public int IsCommercialPlot = 3;
         public int SublettingArea = 4;
         public int PremiumPrice = 5;
         public int SublettingPercentage = 6;
         public int SublettingYear = 7;
         public int SublettingDAFees = 8;
         public int SublettingDAfeesSGST = 9;
         public int SublettingDAfeesCGST = 10;
         public int TotalPaybleAmount = 11;
         public int SL_ACCHEAD_C = 12;
         public int SL_ACC_M = 13;
         public int SL_FROM_D = 14;
         public int SL_TO_D = 15;
         public int SL_ACC_NO = 16;
         public int SL_SGST_A = 17;
         public int SL_CGST_A = 18;
         public int SL_ACC_N = 19;
         public int IsAgreeDA = 20;
         public int RemarksDA = 21;
         public int IsAgreeAM = 22;
         public int RemarksAM = 23;
         public int IsAgreeRM = 24;
         public int RemarksRM = 25;
         public int IsAgreeDM = 26;
         public int RemarksDM = 27;
         public int IsAgreeVCMD = 28;
         public int RemarksVCMD = 29;
         public int IsSubmitted = 30;
         public int AccountDues = 31;
         public int WaterDues = 32;
         public int OtherDues = 33;
         public int DrainageDues = 34;
         public int OSINST_A = 35;
         public int OSIDPPI_A = 36;
         public int OSSC_A = 37;
         public int OSSC_ST = 38;
         public int OSSC_EC = 39;
         public int OSSWCSC = 40;
         public int OSSCKKC = 41;
         public int OSNAA_A = 42;
         public int OSNAA_ST = 43;
         public int OSNAA_EC = 44;
         public int OSSWCNAA = 45;
         public int OSNAAKKC = 46;
         public int OSLR_A = 47;
         public int OSLR_ST = 48;
         public int OSLR_EC = 49;
         public int OSSWCLR = 50;
         public int OSLRKKC = 51;
         public int OSIR_A = 52;
         public int OSIUF_A = 53;
         public int OSIUF_ST = 54;
         public int OSIUF_EC = 55;
         public int OSFULLPAYMENT_A = 56;
         public int LRCOSINST_A = 57;
         public int LRCOSIDP_A = 58;
         public int EN_ACCHEAD_C = 59;
         public int EN_ACC_M = 60;
         public int EN_FROM_D = 61;
         public int EN_TO_D = 62;
         public int EN_ACC_NO = 63;
         public int EN_SGST_A = 64;
         public int EN_CGST_A = 65;
         public int EN_ACC_N = 66;
         public int EN_SGSTAmount = 67;
         public int EN_CGSTAmount = 68;
         public int EN_BaseAmount = 69;
         public int SC_ACCHEAD_C = 70;
         public int SC_ACC_M = 71;
         public int SC_FROM_D = 72;
         public int SC_TO_D = 73;
         public int SC_ACC_NO = 74;
         public int SC_SGST_A = 75;
         public int SC_CGST_A = 76;
         public int SC_ACC_N = 77;
         public int SC_SGSTAmount = 78;
         public int SC_CGSTAmount = 79;
         public int SC_BaseAmount = 80;
         public int NAA_ACCHEAD_C = 81;
         public int NAA_ACC_M = 82;
         public int NAA_FROM_D = 83;
         public int NAA_TO_D = 84;
         public int NAA_ACC_NO = 85;
         public int NAA_SGST_A = 86;
         public int NAA_CGST_A = 87;
         public int NAA_ACC_N = 88;
         public int NAA_SGSTAmount = 89;
         public int NAA_CGSTAmount = 90;
         public int NAA_BaseAmount = 91;
         public int LR_ACCHEAD_C = 92;
         public int LR_ACC_M = 93;
         public int LR_FROM_D = 94;
         public int LR_TO_D = 95;
         public int LR_ACC_NO = 96;
         public int LR_SGST_A = 97;
         public int LR_CGST_A = 98;
         public int LR_ACC_N = 99;
         public int LR_SGSTAmount = 100;
         public int LR_CGSTAmount = 101;
         public int LR_BaseAmount = 102;
         public int INT_ACCHEAD_C = 103;
         public int INT_ACC_M = 104;
         public int INT_FROM_D = 105;
         public int INT_TO_D = 106;
         public int INT_ACC_NO = 107;
         public int INT_SGST_A = 108;
         public int INT_CGST_A = 109;
         public int INT_ACC_N = 110;
         public int INT_SGSTAmount = 111;
         public int INT_CGSTAmount = 112;
         public int INT_BaseAmount = 113;
         public int SC_OS_CGST = 114;
         public int SC_OS_SGST = 115;
         public int NAA_OS_CGST = 116;
         public int NAA_OS_SGST = 117;
         public int LR_OS_CGST = 118;
         public int LR_OS_SGST = 119;
         public int INTREV_OS_CGST = 120;
         public int INTREV_OS_SGST = 121;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdatePaymentDetails
      public class SPUpdatePaymentDetails
      {
         public string SPName = "SPUpdatePaymentDetails";
         public int ApplicationFormIdnotused = 0;
         public int TxId = 1;
         public int TxRefNo = 2;
         public int TxStatus = 3;
         public int TxAmount = 4;
         public int TxMsg = 5;
         public int pgTxnNo = 6;
         public int issuerRefNo = 7;
         public int authIdCode = 8;
         public int firstName = 9;
         public int lastName = 10;
         public int pgRespCode = 11;
         public int addressZip = 12;
         public int signature = 13;
         public int Head = 14;
         public int paymentMode = 15;
         public int TxGateway = 16;
         public int cardType = 17;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetPendingDayFromLastActionAtGIDCendForBuildingPlanApproval
      public class SPGetPendingDayFromLastActionAtGIDCendForBuildingPlanApproval
      {
         public string SPName = "SPGetPendingDayFromLastActionAtGIDCendForBuildingPlanApproval";
         public int ReferenceNo = 0;
         public int Days = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDrainageApplication
      public class SPSelectDrainageApplication
      {
         public string SPName = "SPSelectDrainageApplication";
         public int AssignedRoleId = 0;
         public int SearchValue = 1;
         public int SearchId = 2;
         public int RegionId = 3;
         public int UserId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateSubdivisionModuleforGenerateNOCOutwardNo
      public class SpUpdateSubdivisionModuleforGenerateNOCOutwardNo
      {
         public string SPName = "SpUpdateSubdivisionModuleforGenerateNOCOutwardNo";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDelayReport
      public class SPDelayReport
      {
         public string SPName = "SPDelayReport";
         public int ApplicationId = 0;
         public int RegionId = 1;
         public int EstateId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDEEmailIdForReplyQueryForBuildingPlanApproval
      public class SPSelectDEEmailIdForReplyQueryForBuildingPlanApproval
      {
         public string SPName = "SPSelectDEEmailIdForReplyQueryForBuildingPlanApproval";
         public int EStateId = 0;
         public int ApplicationFormId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPBUILDINGPLANAPPLICATIONDETAILSREPORTFOOTER
      public class SPBUILDINGPLANAPPLICATIONDETAILSREPORTFOOTER
      {
         public string SPName = "SPBUILDINGPLANAPPLICATIONDETAILSREPORTFOOTER";
         public int StatusId = 0;
         public int FromDate = 1;
         public int Todate = 2;
         public int ApplicationType = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetWaterSupplyApplicationRejected
      public class SPGetWaterSupplyApplicationRejected
      {
         public string SPName = "SPGetWaterSupplyApplicationRejected";
         public int RegionId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectStateMasterByCountryId
      public class SPSelectStateMasterByCountryId
      {
         public string SPName = "SPSelectStateMasterByCountryId";
         public int CountryId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubdivisionModuleInvoice
      public class SPSelectSubdivisionModuleInvoice
      {
         public string SPName = "SPSelectSubdivisionModuleInvoice";
         public int ApplicationFormId = 0;
         public int UserId = 1;
         public int TxId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateBuildingplanApprovalApplicationForMailReminder
      public class SPUpdateBuildingplanApprovalApplicationForMailReminder
      {
         public string SPName = "SPUpdateBuildingplanApprovalApplicationForMailReminder";
         public int ApplicationFormId = 0;
         public int IsPreemptiveReminderSend = 1;
         public int PreemptiveFormate = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubLettingModulePriceByEstateId
      public class SPSelectSubLettingModulePriceByEstateId
      {
         public string SPName = "SPSelectSubLettingModulePriceByEstateId";
         public int EstateId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPAmalgamationPaymentVerification
      public class SPAmalgamationPaymentVerification
      {
         public string SPName = "SPAmalgamationPaymentVerification";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int UserRoleId = 2;
         public int CurrentApplicationActionId = 3;
         public int AssignedRoleId = 4;
         public int AssignedActionId = 5;
         public int Remark = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDrainageApplicationByApplicationFormId
      public class SPSelectDrainageApplicationByApplicationFormId
      {
         public string SPName = "SPSelectDrainageApplicationByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUserAppSummary
      public class SPUserAppSummary
      {
         public string SPName = "SPUserAppSummary";
         public int ApplicationId = 0;
         public int RegionId = 1;
         public int EstateId = 2;
         public int FromDate = 3;
         public int ToDate = 4;
         public int UserId = 5;
         public int RoleId = 6;
         public int ReportId = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPBmailIdForReplyQueryForBuildingPlanApproval
      public class SPSelectPBmailIdForReplyQueryForBuildingPlanApproval
      {
         public string SPName = "SPSelectPBmailIdForReplyQueryForBuildingPlanApproval";
         public int EStateId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDrainageDetailSummaryReport
      public class SPDrainageDetailSummaryReport
      {
         public string SPName = "SPDrainageDetailSummaryReport";
         public int RegionId = 0;
         public int StatusId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetDrainageApplicationRejected
      public class SPGetDrainageApplicationRejected
      {
         public string SPName = "SPGetDrainageApplicationRejected";
         public int RegionId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubdivisionModuleHOFlowUserByBranchAndRole
      public class SPSelectSubdivisionModuleHOFlowUserByBranchAndRole
      {
         public string SPName = "SPSelectSubdivisionModuleHOFlowUserByBranchAndRole";
         public int BranchId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubdivisionModuleInvoiceByHeader
      public class SPSelectSubdivisionModuleInvoiceByHeader
      {
         public string SPName = "SPSelectSubdivisionModuleInvoiceByHeader";
         public int ApplicationFormId = 0;
         public int TxId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectBuildingPlanApprovalApplicationList04102016
      public class SPSelectBuildingPlanApprovalApplicationList04102016
      {
         public string SPName = "SPSelectBuildingPlanApprovalApplicationList04102016";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateApplicantUserMasterForChangePassword
      public class SPUpdateApplicantUserMasterForChangePassword
      {
         public string SPName = "SPUpdateApplicantUserMasterForChangePassword";
         public int EmailId = 0;
         public int Password = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateGeneralApplicationForIFPPortal03112017
      public class SPUpdateGeneralApplicationForIFPPortal03112017
      {
         public string SPName = "SPUpdateGeneralApplicationForIFPPortal03112017";
         public int ReferenceNumber = 0;
         public int IsIFP_Sync = 1;
         public int IFPActionId = 2;
         public int ModifiedBy = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPlotShedNoByEstateIdAndPlotTypeId12042017
      public class SPSelectPlotShedNoByEstateIdAndPlotTypeId12042017
      {
         public string SPName = "SPSelectPlotShedNoByEstateIdAndPlotTypeId12042017";
         public int EstateId = 0;
         public int PlotTypeId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectdrainageApplicationByIFPApplicationId
      public class SPSelectdrainageApplicationByIFPApplicationId
      {
         public string SPName = "SPSelectdrainageApplicationByIFPApplicationId";
         public int IFPApplicationId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectApplicationPaymentDetailByApplicationFormIdForSurrender
      public class SPSelectApplicationPaymentDetailByApplicationFormIdForSurrender
      {
         public string SPName = "SPSelectApplicationPaymentDetailByApplicationFormIdForSurrender";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUserSummaryReport
      public class SPUserSummaryReport
      {
         public string SPName = "SPUserSummaryReport";
         public int ApplicationId = 0;
         public int RegionId = 1;
         public int EstateId = 2;
         public int FromDate = 3;
         public int ToDate = 4;
         public int UserId = 5;
         public int RoleId = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectXENmailIdForReplyQueryForBuildingPlanApproval
      public class SPSelectXENmailIdForReplyQueryForBuildingPlanApproval
      {
         public string SPName = "SPSelectXENmailIdForReplyQueryForBuildingPlanApproval";
         public int EStateId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPWaterSupplyDetailSummaryReport
      public class SPWaterSupplyDetailSummaryReport
      {
         public string SPName = "SPWaterSupplyDetailSummaryReport";
         public int RegionId = 0;
         public int StatusId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateGSTNoforBuildingPlanApprovalApplicationByHeader
      public class SPUpdateGSTNoforBuildingPlanApprovalApplicationByHeader
      {
         public string SPName = "SPUpdateGSTNoforBuildingPlanApprovalApplicationByHeader";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubLettingModuleByApplicationFormId02022017
      public class SPSelectSubLettingModuleByApplicationFormId02022017
      {
         public string SPName = "SPSelectSubLettingModuleByApplicationFormId02022017";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateTrasferModuleforGenerateFTOOutwardNo
      public class SpUpdateTrasferModuleforGenerateFTOOutwardNo
      {
         public string SPName = "SpUpdateTrasferModuleforGenerateFTOOutwardNo";
         public int ApplicationFormId = 0;
         public int LeaseDeedDate = 1;
         public int IsDeedAssignment = 2;
         public int DateOfAssignment = 3;
         public int IsDeedDeclaration = 4;
         public int DateOfDeclaration = 5;
         public int IsDeedRectification = 6;
         public int DateOfRectification = 7;
         public int DateOfSupplementaryAgreement = 8;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertBuildingPlanApprovalDWG
      public class SPInsertBuildingPlanApprovalDWG
      {
         public string SPName = "SPInsertBuildingPlanApprovalDWG";
         public int ApplicationFormId = 0;
         public int DWGdata = 1;
         public int CreatedBy = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPRMSummaryReport
      public class SPRMSummaryReport
      {
         public string SPName = "SPRMSummaryReport";
         public int ApplicationId = 0;
         public int RegionId = 1;
         public int FromDate = 2;
         public int ToDate = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateBuildingPlanApprovalApplicationForm
      public class SPUpdateBuildingPlanApprovalApplicationForm
      {
         public string SPName = "SPUpdateBuildingPlanApprovalApplicationForm";
         public int Operation = 0;
         public int ApplicationFormId = 1;
         public int ApplicantName = 2;
         public int OCALetterDoc = 3;
         public int LicenceAgreementDoc = 4;
         public int PossessionReceiptDoc = 5;
         public int CompletesetofDrawingDoc = 6;
         public int LatestTrasferOrderDoc = 7;
         public int CopyofTimeLimitExtensionLetterDoc = 8;
         public int CTENOCFromGPCB = 9;
         public int FieldBookSketch = 10;
         public int ModifiedBy = 11;
         public int IndustryTypeId = 12;
         public int IsHighRisk = 13;
         public int RiskType = 14;
         public int DateofPossession = 15;
         public int ApplicantUploadDocument = 16;
         public int TypeOfApproval = 17;
         public int SubmissionOfApprovalPlan = 18;
         public int AsbuiltDrawing = 19;
         public int Office = 20;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDrainageSummaryReport
      public class SPDrainageSummaryReport
      {
         public string SPName = "SPDrainageSummaryReport";
         public int RegionId = 0;
         public int StatusId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetBuildingPlanApplicationRejected
      public class SPGetBuildingPlanApplicationRejected
      {
         public string SPName = "SPGetBuildingPlanApplicationRejected";
         public int RegionId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectEstateMasterByRegionId
      public class SPSelectEstateMasterByRegionId
      {
         public string SPName = "SPSelectEstateMasterByRegionId";
         public int RegionId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubLettingModuleInvoice
      public class SPSelectSubLettingModuleInvoice
      {
         public string SPName = "SPSelectSubLettingModuleInvoice";
         public int ApplicationFormId = 0;
         public int UserId = 1;
         public int TxId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSurrenderApplicationSummaryReport
      public class SPSurrenderApplicationSummaryReport
      {
         public string SPName = "SPSurrenderApplicationSummaryReport";
         public int BeforeAfter = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPCheckUniqueReferenceNoForSubLettingModule02022017
      public class SPCheckUniqueReferenceNoForSubLettingModule02022017
      {
         public string SPName = "SPCheckUniqueReferenceNoForSubLettingModule02022017";
         public int ReferenceNo = 0;
         public int EstateId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectApplicationUserMasterForChangePassword
      public class SPSelectApplicationUserMasterForChangePassword
      {
         public string SPName = "SPSelectApplicationUserMasterForChangePassword";
         public int EmailId = 0;
         public int Password = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpSelectWaterDrainagePlanQueryApplicationList
      public class SpSelectWaterDrainagePlanQueryApplicationList
      {
         public string SPName = "SpSelectWaterDrainagePlanQueryApplicationList";
         public int AssignedRoleId = 0;
         public int SearchValue = 1;
         public int SearchId = 2;
         public int RegionId = 3;
         public int UserId = 4;
         public int ApplicationTypeId = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUPDATEBuildingPlanApprovalDWG
      public class SPUPDATEBuildingPlanApprovalDWG
      {
         public string SPName = "SPUPDATEBuildingPlanApprovalDWG";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDrainageApplicationIFPDetials03112017
      public class SPSelectDrainageApplicationIFPDetials03112017
      {
         public string SPName = "SPSelectDrainageApplicationIFPDetials03112017";
         public int ReferenceNo = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPTwoRApplicationReport
      public class SPTwoRApplicationReport
      {
         public string SPName = "SPTwoRApplicationReport";
         public int ApplicationId = 0;
         public int RegionId = 1;
         public int EstateId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region GetDMSApplicationFilesdtl
      public class GetDMSApplicationFilesdtl
      {
         public string SPName = "GetDMSApplicationFilesdtl";
         public int Mode = 0;
         public int DocumentId = 1;
         public int PlottypeId = 2;
         public int EstateId = 3;
         public int PartyCode = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateBuildingPlanApprovalApplicationFormApplicantQuery
      public class SPUpdateBuildingPlanApprovalApplicationFormApplicantQuery
      {
         public string SPName = "SPUpdateBuildingPlanApprovalApplicationFormApplicantQuery";
         public int Operation = 0;
         public int ApplicationFormId = 1;
         public int UserId = 2;
         public int ActionId = 3;
         public int QueryAnswerApplicantLine1 = 4;
         public int QueryAnswerApplicantLine2 = 5;
         public int QueryAnswerApplicantLine3 = 6;
         public int QueryAnswerApplicantLine4 = 7;
         public int QueryAnswerApplicantLine5 = 8;
         public int OCALetterDoc = 9;
         public int LicenceAgreementDoc = 10;
         public int PossessionReceiptDoc = 11;
         public int CompletesetofDrawingDoc = 12;
         public int LatestTrasferOrderDoc = 13;
         public int CopyofTimeLimitExtensionLetterDoc = 14;
         public int CTENOCFromGPCB = 15;
         public int FieldBookSketch = 16;
         public int ReplyAttchment = 17;
         public int ApplicantUploadDocument = 18;
         public int SubmissionOfApprovalPlan = 19;
         public int AsbuiltDrawing = 20;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubLettingModuleInvoiceByHeader
      public class SPSelectSubLettingModuleInvoiceByHeader
      {
         public string SPName = "SPSelectSubLettingModuleInvoiceByHeader";
         public int ApplicationFormId = 0;
         public int InvoiceNo = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region GetSurrenderSummaryReportbyStatus
      public class GetSurrenderSummaryReportbyStatus
      {
         public string SPName = "GetSurrenderSummaryReportbyStatus";
         public int RegionId = 0;
         public int ApplicationStatusId = 1;
         public int Flag = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubLettingModuleForReferenceNo02022017
      public class SPSelectSubLettingModuleForReferenceNo02022017
      {
         public string SPName = "SPSelectSubLettingModuleForReferenceNo02022017";
         public int EstateId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateAmalgamationModuleOutwardByApplicationFormId
      public class SPUpdateAmalgamationModuleOutwardByApplicationFormId
      {
         public string SPName = "SPUpdateAmalgamationModuleOutwardByApplicationFormId";
         public int ApplicationFormId = 0;
         public int OutwardDocumentName = 1;
         public int isPTO = 2;
         public int IsAggredTransferMode = 3;
         public int FormalTrasferOrInFormalTrasfer = 4;
         public int ModifiedBy = 5;
         public int Remarks = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateRouModuleQueryDocuments
      public class SPUpdateRouModuleQueryDocuments
      {
         public string SPName = "SPUpdateRouModuleQueryDocuments";
         public int ApplicationFormId = 0;
         public int ActionId = 1;
         public int QueryDocumentsXML = 2;
         public int RoutePlanOkorNotOk = 3;
         public int DocRoutePlan = 4;
         public int ApprovalLetterOkorNotOk = 5;
         public int DocApprovalLetter = 6;
         public int QueryReply = 7;
         public int UserId = 8;
         public int ROUModuleOtherQueryId = 9;
         public int NewAssignedActionId = 10;
         public int ConcludingRemarks = 11;
         public int AssignedRoleId = 12;
         public int NDCAccount = 13;
         public int NDCEngineering = 14;
         public int DocROUAgreementCopy = 15;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateTrasferModuleApplicationForPTODocs
      public class SpUpdateTrasferModuleApplicationForPTODocs
      {
         public string SPName = "SpUpdateTrasferModuleApplicationForPTODocs";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int NewAssinedActionId = 2;
         public int Remark = 3;
         public int DSPublickey = 4;
         public int DSHash = 5;
         public int DScrtString = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDrainageApplicationList
      public class SPSelectDrainageApplicationList
      {
         public string SPName = "SPSelectDrainageApplicationList";
         public int UserId = 0;
         public int Project = 1;
         public int SearchText = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdatePaymentDetailsSurrenderForBillDesk
      public class SPUpdatePaymentDetailsSurrenderForBillDesk
      {
         public string SPName = "SPUpdatePaymentDetailsSurrenderForBillDesk";
         public int MerchnatId = 0;
         public int TxId = 1;
         public int TxRefNo = 2;
         public int BankRefNo = 3;
         public int TxAmount = 4;
         public int BankID = 5;
         public int CardBin = 6;
         public int TxnType = 7;
         public int CurrencyName = 8;
         public int ItemcOde = 9;
         public int securityType = 10;
         public int securityId = 11;
         public int surchargeAmount = 12;
         public int TxnDate = 13;
         public int TxStatus = 14;
         public int SettlementType = 15;
         public int ShortCode = 16;
         public int Additionalinfo2 = 17;
         public int Additionalinfo3 = 18;
         public int Additionalinfo4 = 19;
         public int Additionalinfo5 = 20;
         public int Additionalinfo6 = 21;
         public int Additionalinfo7 = 22;
         public int ErrorStatus = 23;
         public int ErrorDescription = 24;
         public int CheckSum = 25;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectEstateMasterByRegion
      public class SPSelectEstateMasterByRegion
      {
         public string SPName = "SPSelectEstateMasterByRegion";
         public int RegionId = 0;
         public int UserId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateBuildingPlanApprovalForPayFee
      public class SPUpdateBuildingPlanApprovalForPayFee
      {
         public string SPName = "SPUpdateBuildingPlanApprovalForPayFee";
         public int ApplicationFormId = 0;
         public int UserId = 1;
         public int PayFeeForApproval = 2;
         public int NEFTorRTGSDocument = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPWaterSupplySummaryReport
      public class SPWaterSupplySummaryReport
      {
         public string SPName = "SPWaterSupplySummaryReport";
         public int RegionId = 0;
         public int StatusId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetLeaseApplicationRejected
      public class SPGetLeaseApplicationRejected
      {
         public string SPName = "SPGetLeaseApplicationRejected";
         public int RegionId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTWORApplicationModuleInvoice
      public class SPSelectTWORApplicationModuleInvoice
      {
         public string SPName = "SPSelectTWORApplicationModuleInvoice";
         public int ApplicationFormId = 0;
         public int UserId = 1;
         public int TxId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region GetSurrenderSummaryReportbyStatusforAllRegion
      public class GetSurrenderSummaryReportbyStatusforAllRegion
      {
         public string SPName = "GetSurrenderSummaryReportbyStatusforAllRegion";
         public int ApplicationStatusId = 0;
         public int Flag = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSubLettingSelectSubLettingByUserId02022017
      public class SPSubLettingSelectSubLettingByUserId02022017
      {
         public string SPName = "SPSubLettingSelectSubLettingByUserId02022017";
         public int UserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateAmalgamationModuleforGenerateFO_OutwardNo
      public class SpUpdateAmalgamationModuleforGenerateFO_OutwardNo
      {
         public string SPName = "SpUpdateAmalgamationModuleforGenerateFO_OutwardNo";
         public int ApplicationFormId = 0;
         public int LeaseDeedDate = 1;
         public int IsDeedAssignment = 2;
         public int DateOfAssignment = 3;
         public int IsDeedDeclaration = 4;
         public int DateOfDeclaration = 5;
         public int IsDeedRectification = 6;
         public int DateOfRectification = 7;
         public int DateOfSupplementaryAgreement = 8;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectApplicantUserMasterForChangePassword
      public class SPSelectApplicantUserMasterForChangePassword
      {
         public string SPName = "SPSelectApplicantUserMasterForChangePassword";
         public int EmailId = 0;
         public int Password = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSurrenderByApplicationFormId25092016
      public class SPSelectSurrenderByApplicationFormId25092016
      {
         public string SPName = "SPSelectSurrenderByApplicationFormId25092016";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertTransactionReferenceNoPaymentDetailsForPTO
      public class SPInsertTransactionReferenceNoPaymentDetailsForPTO
      {
         public string SPName = "SPInsertTransactionReferenceNoPaymentDetailsForPTO";
         public int TxId = 0;
         public int ApplicationFormId = 1;
         public int PTOPayment = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateCRDatesOnReceiveForTransfer
      public class SPUpdateCRDatesOnReceiveForTransfer
      {
         public string SPName = "SPUpdateCRDatesOnReceiveForTransfer";
         public int ApplicationId = 0;
         public int ApplicationFormId = 1;
         public int ReceivedDate = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDrainageInspectionListByInspectorUserId
      public class SPSelectDrainageInspectionListByInspectorUserId
      {
         public string SPName = "SPSelectDrainageInspectionListByInspectorUserId";
         public int InspectorUserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPTrackApplicationbyAppnum
      public class SPTrackApplicationbyAppnum
      {
         public string SPName = "SPTrackApplicationbyAppnum";
         public int ReferenceNo = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region BuildinPlanDetailSummaryReport
      public class BuildinPlanDetailSummaryReport
      {
         public string SPName = "BuildinPlanDetailSummaryReport";
         public int RegionId = 0;
         public int StatusId = 1;
         public int FromDate = 2;
         public int Todate = 3;
         public int ApplicationType = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetWaterSupplyPendingWithApplicant
      public class SPGetWaterSupplyPendingWithApplicant
      {
         public string SPName = "SPGetWaterSupplyPendingWithApplicant";
         public int RegionId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDistrictMasterByStateId
      public class SPSelectDistrictMasterByStateId
      {
         public string SPName = "SPSelectDistrictMasterByStateId";
         public int StateId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPBuildingCompletionSummaryAndDetailsReport
      public class SPBuildingCompletionSummaryAndDetailsReport
      {
         public string SPName = "SPBuildingCompletionSummaryAndDetailsReport";
         public int RegionId = 0;
         public int EstateId = 1;
         public int Type = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDrainageMailIdByRoleId
      public class SPSelectDrainageMailIdByRoleId
      {
         public string SPName = "SPSelectDrainageMailIdByRoleId";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region GetEmployeeDetailsByEmpCode
      public class GetEmployeeDetailsByEmpCode
      {
         public string SPName = "GetEmployeeDetailsByEmpCode";
         public int EmployeeCode = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region BuildinPlanSummaryReport
      public class BuildinPlanSummaryReport
      {
         public string SPName = "BuildinPlanSummaryReport";
         public int RegionId = 0;
         public int StatusId = 1;
         public int FromDate = 2;
         public int Todate = 3;
         public int ApplicationType = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDigitalInfo
      public class SPSelectDigitalInfo
      {
         public string SPName = "SPSelectDigitalInfo";
         public int UserId = 0;
         public int RoleId = 1;
         public int EmailId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferModulePTOInvoiceByHeader
      public class SPSelectTransferModulePTOInvoiceByHeader
      {
         public string SPName = "SPSelectTransferModulePTOInvoiceByHeader";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDrainageReleaseConnectionDetailsByApplicationFormId
      public class SPSelectDrainageReleaseConnectionDetailsByApplicationFormId
      {
         public string SPName = "SPSelectDrainageReleaseConnectionDetailsByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertupdateSubdivisionNOCdetails
      public class SPInsertupdateSubdivisionNOCdetails
      {
         public string SPName = "SPInsertupdateSubdivisionNOCdetails";
         public int Mode = 0;
         public int ApplicationformId = 1;
         public int NocFilePath = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertInvoiceForRegion
      public class SPInsertInvoiceForRegion
      {
         public string SPName = "SPInsertInvoiceForRegion";
         public int ApplicationId = 0;
         public int ApplicationFormId = 1;
         public int CreatedBy = 2;
         public int RegionId = 3;
         public int TxId = 4;
         public int TxRefNo = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetPendingDayFromLastActionAtGIDCendForTransferModule
      public class SPGetPendingDayFromLastActionAtGIDCendForTransferModule
      {
         public string SPName = "SPGetPendingDayFromLastActionAtGIDCendForTransferModule";
         public int ReferenceNo = 0;
         public int Days = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetDrainageApplicationPendingWithApplicant
      public class SPGetDrainageApplicationPendingWithApplicant
      {
         public string SPName = "SPGetDrainageApplicationPendingWithApplicant";
         public int RegionId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTalukaMasterByDistrictId
      public class SPSelectTalukaMasterByDistrictId
      {
         public string SPName = "SPSelectTalukaMasterByDistrictId";
         public int DistrictId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPPlinthCirtificationSummaryAndDetailsReport
      public class SPPlinthCirtificationSummaryAndDetailsReport
      {
         public string SPName = "SPPlinthCirtificationSummaryAndDetailsReport";
         public int RegionId = 0;
         public int EstateId = 1;
         public int Type = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpEODBApplicationSummary
      public class SpEODBApplicationSummary
      {
         public string SPName = "SpEODBApplicationSummary";
         public int UserId = 0;
         public int StartDate = 1;
         public int EndDate = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferModuleQueryDocuments27032017
      public class SPSelectTransferModuleQueryDocuments27032017
      {
         public string SPName = "SPSelectTransferModuleQueryDocuments27032017";
         public int AplicationFormId = 0;
         public int AssignedRoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDelayTwoRAppByUserRole
      public class SPSelectDelayTwoRAppByUserRole
      {
         public string SPName = "SPSelectDelayTwoRAppByUserRole";
         public int RoleId = 0;
         public int RegionId = 1;
         public int UserId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateDrainageApplicationByAdmin
      public class SpUpdateDrainageApplicationByAdmin
      {
         public string SPName = "SpUpdateDrainageApplicationByAdmin";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int UserRoleId = 2;
         public int CurrentApplicationActionId = 3;
         public int CurrentApplicationStatusId = 4;
         public int AssignedRoleId = 5;
         public int AssignedActionId = 6;
         public int AssignedStatusId = 7;
         public int SignedApplicationFormDEE = 8;
         public int CCAfromGpcbDEE = 9;
         public int LicenseAgreementDEE = 10;
         public int SignedGIDCDrainageRegulationsDEE = 11;
         public int SignedApplicationFormXEN = 12;
         public int CCAfromGpcbXEN = 13;
         public int LicenseAgreementXEN = 14;
         public int SignedGIDCDrainageRegulationsXEN = 15;
         public int CalculatingPipeDiaRequirementDEE = 16;
         public int CalculatingPipeDiaRequirementXEN = 17;
         public int ExistingDrainageLineDetailsDEE = 18;
         public int ExistingDrainageLineDetailsXEN = 19;
         public int ProposedPipeLineDiaDEE = 20;
         public int ProposedPipeLineDiaXEN = 21;
         public int QueryLineDEE1 = 22;
         public int QueryLineDEE2 = 23;
         public int QueryLineDEE3 = 24;
         public int QueryLineDEE4 = 25;
         public int QueryLineDEE5 = 26;
         public int QueryLineXEN1 = 27;
         public int QueryLineXEN2 = 28;
         public int QueryLineXEN3 = 29;
         public int QueryLineXEN4 = 30;
         public int QueryLineXEN5 = 31;
         public int AdminAttachmentXML = 32;
         public int Remarks = 33;
         public int QueryDocumentXML = 34;
         public int PossessionReceiptDEE = 35;
         public int OCAletterDEE = 36;
         public int PossessionReceiptXEN = 37;
         public int OCAletterXEN = 38;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectRegionEmailIdfromRegionId
      public class SPSelectRegionEmailIdfromRegionId
      {
         public string SPName = "SPSelectRegionEmailIdfromRegionId";
         public int RegionId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectBuildingCompletionByApplicationFormId
      public class SPSelectBuildingCompletionByApplicationFormId
      {
         public string SPName = "SPSelectBuildingCompletionByApplicationFormId";
         public int ApplicationFormId = 0;
         public int mode = 1;
         public int BuildingPlanUI = 2;
         public int BuildingPlanDeptUniqueId = 3;
         public int BuildingPlanEODBApplicationId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdatePhotoPathByEmpCode
      public class SPUpdatePhotoPathByEmpCode
      {
         public string SPName = "SPUpdatePhotoPathByEmpCode";
         public int EmployeeCode = 0;
         public int PhotoPath = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPTransferApplicationSummaryReportNew
      public class SPTransferApplicationSummaryReportNew
      {
         public string SPName = "SPTransferApplicationSummaryReportNew";
         public int BeforeAfter = 0;
         public int RegionId = 1;
         public int StatusId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertDigitalSignatureData
      public class SPInsertDigitalSignatureData
      {
         public string SPName = "SPInsertDigitalSignatureData";
         public int msg = 0;
         public int SerialNumber = 1;
         public int flag = 2;
         public int subject = 3;
         public int subjectAlternativeName = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectCityMasterByTalukaId
      public class SPSelectCityMasterByTalukaId
      {
         public string SPName = "SPSelectCityMasterByTalukaId";
         public int TalukaId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferModulePTOInvoice
      public class SPSelectTransferModulePTOInvoice
      {
         public string SPName = "SPSelectTransferModulePTOInvoice";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteEstateMasterByEstateId
      public class SPDeleteEstateMasterByEstateId
      {
         public string SPName = "SPDeleteEstateMasterByEstateId";
         public int EstateId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateTransferModuleForRejectApplication
      public class SPUpdateTransferModuleForRejectApplication
      {
         public string SPName = "SPUpdateTransferModuleForRejectApplication";
         public int ApplicationFormId = 0;
         public int RejectReason = 1;
         public int ModifiedBy = 2;
         public int RoleId = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateDrainageApplicationDemandDraftByApplicant
      public class SPUpdateDrainageApplicationDemandDraftByApplicant
      {
         public string SPName = "SPUpdateDrainageApplicationDemandDraftByApplicant";
         public int ApplicationFormId = 0;
         public int AssignedActionId = 1;
         public int NEFTorRTGSDocument = 2;
         public int UserId = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpInsertUpdateApplicantMenu
      public class SpInsertUpdateApplicantMenu
      {
         public string SPName = "SpInsertUpdateApplicantMenu";
         public int Mode = 0;
         public int Status = 1;
         public int MenuId = 2;
         public int UserId = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertSaturdaySunday
      public class SPInsertSaturdaySunday
      {
         public string SPName = "SPInsertSaturdaySunday";
         public int year = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertCRDailyApplicationDetails
      public class SPInsertCRDailyApplicationDetails
      {
         public string SPName = "SPInsertCRDailyApplicationDetails";
         public int ApplicationId = 0;
         public int ApplicationFormId = 1;
         public int AppForwardDate = 2;
         public int AppActualForwardDate = 3;
         public int ActionId = 4;
         public int AssignRoleId = 5;
         public int EstateId = 6;
         public int Remark = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetBuildinPlanPendingWithApplicant
      public class SPGetBuildinPlanPendingWithApplicant
      {
         public string SPName = "SPGetBuildinPlanPendingWithApplicant";
         public int RegionId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTWORAPPLICATIONModuleInvoiceByHeader
      public class SPSelectTWORAPPLICATIONModuleInvoiceByHeader
      {
         public string SPName = "SPSelectTWORAPPLICATIONModuleInvoiceByHeader";
         public int ApplicationFormId = 0;
         public int TxId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPTransferApplicationDetailsReportTempHardik
      public class SPTransferApplicationDetailsReportTempHardik
      {
         public string SPName = "SPTransferApplicationDetailsReportTempHardik";
         public int REGIONID = 0;
         public int ACTIONID = 1;
         public int ActionType = 2;
         public int BeforeAfter = 3;
         public int OldApplicationStatusId = 4;
         public int PTOIssueCMD = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateEstateMaster
      public class SPInsertUpdateEstateMaster
      {
         public string SPName = "SPInsertUpdateEstateMaster";
         public int EstateId = 0;
         public int Estate = 1;
         public int RegionId = 2;
         public int UserId = 3;
         public int IsActive = 4;
         public int Operation = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectEstatePriceForSubdivisionByApplicationFormId
      public class SPSelectEstatePriceForSubdivisionByApplicationFormId
      {
         public string SPName = "SPSelectEstatePriceForSubdivisionByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateTransferModuleForDues
      public class SPUpdateTransferModuleForDues
      {
         public string SPName = "SPUpdateTransferModuleForDues";
         public int ApplicationFormId = 0;
         public int AccountDues = 1;
         public int WaterDues = 2;
         public int EngineeringDues = 3;
         public int DrainageDues = 4;
         public int ModifiedBy = 5;
         public int TotalPaybleAmount = 6;
         public int OSINST_A = 7;
         public int OSIDPPI_A = 8;
         public int OSSC_A = 9;
         public int OSSC_ST = 10;
         public int OSSC_EC = 11;
         public int OSSWCSC = 12;
         public int OSSCKKC = 13;
         public int OSNAA_A = 14;
         public int OSNAA_ST = 15;
         public int OSNAA_EC = 16;
         public int OSSWCNAA = 17;
         public int OSNAAKKC = 18;
         public int OSLR_A = 19;
         public int OSLR_ST = 20;
         public int OSLR_EC = 21;
         public int OSSWCLR = 22;
         public int OSLRKKC = 23;
         public int OSIR_A = 24;
         public int OSIUF_A = 25;
         public int OSIUF_ST = 26;
         public int OSIUF_EC = 27;
         public int OSFULLPAYMENT_A = 28;
         public int LRCOSINST_A = 29;
         public int LRCOSIDP_A = 30;
         public int AC_SGSTAmount = 31;
         public int AC_CGSTAmount = 32;
         public int AC_ACCHEAD_C = 33;
         public int AC_ACC_M = 34;
         public int AC_FROM_D = 35;
         public int AC_TO_D = 36;
         public int AC_ACC_NO = 37;
         public int AC_SGST_A = 38;
         public int AC_CGST_A = 39;
         public int AC_ACC_N = 40;
         public int EN_SGSTAmount = 41;
         public int EN_CGSTAmount = 42;
         public int EN_ACCHEAD_C = 43;
         public int EN_ACC_M = 44;
         public int EN_FROM_D = 45;
         public int EN_TO_D = 46;
         public int EN_ACC_NO = 47;
         public int EN_SGST_A = 48;
         public int EN_CGST_A = 49;
         public int EN_ACC_N = 50;
         public int SC_SGSTAmount = 51;
         public int SC_CGSTAmount = 52;
         public int SC_ACCHEAD_C = 53;
         public int SC_ACC_M = 54;
         public int SC_FROM_D = 55;
         public int SC_TO_D = 56;
         public int SC_ACC_NO = 57;
         public int SC_SGST_A = 58;
         public int SC_CGST_A = 59;
         public int SC_ACC_N = 60;
         public int SC_BaseAmount = 61;
         public int NAA_SGSTAmount = 62;
         public int NAA_CGSTAmount = 63;
         public int NAA_ACCHEAD_C = 64;
         public int NAA_ACC_M = 65;
         public int NAA_FROM_D = 66;
         public int NAA_TO_D = 67;
         public int NAA_ACC_NO = 68;
         public int NAA_SGST_A = 69;
         public int NAA_CGST_A = 70;
         public int NAA_ACC_N = 71;
         public int NAA_BaseAmount = 72;
         public int LR_SGSTAmount = 73;
         public int LR_CGSTAmount = 74;
         public int LR_ACCHEAD_C = 75;
         public int LR_ACC_M = 76;
         public int LR_FROM_D = 77;
         public int LR_TO_D = 78;
         public int LR_ACC_NO = 79;
         public int LR_SGST_A = 80;
         public int LR_CGST_A = 81;
         public int LR_ACC_N = 82;
         public int LR_BaseAmount = 83;
         public int INT_SGSTAmount = 84;
         public int INT_CGSTAmount = 85;
         public int INT_ACCHEAD_C = 86;
         public int INT_ACC_M = 87;
         public int INT_FROM_D = 88;
         public int INT_TO_D = 89;
         public int INT_ACC_NO = 90;
         public int INT_SGST_A = 91;
         public int INT_CGST_A = 92;
         public int INT_ACC_N = 93;
         public int INT_BaseAmount = 94;
         public int SC_OS_CGST = 95;
         public int SC_OS_SGST = 96;
         public int NAA_OS_CGST = 97;
         public int NAA_OS_SGST = 98;
         public int LR_OS_CGST = 99;
         public int LR_OS_SGST = 100;
         public int INTREV_OS_CGST = 101;
         public int INTREV_OS_SGST = 102;
         public int NUACCHEAD_C = 103;
         public int NUACC_M = 104;
         public int NUFROM_D = 105;
         public int NUTO_D = 106;
         public int NUACC_NO = 107;
         public int NUSGST_A = 108;
         public int NUCGST_A = 109;
         public int NUACC_N = 110;
         public int NUSGSTAmount = 111;
         public int NUCGSTAmount = 112;
         public int TFACCHEAD_C = 113;
         public int TFACC_M = 114;
         public int TFFROM_D = 115;
         public int TFTO_D = 116;
         public int TFACC_NO = 117;
         public int TFSGST_A = 118;
         public int TFCGST_A = 119;
         public int TFACC_N = 120;
         public int TFSGSTAmount = 121;
         public int TFCGSTAmount = 122;
         public int AddTFSGSTAmount = 123;
         public int AddTFCGSTAmount = 124;
         public int AddTFACCHEAD_C = 125;
         public int AddTFACC_M = 126;
         public int AddTFFROM_D = 127;
         public int AddTFTO_D = 128;
         public int AddTFACC_NO = 129;
         public int AddTFSGST_A = 130;
         public int AddTFCGST_A = 131;
         public int AddTFACC_N = 132;
         public int REVINT_CSGST_OS = 133;
         public int GSTNo = 134;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteRoleMasterByRoleId
      public class SPDeleteRoleMasterByRoleId
      {
         public string SPName = "SPDeleteRoleMasterByRoleId";
         public int RoleId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateDrainageApplicationForm
      public class SPUpdateDrainageApplicationForm
      {
         public string SPName = "SPUpdateDrainageApplicationForm";
         public int Operation = 0;
         public int ApplicationFormId = 1;
         public int ApplicantName = 2;
         public int DescriptionofPremises = 3;
         public int SizeofWaterConnection = 4;
         public int ConsumptionOfWaterLiters = 5;
         public int QuantityEffluentToBeDischarged = 6;
         public int SizeofDrainageConnection = 7;
         public int QualityofEffluent = 8;
         public int PermissionOrNoObjectionCertificate = 9;
         public int EffluentAnalysisReport = 10;
         public int IndustrialWasteGPCBOrderNo = 11;
         public int IndustrialWasteGPCBDate = 12;
         public int WhetherControlManholeConstructed = 13;
         public int DateofPossessionField = 14;
         public int SignedApplicationFormDoc = 15;
         public int CCAfromGpcbDoc = 16;
         public int LicenseAgreementDoc = 17;
         public int PossessionReceiptDoc = 18;
         public int OCAletterDoc = 19;
         public int SignedGIDCDrainageRegulationsDoc = 20;
         public int ApplicantDocumentList = 21;
         public int ModifiedBy = 22;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateTrasferModuleApplicationInManagerHOLoop
      public class SpUpdateTrasferModuleApplicationInManagerHOLoop
      {
         public string SPName = "SpUpdateTrasferModuleApplicationInManagerHOLoop";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int NewAssinedActionId = 2;
         public int AssignedRoleId = 3;
         public int DepartmentId = 4;
         public int Remarks = 5;
         public int HOAdditionalDocs = 6;
         public int BranchUserId = 7;
         public int CurrentBranchId = 8;
         public int DSPublickey = 9;
         public int DSHash = 10;
         public int DScrtString = 11;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTrasferModuleTrasferorDetailsByApplicationFormId
      public class SPSelectTrasferModuleTrasferorDetailsByApplicationFormId
      {
         public string SPName = "SPSelectTrasferModuleTrasferorDetailsByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region spPlainthSelfCertification
      public class spPlainthSelfCertification
      {
         public string SPName = "spPlainthSelfCertification";
         public int Mode = 0;
         public int ReferenceNo = 1;
         public int ActionId = 2;
         public int AssignedRoleId = 3;
         public int ApplicationId = 4;
         public int ApplicantName = 5;
         public int MobileNo = 6;
         public int EmailId = 7;
         public int EstateId = 8;
         public int RegionId = 9;
         public int PlotShedType = 10;
         public int OraEstateId = 11;
         public int OraRegionId = 12;
         public int OraPlotTypeId = 13;
         public int PlotShedNo = 14;
         public int PlotShedArea = 15;
         public int AllotmentDate = 16;
         public int Address = 17;
         public int BuildingPlanLatterNo = 18;
         public int BuildingPlanLatterDate = 19;
         public int ArchitectName = 20;
         public int PlinthConstructionArea = 21;
         public int PlinthCompletionFee = 22;
         public int PartyCode = 23;
         public int PlinthPlanApprovalLetter = 24;
         public int PlinthCompletionSelfCertification = 25;
         public int AttechmentDoc = 26;
         public int SubmissionDate = 27;
         public int FinalPaymentStatus = 28;
         public int ApplicationFormId = 29;
         public int CreatedBy = 30;
         public int AllotteeName = 31;
         public int CreationOn = 32;
         public int IsSubmitted = 33;
         public int PlinthBuildingLayoutPlan = 34;
         public int IsCertificatePlanDevelopment = 35;
         public int ArchitectRegisterNumber = 36;
         public int ArchitectRegisterWith = 37;
         public int ArchitectRegisterDate = 38;
         public int SGSTAmount = 39;
         public int CGSTAmount = 40;
         public int BaseAmount = 41;
         public int ACCHEAD_C = 42;
         public int ACC_M = 43;
         public int FROM_D = 44;
         public int TO_D = 45;
         public int SGST_A = 46;
         public int CGST_A = 47;
         public int TotalAdministrativeCharges = 48;
         public int AlloteeGSTNo = 49;
         public int BuildingPlanUI = 50;
         public int BuildingPlanDeptUniqueId = 51;
         public int BuildingPlanEODBApplicationId = 52;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateSublettingQueryCount
      public class SPInsertUpdateSublettingQueryCount
      {
         public string SPName = "SPInsertUpdateSublettingQueryCount";
         public int ApplicationFormId = 0;
         public int ActionId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateSubdivisionFeeDetail
      public class SPUpdateSubdivisionFeeDetail
      {
         public string SPName = "SPUpdateSubdivisionFeeDetail";
         public int Mode = 0;
         public int ApplicationFormId = 1;
         public int SD_AccountDues = 2;
         public int SD_WaterDues = 3;
         public int SD_OtherDues = 4;
         public int SD_DrainageDues = 5;
         public int SD_OSINST_A = 6;
         public int SD_OSIDPPI_A = 7;
         public int SD_OSSC_A = 8;
         public int SD_OSSC_ST = 9;
         public int SD_OSSC_EC = 10;
         public int SD_OSSWCSC = 11;
         public int SD_OSSCKKC = 12;
         public int SD_OSNAA_A = 13;
         public int SD_OSNAA_ST = 14;
         public int SD_OSNAA_EC = 15;
         public int SD_OSSWCNAA = 16;
         public int SD_OSNAAKKC = 17;
         public int SD_OSLR_A = 18;
         public int SD_OSLR_ST = 19;
         public int SD_OSLR_EC = 20;
         public int SD_OSSWCLR = 21;
         public int SD_OSLRKKC = 22;
         public int SD_OSIR_A = 23;
         public int SD_OSIUF_A = 24;
         public int SD_OSIUF_ST = 25;
         public int SD_OSIUF_EC = 26;
         public int SD_OSFULLPAYMENT_A = 27;
         public int SD_LRCOSINST_A = 28;
         public int SD_LRCOSIDP_A = 29;
         public int SD_SC_OS_CGST = 30;
         public int SD_SC_OS_SGST = 31;
         public int SD_NAA_OS_CGST = 32;
         public int SD_NAA_OS_SGST = 33;
         public int SD_LR_OS_CGST = 34;
         public int SD_LR_OS_SGST = 35;
         public int SD_INTREV_OS_CGST = 36;
         public int SD_INTREV_OS_SGST = 37;
         public int SD_SC_BASE = 38;
         public int SD_SC_SGSTAmount = 39;
         public int SD_SC_CGSTAmount = 40;
         public int SD_SC_ACCHEAD_C = 41;
         public int SD_SC_ACC_M = 42;
         public int SD_SC_FROM_D = 43;
         public int SD_SC_TO_D = 44;
         public int SD_SC_ACC_NO = 45;
         public int SD_SC_SGST_A = 46;
         public int SD_SC_CGST_A = 47;
         public int SD_SC_ACC_N = 48;
         public int SD_NAA_BASE = 49;
         public int SD_NAA_SGSTAmount = 50;
         public int SD_NAA_CGSTAmount = 51;
         public int SD_NAA_ACCHEAD_C = 52;
         public int SD_NAA_ACC_M = 53;
         public int SD_NAA_FROM_D = 54;
         public int SD_NAA_TO_D = 55;
         public int SD_NAA_ACC_NO = 56;
         public int SD_NAA_SGST_A = 57;
         public int SD_NAA_CGST_A = 58;
         public int SD_NAA_ACC_N = 59;
         public int SD_LR_BASE = 60;
         public int SD_LR_SGSTAmount = 61;
         public int SD_LR_CGSTAmount = 62;
         public int SD_LR_ACCHEAD_C = 63;
         public int SD_LR_ACC_M = 64;
         public int SD_LR_FROM_D = 65;
         public int SD_LR_TO_D = 66;
         public int SD_LR_ACC_NO = 67;
         public int SD_LR_SGST_A = 68;
         public int SD_LR_CGST_A = 69;
         public int SD_LR_ACC_N = 70;
         public int SD_INT_BASE = 71;
         public int SD_INT_SGSTAmount = 72;
         public int SD_INT_CGSTAmount = 73;
         public int SD_INT_ACCHEAD_C = 74;
         public int SD_INT_ACC_M = 75;
         public int SD_INT_FROM_D = 76;
         public int SD_INT_TO_D = 77;
         public int SD_INT_ACC_NO = 78;
         public int SD_INT_SGST_A = 79;
         public int SD_INT_CGST_A = 80;
         public int SD_INT_ACC_N = 81;
         public int ModifiedBy = 82;
         public int PSOPaymentDocument = 83;
         public int Remarks = 84;
         public int GSTNumber = 85;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateTransferModuleForSupplementaryDocument
      public class SPUpdateTransferModuleForSupplementaryDocument
      {
         public string SPName = "SPUpdateTransferModuleForSupplementaryDocument";
         public int ApplicationFormId = 0;
         public int SupplementaryDoc = 1;
         public int PTOPaymentDocuments = 2;
         public int NDCAccount = 3;
         public int NDCEngineering = 4;
         public int ModifiedBy = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateRoleMaster
      public class SPInsertUpdateRoleMaster
      {
         public string SPName = "SPInsertUpdateRoleMaster";
         public int RoleId = 0;
         public int Role = 1;
         public int UserId = 2;
         public int IsActive = 3;
         public int Operation = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateDrainageApplicationFormApplicantQuery
      public class SPUpdateDrainageApplicationFormApplicantQuery
      {
         public string SPName = "SPUpdateDrainageApplicationFormApplicantQuery";
         public int Operation = 0;
         public int ApplicationFormId = 1;
         public int QueryAnswerApplicantLine1 = 2;
         public int QueryAnswerApplicantLine2 = 3;
         public int QueryAnswerApplicantLine3 = 4;
         public int QueryAnswerApplicantLine4 = 5;
         public int QueryAnswerApplicantLine5 = 6;
         public int SignedApplicationFormDoc = 7;
         public int CCAfromGpcbDoc = 8;
         public int LicenseAgreementDoc = 9;
         public int PossessionReceiptDoc = 10;
         public int OCAletterDoc = 11;
         public int SignedGIDCDrainageRegulationsDoc = 12;
         public int ActionId = 13;
         public int ApplicantDocumentList = 14;
         public int ModifiedBy = 15;
         public int QueryDocumentXML = 16;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdatePaymentDetailsSubDivisionForBillDesk
      public class SPUpdatePaymentDetailsSubDivisionForBillDesk
      {
         public string SPName = "SPUpdatePaymentDetailsSubDivisionForBillDesk";
         public int MerchantId = 0;
         public int TxId = 1;
         public int TxRefNo = 2;
         public int BankRefNo = 3;
         public int TxAmount = 4;
         public int BankID = 5;
         public int CardBin = 6;
         public int TxnType = 7;
         public int CurrencyName = 8;
         public int ItemcOde = 9;
         public int securityType = 10;
         public int securityId = 11;
         public int surchargeAmount = 12;
         public int TxnDate = 13;
         public int TxStatus = 14;
         public int SettlementType = 15;
         public int ShortCode = 16;
         public int Additionalinfo2 = 17;
         public int Additionalinfo3 = 18;
         public int Additionalinfo4 = 19;
         public int Additionalinfo5 = 20;
         public int Additionalinfo6 = 21;
         public int Additionalinfo7 = 22;
         public int ErrorStatus = 23;
         public int ErrorDescription = 24;
         public int CheckSum = 25;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPValidateSaturdaySunday
      public class SPValidateSaturdaySunday
      {
         public string SPName = "SPValidateSaturdaySunday";
         public int Year = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region spBuildingCompletionReportDetail
      public class spBuildingCompletionReportDetail
      {
         public string SPName = "spBuildingCompletionReportDetail";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectUtilisedPercentageByConstitutionType
      public class SPSelectUtilisedPercentageByConstitutionType
      {
         public string SPName = "SPSelectUtilisedPercentageByConstitutionType";
         public int ConstitutionTypeId = 0;
         public int ConstitutionTypeIdTransferee = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferModuleDocumentTransactionByApplicationIdPublic05102016_TEMP
      public class SPSelectTransferModuleDocumentTransactionByApplicationIdPublic05102016_TEMP
      {
         public string SPName = "SPSelectTransferModuleDocumentTransactionByApplicationIdPublic05102016_TEMP";
         public int AplicationFormId = 0;
         public int ConstituteTypeTransferor = 1;
         public int ConstituteTypeTransferee = 2;
         public int DeathWIllType = 3;
         public int TrasferGSFC = 4;
         public int TrasferCoOperative = 5;
         public int IsIndustrial = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPaymentDetailsSubdivisionForTxId
      public class SPSelectPaymentDetailsSubdivisionForTxId
      {
         public string SPName = "SPSelectPaymentDetailsSubdivisionForTxId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectEstateMasterByEstate
      public class SPSelectEstateMasterByEstate
      {
         public string SPName = "SPSelectEstateMasterByEstate";
         public int Estate = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPCheckUniqueInvoiceNoForAmmalgamation
      public class SPCheckUniqueInvoiceNoForAmmalgamation
      {
         public string SPName = "SPCheckUniqueInvoiceNoForAmmalgamation";
         public int TxId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferModuleDetailsListForViewByApplicationFormId
      public class SPSelectTransferModuleDetailsListForViewByApplicationFormId
      {
         public string SPName = "SPSelectTransferModuleDetailsListForViewByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateDrainageApplicationForwardToApplicantForPayment
      public class SpUpdateDrainageApplicationForwardToApplicantForPayment
      {
         public string SPName = "SpUpdateDrainageApplicationForwardToApplicantForPayment";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int UserRoleId = 2;
         public int CurrentApplicationActionId = 3;
         public int CurrentApplicationStatusId = 4;
         public int AssignedRoleId = 5;
         public int AssignedActionId = 6;
         public int DemandNoteDocumentDEE = 7;
         public int AmountPayable = 8;
         public int PaymentRemarks = 9;
         public int ContributationCharges = 10;
         public int FormFees = 11;
         public int DRAINAGE_ACCHEAD_C = 12;
         public int DRAINAGE_ACC_M = 13;
         public int DRAINAGE_FROM_D = 14;
         public int DRAINAGE_TO_D = 15;
         public int DRAINAGE_ACC_NO = 16;
         public int DRAINAGE_SGST_A = 17;
         public int DRAINAGE_CGST_A = 18;
         public int DRAINAGE_ACC_N = 19;
         public int DRAINAGE_SGSTAmount = 20;
         public int DRAINAGE_CGSTAmount = 21;
         public int DRAINAGE_BaseAmount = 22;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdatePaymentDetailsFor2R17032017ForBillDesk
      public class SPUpdatePaymentDetailsFor2R17032017ForBillDesk
      {
         public string SPName = "SPUpdatePaymentDetailsFor2R17032017ForBillDesk";
         public int MerchnatId = 0;
         public int TxId = 1;
         public int TxRefNo = 2;
         public int BankRefNo = 3;
         public int TxAmount = 4;
         public int BankID = 5;
         public int CardBin = 6;
         public int TxnType = 7;
         public int CurrencyName = 8;
         public int ItemcOde = 9;
         public int securityType = 10;
         public int securityId = 11;
         public int surchargeAmount = 12;
         public int TxnDate = 13;
         public int TxStatus = 14;
         public int SettlementType = 15;
         public int ShortCode = 16;
         public int Additionalinfo2 = 17;
         public int Additionalinfo3 = 18;
         public int Additionalinfo4 = 19;
         public int Additionalinfo5 = 20;
         public int Additionalinfo6 = 21;
         public int Additionalinfo7 = 22;
         public int ErrorStatus = 23;
         public int ErrorDescription = 24;
         public int CheckSum = 25;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateSublettingModuleOtherQuery
      public class SPUpdateSublettingModuleOtherQuery
      {
         public string SPName = "SPUpdateSublettingModuleOtherQuery";
         public int ApplicationFormId = 0;
         public int Query = 1;
         public int QueryCreatedOn = 2;
         public int QueryReply = 3;
         public int Documents = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region M_SPGetTransferModuleDetailsById
      public class M_SPGetTransferModuleDetailsById
      {
         public string SPName = "M_SPGetTransferModuleDetailsById";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectEstateMasterByEstateId
      public class SPSelectEstateMasterByEstateId
      {
         public string SPName = "SPSelectEstateMasterByEstateId";
         public int EstateId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SendDBEmailwithTabularQuery
      public class SendDBEmailwithTabularQuery
      {
         public string SPName = "SendDBEmailwithTabularQuery";
         public int qSELECT = 0;
         public int fieldlist = 1;
         public int qFROM = 2;
         public int qWHERE = 3;
         public int qGroupBy = 4;
         public int qHaving = 5;
         public int qOrderBy = 6;
         public int recipients = 7;
         public int copy_recipients = 8;
         public int blind_copy_recipients = 9;
         public int subject = 10;
         public int Title = 11;
         public int SendEmailWithNoResults = 12;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSurrenderQueryDocument
      public class SPSelectSurrenderQueryDocument
      {
         public string SPName = "SPSelectSurrenderQueryDocument";
         public int AplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPTransferModuleInsertPTOConditions
      public class SPTransferModuleInsertPTOConditions
      {
         public string SPName = "SPTransferModuleInsertPTOConditions";
         public int ApplicationFormId = 0;
         public int DocumentXML = 1;
         public int CreatedBy = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectRoleMasterByRole
      public class SPSelectRoleMasterByRole
      {
         public string SPName = "SPSelectRoleMasterByRole";
         public int Role = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateDrainageApplicationReleaseConnection
      public class SpUpdateDrainageApplicationReleaseConnection
      {
         public string SPName = "SpUpdateDrainageApplicationReleaseConnection";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int UserRoleId = 2;
         public int CurrentApplicationActionId = 3;
         public int CurrentApplicationStatusId = 4;
         public int AssignedRoleId = 5;
         public int AssignedActionId = 6;
         public int OnlineFeesSubmissionReceipt = 7;
         public int SignedAgreementDocument = 8;
         public int Otherdocuments = 9;
         public int Remarks = 10;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSublettingModuleOtherQuery
      public class SPSelectSublettingModuleOtherQuery
      {
         public string SPName = "SPSelectSublettingModuleOtherQuery";
         public int ApplicationFormId = 0;
         public int AssignedRoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetPendingDayAtGIDCendFor2R
      public class SPGetPendingDayAtGIDCendFor2R
      {
         public string SPName = "SPGetPendingDayAtGIDCendFor2R";
         public int ReferenceNo = 0;
         public int Days = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertTransactionReferenceNoPaymentDetailsSubDivisionPSO
      public class SPInsertTransactionReferenceNoPaymentDetailsSubDivisionPSO
      {
         public string SPName = "SPInsertTransactionReferenceNoPaymentDetailsSubDivisionPSO";
         public int TxId = 0;
         public int ApplicationFormId = 1;
         public int PTOPayment = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPRMAceptRejectReport
      public class SPRMAceptRejectReport
      {
         public string SPName = "SPRMAceptRejectReport";
         public int RegionId = 0;
         public int FromDate = 1;
         public int ToDate = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectRoleMasterByRoleId
      public class SPSelectRoleMasterByRoleId
      {
         public string SPName = "SPSelectRoleMasterByRoleId";
         public int RoleId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubdivisionModuleOtherQuery
      public class SPSelectSubdivisionModuleOtherQuery
      {
         public string SPName = "SPSelectSubdivisionModuleOtherQuery";
         public int ApplicationFormId = 0;
         public int AssignedRoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateForwardDateNewTwoR25102016
      public class SPUpdateForwardDateNewTwoR25102016
      {
         public string SPName = "SPUpdateForwardDateNewTwoR25102016";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
         public int flag = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region M_SPUpdateTransferModule
      public class M_SPUpdateTransferModule
      {
         public string SPName = "M_SPUpdateTransferModule";
         public int ApplicationFormId = 0;
         public int RegionId = 1;
         public int EstateId = 2;
         public int PlotShedTypeId = 3;
         public int PlotShedNo = 4;
         public int PlotArea = 5;
         public int DateofAllotment = 6;
         public int TransferorConsititutionTypeId = 7;
         public int TransfereeConsititutionTypeId = 8;
         public int AlloteeName = 9;
         public int CreatedBy = 10;
         public int IsChemical = 11;
         public int ApplicantName = 12;
         public int ApplicantLandlineNo = 13;
         public int ApplicantMobileNo = 14;
         public int ApplicantEmailId = 15;
         public int ApplicantRelationUnit = 16;
         public int ApplicantIdentity = 17;
         public int IsTransferSubDivision = 18;
         public int IsAmalgamation = 19;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateTransferModulePTOPayment
      public class SPUpdateTransferModulePTOPayment
      {
         public string SPName = "SPUpdateTransferModulePTOPayment";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
         public int PTOPaymentDocuments = 2;
         public int IsTotal0 = 3;
         public int SupplementaryDoc = 4;
         public int NDCAccount = 5;
         public int NDCEngineering = 6;
         public int AccountDues = 7;
         public int WaterDues = 8;
         public int EngineeringDues = 9;
         public int DrainageDues = 10;
         public int OSINST_A = 11;
         public int OSIDPPI_A = 12;
         public int OSSC_A = 13;
         public int OSSC_ST = 14;
         public int OSSC_EC = 15;
         public int OSSWCSC = 16;
         public int OSSCKKC = 17;
         public int OSNAA_A = 18;
         public int OSNAA_ST = 19;
         public int OSNAA_EC = 20;
         public int OSSWCNAA = 21;
         public int OSNAAKKC = 22;
         public int OSLR_A = 23;
         public int OSLR_ST = 24;
         public int OSLR_EC = 25;
         public int OSSWCLR = 26;
         public int OSLRKKC = 27;
         public int OSIR_A = 28;
         public int OSIUF_A = 29;
         public int OSIUF_ST = 30;
         public int OSIUF_EC = 31;
         public int OSFULLPAYMENT_A = 32;
         public int Remark = 33;
         public int LRCOSINST_A = 34;
         public int LRCOSIDP_A = 35;
         public int REVINT_CSGST_OS = 36;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPApproveRejectSummary
      public class SPApproveRejectSummary
      {
         public string SPName = "SPApproveRejectSummary";
         public int RegionId = 0;
         public int ApplicationId = 1;
         public int Fromdate = 2;
         public int ToDate = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpTwoRDocumentApplicationRemarksHistory
      public class SpTwoRDocumentApplicationRemarksHistory
      {
         public string SPName = "SpTwoRDocumentApplicationRemarksHistory";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPTWORAPPLICATIONDETAILSREPORT09052017
      public class SPTWORAPPLICATIONDETAILSREPORT09052017
      {
         public string SPName = "SPTWORAPPLICATIONDETAILSREPORT09052017";
         public int REGIONID = 0;
         public int ACTIONID = 1;
         public int ActionType = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTwoRApplicationQueryListDetails
      public class SPSelectTwoRApplicationQueryListDetails
      {
         public string SPName = "SPSelectTwoRApplicationQueryListDetails";
         public int AssignedRoleId = 0;
         public int SearchValue = 1;
         public int SearchId = 2;
         public int RegionId = 3;
         public int UserId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSurrenderOtherQuery
      public class SPSelectSurrenderOtherQuery
      {
         public string SPName = "SPSelectSurrenderOtherQuery";
         public int ApplicationFormId = 0;
         public int AssignedRoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetPendingDayAtGIDCendForTransfer
      public class SPGetPendingDayAtGIDCendForTransfer
      {
         public string SPName = "SPGetPendingDayAtGIDCendForTransfer";
         public int ReferenceNo = 0;
         public int Days = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateSubdivisionModuleOtherQuery
      public class SPUpdateSubdivisionModuleOtherQuery
      {
         public string SPName = "SPUpdateSubdivisionModuleOtherQuery";
         public int ApplicationFormId = 0;
         public int Query = 1;
         public int QueryCreatedOn = 2;
         public int QueryReply = 3;
         public int Documents = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateTwoRApplicationFinalOutwardByAdmin
      public class SpUpdateTwoRApplicationFinalOutwardByAdmin
      {
         public string SPName = "SpUpdateTwoRApplicationFinalOutwardByAdmin";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int CurrentApplicationActionId = 2;
         public int OutWardNo = 3;
         public int OutwardDate = 4;
         public int Remarks = 5;
         public int NewActionId = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region M_SPUpdateTransferModule_FORFIRSTSECTION
      public class M_SPUpdateTransferModule_FORFIRSTSECTION
      {
         public string SPName = "M_SPUpdateTransferModule_FORFIRSTSECTION";
         public int ApplicationFormId = 0;
         public int RegionId = 1;
         public int EstateId = 2;
         public int PlotShedTypeId = 3;
         public int PlotShedNo = 4;
         public int PlotArea = 5;
         public int DateofAllotment = 6;
         public int TransferorConsititutionTypeId = 7;
         public int TransfereeConsititutionTypeId = 8;
         public int AlloteeName = 9;
         public int CreatedBy = 10;
         public int IsChemical = 11;
         public int ApplicantName = 12;
         public int ApplicantLandlineNo = 13;
         public int ApplicantMobileNo = 14;
         public int ApplicantEmailId = 15;
         public int ApplicantRelationUnit = 16;
         public int ApplicantIdentity = 17;
         public int IsTransferSubDivision = 18;
         public int IsAmalgamation = 19;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPCheckSEZApplication
      public class SPCheckSEZApplication
      {
         public string SPName = "SPCheckSEZApplication";
         public int Applicationformid = 0;
         public int TxId = 1;
         public int ActionId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteStatusMasterByStatusId
      public class SPDeleteStatusMasterByStatusId
      {
         public string SPName = "SPDeleteStatusMasterByStatusId";
         public int StatusId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPAppTransferInsert
      public class SPAppTransferInsert
      {
         public string SPName = "SPAppTransferInsert";
         public int ReferenceNo = 0;
         public int RegionId = 1;
         public int EstateId = 2;
         public int TypeOfPlotShed = 3;
         public int PlotShedNo = 4;
         public int PlotArea = 5;
         public int DateofAllotment = 6;
         public int NameofAllottee = 7;
         public int NameofIndividual = 8;
         public int Cin = 9;
         public int AuthorisedPerson = 10;
         public int ContactNo = 11;
         public int EmailId = 12;
         public int NameofIndividualNew = 13;
         public int CinNew = 14;
         public int AuthorisedPersonNew = 15;
         public int ContactNoNew = 16;
         public int EmailIdNew = 17;
         public int CreatedBy = 18;
         public int CreatedOn = 19;
         public int IsActive = 20;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferApplicationPaymentDetailByApplicationFormId
      public class SPSelectTransferApplicationPaymentDetailByApplicationFormId
      {
         public string SPName = "SPSelectTransferApplicationPaymentDetailByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region spDMSSearchFile
      public class spDMSSearchFile
      {
         public string SPName = "spDMSSearchFile";
         public int mode = 0;
         public int SearchBy = 1;
         public int Barcodeno = 2;
         public int EstateId = 3;
         public int RegionId = 4;
         public int PlottypeId = 5;
         public int PlotShedNo = 6;
         public int AllotteeName = 7;
         public int DocumentTypeId = 8;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPlotShedByPlotShedNoDetails17032017
      public class SPSelectPlotShedByPlotShedNoDetails17032017
      {
         public string SPName = "SPSelectPlotShedByPlotShedNoDetails17032017";
         public int PlotShedNo = 0;
         public int EstateId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertRecindmentAllotmentDate
      public class SPInsertRecindmentAllotmentDate
      {
         public string SPName = "SPInsertRecindmentAllotmentDate";
         public int ApplicationFormId = 0;
         public int ProcessType = 1;
         public int DocumentName = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region M_SPInsertTransferModule_FORFIRSTSECTION
      public class M_SPInsertTransferModule_FORFIRSTSECTION
      {
         public string SPName = "M_SPInsertTransferModule_FORFIRSTSECTION";
         public int RegionId = 0;
         public int EstateId = 1;
         public int PlotShedTypeId = 2;
         public int PlotShedNo = 3;
         public int PlotArea = 4;
         public int DateofAllotment = 5;
         public int TransferorConsititutionTypeId = 6;
         public int TransfereeConsititutionTypeId = 7;
         public int AlloteeName = 8;
         public int CreatedBy = 9;
         public int IsChemical = 10;
         public int ApplicantName = 11;
         public int ApplicantLandlineNo = 12;
         public int ApplicantMobileNo = 13;
         public int ApplicantEmailId = 14;
         public int ApplicantRelationUnit = 15;
         public int ApplicantIdentity = 16;
         public int IsTransferSubDivision = 17;
         public int IsAmalgamation = 18;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateStatusMaster
      public class SPInsertUpdateStatusMaster
      {
         public string SPName = "SPInsertUpdateStatusMaster";
         public int StatusId = 0;
         public int Status = 1;
         public int UserId = 2;
         public int IsActive = 3;
         public int Operation = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectAppTranForReferenceNo
      public class SPSelectAppTranForReferenceNo
      {
         public string SPName = "SPSelectAppTranForReferenceNo";
         public int EstateId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectRemarksHistoryByApplicationFormIdTwoR
      public class SPSelectRemarksHistoryByApplicationFormIdTwoR
      {
         public string SPName = "SPSelectRemarksHistoryByApplicationFormIdTwoR";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectBuildingCompletionForReferenceNo
      public class SPSelectBuildingCompletionForReferenceNo
      {
         public string SPName = "SPSelectBuildingCompletionForReferenceNo";
         public int EstateId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPlotShedNoAndPartyNameByEstateIdAndPlotTypeId
      public class SPSelectPlotShedNoAndPartyNameByEstateIdAndPlotTypeId
      {
         public string SPName = "SPSelectPlotShedNoAndPartyNameByEstateIdAndPlotTypeId";
         public int EstateId = 0;
         public int PlotTypeId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTwoRApplicationDocument
      public class SPSelectTwoRApplicationDocument
      {
         public string SPName = "SPSelectTwoRApplicationDocument";
         public int RoleId = 0;
         public int ApplicationFormId = 1;
         public int DocumentId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region BuildinPlanSummaryReport12052017
      public class BuildinPlanSummaryReport12052017
      {
         public string SPName = "BuildinPlanSummaryReport12052017";
         public int RegionId = 0;
         public int StatusId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPCheckUniqueReferenceNoForAppTran
      public class SPCheckUniqueReferenceNoForAppTran
      {
         public string SPName = "SPCheckUniqueReferenceNoForAppTran";
         public int ReferenceNo = 0;
         public int EstateId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectOracleRegionEstateIdByRegionEstateIdForAmalgamation
      public class SPSelectOracleRegionEstateIdByRegionEstateIdForAmalgamation
      {
         public string SPName = "SPSelectOracleRegionEstateIdByRegionEstateIdForAmalgamation";
         public int RegionId = 0;
         public int EstateId = 1;
         public int PlotTypeId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectCountryMasterByCountryId
      public class SPSelectCountryMasterByCountryId
      {
         public string SPName = "SPSelectCountryMasterByCountryId";
         public int CountryId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdatePaymentDetailsBuildingCompletionForBillDesk
      public class SPUpdatePaymentDetailsBuildingCompletionForBillDesk
      {
         public string SPName = "SPUpdatePaymentDetailsBuildingCompletionForBillDesk";
         public int MerchantId = 0;
         public int TxId = 1;
         public int TxRefNo = 2;
         public int BankRefNo = 3;
         public int TxAmount = 4;
         public int BankID = 5;
         public int CardBin = 6;
         public int TxnType = 7;
         public int CurrencyName = 8;
         public int ItemcOde = 9;
         public int securityType = 10;
         public int securityId = 11;
         public int surchargeAmount = 12;
         public int TxnDate = 13;
         public int TxStatus = 14;
         public int SettlementType = 15;
         public int ShortCode = 16;
         public int Additionalinfo2 = 17;
         public int Additionalinfo3 = 18;
         public int Additionalinfo4 = 19;
         public int Additionalinfo5 = 20;
         public int Additionalinfo6 = 21;
         public int Additionalinfo7 = 22;
         public int ErrorStatus = 23;
         public int ErrorDescription = 24;
         public int CheckSum = 25;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDelayNotification
      public class SPDelayNotification
      {
         public string SPName = "SPDelayNotification";
         public int RoleId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPCheckUniqueReferenceNoForBuildingCompletion
      public class SPCheckUniqueReferenceNoForBuildingCompletion
      {
         public string SPName = "SPCheckUniqueReferenceNoForBuildingCompletion";
         public int ReferenceNo = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateSurrenderOtherQuery
      public class SPUpdateSurrenderOtherQuery
      {
         public string SPName = "SPUpdateSurrenderOtherQuery";
         public int TransferModuleOtherQueryId = 0;
         public int QueryReply = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectStatusMasterByStatus
      public class SPSelectStatusMasterByStatus
      {
         public string SPName = "SPSelectStatusMasterByStatus";
         public int Status = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region Sp_InserUpdateSubdivisionDA
      public class Sp_InserUpdateSubdivisionDA
      {
         public string SPName = "Sp_InserUpdateSubdivisionDA";
         public int Mode = 0;
         public int ApplicationFormId = 1;
         public int IsProposedSubdivisionAccepted = 2;
         public int ProposedTransferAcceptedRejectionReason = 3;
         public int ProposedTransferAcceptedRejectionOtherReason = 4;
         public int IsPropertyUnderMoratoriumPeriod = 5;
         public int PossessionReceiptDate = 6;
         public int PriodOfMoratorium = 7;
         public int CompletionPropertyUnderMoratoriumPeriod = 8;
         public int IsPropertyUtilized = 9;
         public int IsTimeLimitExtensionGranted = 10;
         public int TimeLimitExtensionGrantedOrderDate = 11;
         public int TimeLimitExtensionGrantedUptoDate = 12;
         public int TimeLimitExtensionGrantedNUPenaltyDate = 13;
         public int IsSubdivisionProposalUnderExitPolicy = 14;
         public int IsUnitClosedAfterUtilization = 15;
         public int DateOfPartialUtilization = 16;
         public int UnitClosedClosureDate = 17;
         public int UnitClosedClosurePeriod = 18;
         public int IsSubdivisionFeeRecovered = 19;
         public int SDRecoveredDate = 20;
         public int SDRecoveredAmount = 21;
         public int ISNUPenaltyRecovered = 22;
         public int NURecoveredDate = 23;
         public int NURecoveredAmount = 24;
         public int IsProposedIsFormal = 25;
         public int IsCommercialPlot = 26;
         public int ConcessionRevert = 27;
         public int ConcessionInterest = 28;
         public int ClosurePenalty = 29;
         public int NUPenalty = 30;
         public int SubdivisionDAFees = 31;
         public int TotalPaybleAmount = 32;
         public int IsSubmitted = 33;
         public int CreatedBy = 34;
         public int IsAgreeAM = 35;
         public int RemarksAM = 36;
         public int IsAgreeRM = 37;
         public int RemarksRM = 38;
         public int IsTransferDone = 39;
         public int DateOfTransfer = 40;
         public int IsAgreeDM = 41;
         public int RemarksDM = 42;
         public int IsAgreeVCMD = 43;
         public int RemarksVCMD = 44;
         public int NU_SGSTAmount = 45;
         public int NU_CGSTAmount = 46;
         public int NU_ACCHEAD_C = 47;
         public int NU_ACC_M = 48;
         public int NU_FROM_D = 49;
         public int NU_TO_D = 50;
         public int NU_ACC_NO = 51;
         public int NU_SGST_A = 52;
         public int NU_CGST_A = 53;
         public int NU_ACC_N = 54;
         public int SD_SGSTAmount = 55;
         public int SD_CGSTAmount = 56;
         public int SD_ACCHEAD_C = 57;
         public int SD_ACC_M = 58;
         public int SD_FROM_D = 59;
         public int SD_TO_D = 60;
         public int SD_ACC_NO = 61;
         public int SD_SGST_A = 62;
         public int SD_CGST_A = 63;
         public int SD_ACC_N = 64;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPaymentDetailsForTxId
      public class SPSelectPaymentDetailsForTxId
      {
         public string SPName = "SPSelectPaymentDetailsForTxId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectCountryMasterByCountry
      public class SPSelectCountryMasterByCountry
      {
         public string SPName = "SPSelectCountryMasterByCountry";
         public int CountryName = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdatePaymentDetailsPlinthCertificationForBillDesk
      public class SPUpdatePaymentDetailsPlinthCertificationForBillDesk
      {
         public string SPName = "SPUpdatePaymentDetailsPlinthCertificationForBillDesk";
         public int MerchantId = 0;
         public int TxId = 1;
         public int TxRefNo = 2;
         public int BankRefNo = 3;
         public int TxAmount = 4;
         public int BankID = 5;
         public int CardBin = 6;
         public int TxnType = 7;
         public int CurrencyName = 8;
         public int ItemcOde = 9;
         public int securityType = 10;
         public int securityId = 11;
         public int surchargeAmount = 12;
         public int TxnDate = 13;
         public int TxStatus = 14;
         public int SettlementType = 15;
         public int ShortCode = 16;
         public int Additionalinfo2 = 17;
         public int Additionalinfo3 = 18;
         public int Additionalinfo4 = 19;
         public int Additionalinfo5 = 20;
         public int Additionalinfo6 = 21;
         public int Additionalinfo7 = 22;
         public int ErrorStatus = 23;
         public int ErrorDescription = 24;
         public int CheckSum = 25;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectReportHeaderWithAdress
      public class SPSelectReportHeaderWithAdress
      {
         public string SPName = "SPSelectReportHeaderWithAdress";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectROUModuleHOFlowUserByBranchAndRole
      public class SPSelectROUModuleHOFlowUserByBranchAndRole
      {
         public string SPName = "SPSelectROUModuleHOFlowUserByBranchAndRole";
         public int BranchId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUserDigitalSignDetails
      public class SPInsertUserDigitalSignDetails
      {
         public string SPName = "SPInsertUserDigitalSignDetails";
         public int UserId = 0;
         public int EmailId = 1;
         public int RoleId = 2;
         public int DSHash = 3;
         public int DSVersion = 4;
         public int DSSerialNumber = 5;
         public int DSIssuer = 6;
         public int DSSubject = 7;
         public int DSPublicKey = 8;
         public int DSValidFrom = 9;
         public int DSValidTo = 10;
         public int DSCnName = 11;
         public int DSThumbPrint = 12;
         public int DSPubKeyLen = 13;
         public int DSSubjectAlternativeName = 14;
         public int DSCrtString = 15;
         public int DSServerDate = 16;
         public int EmailIDBase64 = 17;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectAmmalgamationApplicationPaymentDetailByTxId
      public class SPSelectAmmalgamationApplicationPaymentDetailByTxId
      {
         public string SPName = "SPSelectAmmalgamationApplicationPaymentDetailByTxId";
         public int TxId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectRegionMasterByEstateId
      public class SPSelectRegionMasterByEstateId
      {
         public string SPName = "SPSelectRegionMasterByEstateId";
         public int EstateId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateROUModuleforGeneratePO_OutwardNo
      public class SpUpdateROUModuleforGeneratePO_OutwardNo
      {
         public string SPName = "SpUpdateROUModuleforGeneratePO_OutwardNo";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteCountryMasterByCountryId
      public class SPDeleteCountryMasterByCountryId
      {
         public string SPName = "SPDeleteCountryMasterByCountryId";
         public int CountryId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdatePaymentDetailsAmalgamationForBillDesk
      public class SPUpdatePaymentDetailsAmalgamationForBillDesk
      {
         public string SPName = "SPUpdatePaymentDetailsAmalgamationForBillDesk";
         public int MerchantID = 0;
         public int TxId = 1;
         public int TxRefNo = 2;
         public int BankRefNo = 3;
         public int TxAmount = 4;
         public int BankID = 5;
         public int CardBin = 6;
         public int TxnType = 7;
         public int CurrencyName = 8;
         public int ItemcOde = 9;
         public int securityType = 10;
         public int securityId = 11;
         public int surchargeAmount = 12;
         public int TxnDate = 13;
         public int TxStatus = 14;
         public int SettlementType = 15;
         public int ShortCode = 16;
         public int Additionalinfo2 = 17;
         public int Additionalinfo3 = 18;
         public int Additionalinfo4 = 19;
         public int Additionalinfo5 = 20;
         public int Additionalinfo6 = 21;
         public int Additionalinfo7 = 22;
         public int ErrorStatus = 23;
         public int ErrorDescription = 24;
         public int CheckSum = 25;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateROUModuleApplicationInManagerHOLoop
      public class SpUpdateROUModuleApplicationInManagerHOLoop
      {
         public string SPName = "SpUpdateROUModuleApplicationInManagerHOLoop";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int NewAssinedActionId = 2;
         public int AssignedRoleId = 3;
         public int DepartmentId = 4;
         public int Remarks = 5;
         public int HOAdditionalDocs = 6;
         public int BranchUserId = 7;
         public int CurrentBranchId = 8;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPaymentRecieptDetailsAmmalagamation
      public class SPSelectPaymentRecieptDetailsAmmalagamation
      {
         public string SPName = "SPSelectPaymentRecieptDetailsAmmalagamation";
         public int txnId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpSelectSublettingQueryCount
      public class SpSelectSublettingQueryCount
      {
         public string SPName = "SpSelectSublettingQueryCount";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SP_Invoice
      public class SP_Invoice
      {
         public string SPName = "SP_Invoice";
         public int ApplicationId = 0;
         public int FromDate = 1;
         public int ToDate = 2;
         public int InvoiceType = 3;
         public int UserId = 4;
         public int RoleId = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateCountryMaster
      public class SPInsertUpdateCountryMaster
      {
         public string SPName = "SPInsertUpdateCountryMaster";
         public int TwoRApplicationDocumentId = 0;
         public int ApplicationFormId = 1;
         public int AssignedRoleId = 2;
         public int DocumentId = 3;
         public int Action = 4;
         public int CreatedBy = 5;
         public int Operation = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateBuildPlanApprovalApplicationByAdmin
      public class SPUpdateBuildPlanApprovalApplicationByAdmin
      {
         public string SPName = "SPUpdateBuildPlanApprovalApplicationByAdmin";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int UserRoleId = 2;
         public int CurrentApplicationActionId = 3;
         public int CurrentApplicationStatusId = 4;
         public int AssignedRoleId = 5;
         public int AssignedActionId = 6;
         public int AssignedStatusId = 7;
         public int OCALetterDEE = 8;
         public int LicenseAgreementDEE = 9;
         public int PossessionReceiptDEE = 10;
         public int DrawingsDEE = 11;
         public int TransferOrderDEE = 12;
         public int ExtensionLetterDEE = 13;
         public int GPBCDEE = 14;
         public int OCALetterPB = 15;
         public int LicenseAgreementPB = 16;
         public int PossessionReceiptPB = 17;
         public int DrawingsPB = 18;
         public int TransferOrderPB = 19;
         public int ExtensionLetterPB = 20;
         public int GPBCPB = 21;
         public int OCALetterXEN = 22;
         public int LicenseAgreementXEN = 23;
         public int PossessionReceiptXEN = 24;
         public int DrawingsXEN = 25;
         public int TransferOrderXEN = 26;
         public int ExtensionLetterXEN = 27;
         public int GPBCXEN = 28;
         public int AttachmentDEE = 29;
         public int AttachmentPB = 30;
         public int Attachment = 31;
         public int Remarks = 32;
         public int QueryLineXEN1 = 33;
         public int QueryLineXEN2 = 34;
         public int QueryLineXEN3 = 35;
         public int QueryLineXEN4 = 36;
         public int QueryLineXEN5 = 37;
         public int QueryAnswerDEELine1 = 38;
         public int QueryAnswerDEELine2 = 39;
         public int QueryAnswerDEELine3 = 40;
         public int QueryAnswerDEELine4 = 41;
         public int QueryAnswerDEELine5 = 42;
         public int QueryAnswerPBLine1 = 43;
         public int QueryAnswerPBLine2 = 44;
         public int QueryAnswerPBLine3 = 45;
         public int QueryAnswerPBLine4 = 46;
         public int QueryAnswerPBLine5 = 47;
         public int SketchDEE = 48;
         public int SketchPB = 49;
         public int SketchXEN = 50;
         public int AttachmentDocDEE = 51;
         public int AttachmentDocPB = 52;
         public int AttachmentDocXEN = 53;
         public int AdminCharges = 54;
         public int AttachmentDocSATP = 55;
         public int SubmissionOfApprovalPlanDEE = 56;
         public int AsbuiltDrawingPlanDEE = 57;
         public int SubmissionOfApprovalPlanPB = 58;
         public int AsbuiltDrawingPlanPB = 59;
         public int SubmissionOfApprovalPlanXEN = 60;
         public int AsbuiltDrawingPlanXEN = 61;
         public int SCRUTINYFEE = 62;
         public int PENALTYFORNONVIOLATIVE = 63;
         public int PENALTYFORVIOLATIVE = 64;
         public int LABOURCESS = 65;
         public int TREEPLANTATION = 66;
         public int PLANAPPROVALFEE = 67;
         public int SERVICETAX = 68;
         public int SWATCHBHARATCESS = 69;
         public int KRISHIKALYANCESS = 70;
         public int IMPACTFEE = 71;
         public int FSIVIOLATION = 72;
         public int DRAINAGECESS = 73;
         public int PARKINGDEFICITPENALTY = 74;
         public int SANITATIONDEFICITPENALTY = 75;
         public int SCRUTINYFEE_SGST = 76;
         public int SCRUTINYFEE_CGST = 77;
         public int SCRUTINYFEE_ACCHEAD_C = 78;
         public int SCRUTINYFEE_ACC_M = 79;
         public int SCRUTINYFEE_FROM_D = 80;
         public int SCRUTINYFEE_TO_D = 81;
         public int SCRUTINYFEE_SGST_A = 82;
         public int SCRUTINYFEE_CGST_A = 83;
         public int PENALTYFORNONVIOLATIVE_SGST = 84;
         public int PENALTYFORNONVIOLATIVE_CGST = 85;
         public int PENALTYFORNONVIOLATIVE_ACCHEAD_C = 86;
         public int PENALTYFORNONVIOLATIVE_ACC_M = 87;
         public int PENALTYFORNONVIOLATIVE_FROM_D = 88;
         public int PENALTYFORNONVIOLATIVE_TO_D = 89;
         public int PENALTYFORNONVIOLATIVE_SGST_A = 90;
         public int PENALTYFORNONVIOLATIVE_CGST_A = 91;
         public int PENALTYFORVIOLATIVE_SGST = 92;
         public int PENALTYFORVIOLATIVE_CGST = 93;
         public int PENALTYFORVIOLATIVE_ACCHEAD_C = 94;
         public int PENALTYFORVIOLATIVE_ACC_M = 95;
         public int PENALTYFORVIOLATIVE_FROM_D = 96;
         public int PENALTYFORVIOLATIVE_TO_D = 97;
         public int PENALTYFORVIOLATIVE_SGST_A = 98;
         public int PENALTYFORVIOLATIVE_CGST_A = 99;
         public int LABOURCESS_SGST = 100;
         public int LABOURCESS_CGST = 101;
         public int LABOURCESS_ACCHEAD_C = 102;
         public int LABOURCESS_ACC_M = 103;
         public int LABOURCESS_FROM_D = 104;
         public int LABOURCESS_TO_D = 105;
         public int LABOURCESS_SGST_A = 106;
         public int LABOURCESS_CGST_A = 107;
         public int TREEPLANTATION_SGST = 108;
         public int TREEPLANTATION_CGST = 109;
         public int TREEPLANTATION_ACCHEAD_C = 110;
         public int TREEPLANTATION_ACC_M = 111;
         public int TREEPLANTATION_FROM_D = 112;
         public int TREEPLANTATION_TO_D = 113;
         public int TREEPLANTATION_SGST_A = 114;
         public int TREEPLANTATION_CGST_A = 115;
         public int PLANAPPROVALFEE_SGST = 116;
         public int PLANAPPROVALFEE_CGST = 117;
         public int PLANAPPROVALFEE_ACCHEAD_C = 118;
         public int PLANAPPROVALFEE_ACC_M = 119;
         public int PLANAPPROVALFEE_FROM_D = 120;
         public int PLANAPPROVALFEE_TO_D = 121;
         public int PLANAPPROVALFEE_SGST_A = 122;
         public int PLANAPPROVALFEE_CGST_A = 123;
         public int IMPACTFEE_SGST = 124;
         public int IMPACTFEE_CGST = 125;
         public int IMPACTFEE_ACCHEAD_C = 126;
         public int IMPACTFEE_ACC_M = 127;
         public int IMPACTFEE_FROM_D = 128;
         public int IMPACTFEE_TO_D = 129;
         public int IMPACTFEE_SGST_A = 130;
         public int IMPACTFEE_CGST_A = 131;
         public int FSIVIOLATION_SGST = 132;
         public int FSIVIOLATION_CGST = 133;
         public int FSIVIOLATION_ACCHEAD_C = 134;
         public int FSIVIOLATION_ACC_M = 135;
         public int FSIVIOLATION_FROM_D = 136;
         public int FSIVIOLATION_TO_D = 137;
         public int FSIVIOLATION_SGST_A = 138;
         public int FSIVIOLATION_CGST_A = 139;
         public int DRAINAGECESS_SGST = 140;
         public int DRAINAGECESS_CGST = 141;
         public int DRAINAGECESS_ACCHEAD_C = 142;
         public int DRAINAGECESS_ACC_M = 143;
         public int DRAINAGECESS_FROM_D = 144;
         public int DRAINAGECESS_TO_D = 145;
         public int DRAINAGECESS_SGST_A = 146;
         public int DRAINAGECESS_CGST_A = 147;
         public int SANITATIONDEFICITPENALTY_SGST = 148;
         public int SANITATIONDEFICITPENALTY_CGST = 149;
         public int SANITATIONDEFICITPENALTY_ACCHEAD_C = 150;
         public int SANITATIONDEFICITPENALTY_ACC_M = 151;
         public int SANITATIONDEFICITPENALTY_FROM_D = 152;
         public int SANITATIONDEFICITPENALTY_TO_D = 153;
         public int SANITATIONDEFICITPENALTY_SGST_A = 154;
         public int SANITATIONDEFICITPENALTY_CGST_A = 155;
         public int PARKINGDEFICITPENALTY_SGST = 156;
         public int PARKINGDEFICITPENALTY_CGST = 157;
         public int PARKINGDEFICITPENALTY_ACCHEAD_C = 158;
         public int PARKINGDEFICITPENALTY_ACC_M = 159;
         public int PARKINGDEFICITPENALTY_FROM_D = 160;
         public int PARKINGDEFICITPENALTY_TO_D = 161;
         public int PARKINGDEFICITPENALTY_SGST_A = 162;
         public int PARKINGDEFICITPENALTY_CGST_A = 163;
         public int SERVICEAMENITIES_SGST = 164;
         public int SERVICEAMENITIES_CGST = 165;
         public int SERVICEAMENITIES_ACCHEAD_C = 166;
         public int SERVICEAMENITIES_ACC_M = 167;
         public int SERVICEAMENITIES_FROM_D = 168;
         public int SERVICEAMENITIES_TO_D = 169;
         public int SERVICEAMENITIES_SGST_A = 170;
         public int SERVICEAMENITIES_CGST_A = 171;
         public int SERVICEAMENITIES = 172;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdatePaymentDetailsForBillDesk
      public class SPUpdatePaymentDetailsForBillDesk
      {
         public string SPName = "SPUpdatePaymentDetailsForBillDesk";
         public int MerchantId = 0;
         public int TxId = 1;
         public int TxRefNo = 2;
         public int BankRefNo = 3;
         public int TxAmount = 4;
         public int BankID = 5;
         public int CardBin = 6;
         public int TxnType = 7;
         public int CurrencyName = 8;
         public int ItemcOde = 9;
         public int securityType = 10;
         public int securityId = 11;
         public int surchargeAmount = 12;
         public int TxnDate = 13;
         public int TxStatus = 14;
         public int SettlementType = 15;
         public int ShortCode = 16;
         public int Additionalinfo2 = 17;
         public int Additionalinfo3 = 18;
         public int Additionalinfo4 = 19;
         public int Additionalinfo5 = 20;
         public int Additionalinfo6 = 21;
         public int Additionalinfo7 = 22;
         public int ErrorStatus = 23;
         public int ErrorDescription = 24;
         public int CheckSum = 25;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPTransferApplicationSummaryReportNew_old
      public class SPTransferApplicationSummaryReportNew_old
      {
         public string SPName = "SPTransferApplicationSummaryReportNew_old";
         public int BeforeAfter = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectGrievanceApplication
      public class SPSelectGrievanceApplication
      {
         public string SPName = "SPSelectGrievanceApplication";
         public int AssignedRoleId = 0;
         public int UserId = 1;
         public int RegionId = 2;
         public int Number = 3;
         public int SubjectId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPAppTransferSelectPlotShedNoByEstateIdAndPlotTypeId
      public class SPAppTransferSelectPlotShedNoByEstateIdAndPlotTypeId
      {
         public string SPName = "SPAppTransferSelectPlotShedNoByEstateIdAndPlotTypeId";
         public int EstateId = 0;
         public int PlotTypeId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateTransferModuleAdminCharges
      public class SPUpdateTransferModuleAdminCharges
      {
         public string SPName = "SPUpdateTransferModuleAdminCharges";
         public int ApplicationFormId = 0;
         public int AdminCharges = 1;
         public int AdminPlotAreaCharge = 2;
         public int AdminKKC = 3;
         public int AdminSBC = 4;
         public int AdminST = 5;
         public int RegionId = 6;
         public int EstateId = 7;
         public int TypeOfPlotShed = 8;
         public int PlotShedNo = 9;
         public int PlotArea = 10;
         public int DateofAllotment = 11;
         public int ConstitutionTypeId = 12;
         public int ConstitutionTypeIdTransferee = 13;
         public int IsChemical = 14;
         public int NameofAllottee = 15;
         public int PartyCode = 16;
         public int ACCHEAD_C = 17;
         public int ACC_M = 18;
         public int FROM_D = 19;
         public int TO_D = 20;
         public int ACC_NO = 21;
         public int SGST_A = 22;
         public int CGST_A = 23;
         public int ACC_N = 24;
         public int SGST = 25;
         public int CGST = 26;
         public int GSTNo = 27;
         public int IsSEZ = 28;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdatePaymentDetailsRouForBillDesk
      public class SPUpdatePaymentDetailsRouForBillDesk
      {
         public string SPName = "SPUpdatePaymentDetailsRouForBillDesk";
         public int MerchantId = 0;
         public int TxId = 1;
         public int TxRefNo = 2;
         public int BankRefNo = 3;
         public int TxAmount = 4;
         public int BankID = 5;
         public int CardBin = 6;
         public int TxnType = 7;
         public int CurrencyName = 8;
         public int ItemcOde = 9;
         public int securityType = 10;
         public int securityId = 11;
         public int surchargeAmount = 12;
         public int TxnDate = 13;
         public int TxStatus = 14;
         public int SettlementType = 15;
         public int ShortCode = 16;
         public int Additionalinfo2 = 17;
         public int Additionalinfo3 = 18;
         public int Additionalinfo4 = 19;
         public int Additionalinfo5 = 20;
         public int Additionalinfo6 = 21;
         public int Additionalinfo7 = 22;
         public int ErrorStatus = 23;
         public int ErrorDescription = 24;
         public int CheckSum = 25;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateAmalgamationModuleOtherQuery
      public class SPUpdateAmalgamationModuleOtherQuery
      {
         public string SPName = "SPUpdateAmalgamationModuleOtherQuery";
         public int ApplicationFormId = 0;
         public int Query = 1;
         public int QueryCreatedOn = 2;
         public int QueryReply = 3;
         public int Documents = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectChecksumKey
      public class SPSelectChecksumKey
      {
         public string SPName = "SPSelectChecksumKey";
         public int MerchantID = 0;
         public int Mode = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPTransferApplicationDetailsReport
      public class SPTransferApplicationDetailsReport
      {
         public string SPName = "SPTransferApplicationDetailsReport";
         public int RegionId = 0;
         public int ActionId = 1;
         public int CommandName = 2;
         public int IsApplicationReceived = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateTwoRApplicationDocument
      public class SPInsertUpdateTwoRApplicationDocument
      {
         public string SPName = "SPInsertUpdateTwoRApplicationDocument";
         public int TwoRApplicationDocumentId = 0;
         public int ApplicationFormId = 1;
         public int AssignedRoleId = 2;
         public int DocumentId = 3;
         public int ApplicationId = 4;
         public int CreatedBy = 5;
         public int Action = 6;
         public int Operation = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPCheckDEEEstateAllow
      public class SPCheckDEEEstateAllow
      {
         public string SPName = "SPCheckDEEEstateAllow";
         public int EstateId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectROUModuleFormalReport
      public class SPSelectROUModuleFormalReport
      {
         public string SPName = "SPSelectROUModuleFormalReport";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectStatusMasterByStatusId
      public class SPSelectStatusMasterByStatusId
      {
         public string SPName = "SPSelectStatusMasterByStatusId";
         public int StatusId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectAmalgamationModuleOtherQuery
      public class SPSelectAmalgamationModuleOtherQuery
      {
         public string SPName = "SPSelectAmalgamationModuleOtherQuery";
         public int ApplicationFormId = 0;
         public int AssignedRoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region GetAmalgationSummaryReportbyStatusforAllRegion
      public class GetAmalgationSummaryReportbyStatusforAllRegion
      {
         public string SPName = "GetAmalgationSummaryReportbyStatusforAllRegion";
         public int ApplicationStatusId = 0;
         public int Flag = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertSurrenderOtherQuery
      public class SPInsertSurrenderOtherQuery
      {
         public string SPName = "SPInsertSurrenderOtherQuery";
         public int ApplicationFormId = 0;
         public int ActionId = 1;
         public int AssignedRoleId = 2;
         public int Query = 3;
         public int QueryReply = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSurrenderInvoiceForCancel
      public class SPSelectSurrenderInvoiceForCancel
      {
         public string SPName = "SPSelectSurrenderInvoiceForCancel";
         public int ApplicationFormId = 0;
         public int UserId = 1;
         public int TxId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateROUModuleforGenerateFO_OutwardNo
      public class SpUpdateROUModuleforGenerateFO_OutwardNo
      {
         public string SPName = "SpUpdateROUModuleforGenerateFO_OutwardNo";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdatePaymentDetailsSubLettingForBillDesk
      public class SPUpdatePaymentDetailsSubLettingForBillDesk
      {
         public string SPName = "SPUpdatePaymentDetailsSubLettingForBillDesk";
         public int MerchantId = 0;
         public int TxId = 1;
         public int TxRefNo = 2;
         public int BankRefNo = 3;
         public int TxAmount = 4;
         public int BankID = 5;
         public int CardBin = 6;
         public int TxnType = 7;
         public int CurrencyName = 8;
         public int ItemcOde = 9;
         public int securityType = 10;
         public int securityId = 11;
         public int surchargeAmount = 12;
         public int TxnDate = 13;
         public int TxStatus = 14;
         public int SettlementType = 15;
         public int ShortCode = 16;
         public int Additionalinfo2 = 17;
         public int Additionalinfo3 = 18;
         public int Additionalinfo4 = 19;
         public int Additionalinfo5 = 20;
         public int Additionalinfo6 = 21;
         public int Additionalinfo7 = 22;
         public int ErrorStatus = 23;
         public int ErrorDescription = 24;
         public int CheckSum = 25;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertInvoiceForDivision
      public class SPInsertInvoiceForDivision
      {
         public string SPName = "SPInsertInvoiceForDivision";
         public int ApplicationId = 0;
         public int ApplicationFormId = 1;
         public int CreatedBy = 2;
         public int DivisionId = 3;
         public int TxId = 4;
         public int TxRefNo = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectCRReportByUserIdNew
      public class SPSelectCRReportByUserIdNew
      {
         public string SPName = "SPSelectCRReportByUserIdNew";
         public int EmployeeCode = 0;
         public int Region = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region GetAmalgationSummaryReportbyStatus
      public class GetAmalgationSummaryReportbyStatus
      {
         public string SPName = "GetAmalgationSummaryReportbyStatus";
         public int RegionId = 0;
         public int ApplicationStatusId = 1;
         public int Flag = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertSignPDF
      public class SPInsertSignPDF
      {
         public string SPName = "SPInsertSignPDF";
         public int ApplicationFormId = 0;
         public int signPDFFileBase64 = 1;
         public int UserId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDAForwardToAMTwoRApplication
      public class SPDAForwardToAMTwoRApplication
      {
         public string SPName = "SPDAForwardToAMTwoRApplication";
         public int ApplicationFormId = 0;
         public int AssignedRoleId = 1;
         public int ModifiedBy = 2;
         public int BackwardRemark = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateTwoRApplicationModulePlotDetailsPaymentDone
      public class SPUpdateTwoRApplicationModulePlotDetailsPaymentDone
      {
         public string SPName = "SPUpdateTwoRApplicationModulePlotDetailsPaymentDone";
         public int ApplicationFormId = 0;
         public int PartyCode = 1;
         public int PlotDeedDate = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectAmalgamationModuleDetailsListForViewByApplicationFormId
      public class SPSelectAmalgamationModuleDetailsListForViewByApplicationFormId
      {
         public string SPName = "SPSelectAmalgamationModuleDetailsListForViewByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region InsertSMSLog
      public class InsertSMSLog
      {
         public string SPName = "InsertSMSLog";
         public int MobileNo = 0;
         public int MessageBody = 1;
         public int MessageId = 2;
         public int ApplicationFormId = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectApplicantUserMasterByUserId21042017
      public class SPSelectApplicantUserMasterByUserId21042017
      {
         public string SPName = "SPSelectApplicantUserMasterByUserId21042017";
         public int UserId = 0;
         public int Password = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSurrenderHOFlowUserByBranchAndRole
      public class SPSelectSurrenderHOFlowUserByBranchAndRole
      {
         public string SPName = "SPSelectSurrenderHOFlowUserByBranchAndRole";
         public int BranchId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSurrenderInvoice
      public class SPSelectSurrenderInvoice
      {
         public string SPName = "SPSelectSurrenderInvoice";
         public int ApplicationFormId = 0;
         public int UserId = 1;
         public int TxId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetGrievanceSubjectWiseSummary
      public class SPGetGrievanceSubjectWiseSummary
      {
         public string SPName = "SPGetGrievanceSubjectWiseSummary";
         public int RoleID = 0;
         public int UserId = 1;
         public int RegionId = 2;
         public int Department = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteStateMasterByStateId
      public class SPDeleteStateMasterByStateId
      {
         public string SPName = "SPDeleteStateMasterByStateId";
         public int StateId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateOraclePlotShedNumber
      public class SPInsertUpdateOraclePlotShedNumber
      {
         public string SPName = "SPInsertUpdateOraclePlotShedNumber";
         public int OraPlotShedNo = 0;
         public int OraPlotType = 1;
         public int OraPlotCode = 2;
         public int OraPlotArea = 3;
         public int OraAllotmentDate = 4;
         public int OraEsateName = 5;
         public int OraEstateCode = 6;
         public int OraPartyName = 7;
         public int OraOldPlotNo = 8;
         public int OraRegionName = 9;
         public int OraRegionCode = 10;
         public int OraAmalgation = 11;
         public int OraCreatedDate = 12;
         public int OraUpdateDate = 13;
         public int OraPartyCode = 14;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpSelectAmalgamationQueryCount
      public class SpSelectAmalgamationQueryCount
      {
         public string SPName = "SpSelectAmalgamationQueryCount";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region GetAmalgamationReportforfooterbyStatus
      public class GetAmalgamationReportforfooterbyStatus
      {
         public string SPName = "GetAmalgamationReportforfooterbyStatus";
         public int ApplicationStatusId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectApplicationPaymentDetailByApplicationFormId
      public class SPSelectApplicationPaymentDetailByApplicationFormId
      {
         public string SPName = "SPSelectApplicationPaymentDetailByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetGrievanceSubjectWiseSummaryDetails
      public class SPGetGrievanceSubjectWiseSummaryDetails
      {
         public string SPName = "SPGetGrievanceSubjectWiseSummaryDetails";
         public int RoleID = 0;
         public int UserId = 1;
         public int RegionId = 2;
         public int Department = 3;
         public int Flag = 4;
         public int SubjectId = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetPendingDayFromLastActionAtGIDCendForSublettingModule
      public class SPGetPendingDayFromLastActionAtGIDCendForSublettingModule
      {
         public string SPName = "SPGetPendingDayFromLastActionAtGIDCendForSublettingModule";
         public int ApplicationFormId = 0;
         public int Days = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPBuildinPlanMISDetailsReportD2
      public class SPBuildinPlanMISDetailsReportD2
      {
         public string SPName = "SPBuildinPlanMISDetailsReportD2";
         public int Referenceno = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateBranchMaster
      public class SPInsertUpdateBranchMaster
      {
         public string SPName = "SPInsertUpdateBranchMaster";
         public int BranchId = 0;
         public int Branchcode = 1;
         public int BranchName = 2;
         public int IsActive = 3;
         public int Operation = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTwoRModulePlotDetailsAlloteeName
      public class SPSelectTwoRModulePlotDetailsAlloteeName
      {
         public string SPName = "SPSelectTwoRModulePlotDetailsAlloteeName";
         public int ApplicationFormId = 0;
         public int PartyCode = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region GetAmalgamationReportforfooterbyStatusandRegion
      public class GetAmalgamationReportforfooterbyStatusandRegion
      {
         public string SPName = "GetAmalgamationReportforfooterbyStatusandRegion";
         public int ApplicationStatusId = 0;
         public int RegionId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPTransferApplicationDetailsReportFooter
      public class SPTransferApplicationDetailsReportFooter
      {
         public string SPName = "SPTransferApplicationDetailsReportFooter";
         public int ACTIONID = 0;
         public int ActionType = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectEmailIdOfAODEE
      public class SPSelectEmailIdOfAODEE
      {
         public string SPName = "SPSelectEmailIdOfAODEE";
         public int UserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTwoRApplicationDemandDraftForMailByApplicationFormId
      public class SPSelectTwoRApplicationDemandDraftForMailByApplicationFormId
      {
         public string SPName = "SPSelectTwoRApplicationDemandDraftForMailByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateTwoRApplicationByAdminForPreview
      public class SpUpdateTwoRApplicationByAdminForPreview
      {
         public string SPName = "SpUpdateTwoRApplicationByAdminForPreview";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int CurrentApplicationActionId = 2;
         public int NewAssinedActionId = 3;
         public int DocumentXML = 4;
         public int Remarks = 5;
         public int IsCollatral = 6;
         public int SurveyNo = 7;
         public int Manufacturing = 8;
         public int FinancialInstitutionsXML = 9;
         public int letterNo = 10;
         public int LetterDate = 11;
         public int CityName = 12;
         public int TalukaName = 13;
         public int DistrictName = 14;
         public int WardNos = 15;
         public int IsLoanTakenFromMultipleBank = 16;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpSurrenderApplicationRemarksHistoryForApplicant
      public class SpSurrenderApplicationRemarksHistoryForApplicant
      {
         public string SPName = "SpSurrenderApplicationRemarksHistoryForApplicant";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPLeaseAPPLICATIONDETAILSREPORT
      public class SPLeaseAPPLICATIONDETAILSREPORT
      {
         public string SPName = "SPLeaseAPPLICATIONDETAILSREPORT";
         public int REGIONID = 0;
         public int StatusId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPBuildinPlanMISDetailsReportA
      public class SPBuildinPlanMISDetailsReportA
      {
         public string SPName = "SPBuildinPlanMISDetailsReportA";
         public int FromDate = 0;
         public int Todate = 1;
         public int RegionId = 2;
         public int StatusId = 3;
         public int EstateId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectStateMasterByState
      public class SPSelectStateMasterByState
      {
         public string SPName = "SPSelectStateMasterByState";
         public int State = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectOfficeUserMasterByEmployeeCodeForDuplication
      public class SPSelectOfficeUserMasterByEmployeeCodeForDuplication
      {
         public string SPName = "SPSelectOfficeUserMasterByEmployeeCodeForDuplication";
         public int EmployeeCode = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateNUExtension
      public class SPInsertUpdateNUExtension
      {
         public string SPName = "SPInsertUpdateNUExtension";
         public int ApplicationFormId = 0;
         public int ApplicationId = 1;
         public int ReferenceNo = 2;
         public int NUExtensionId = 3;
         public int PlotArea = 4;
         public int LandCost = 5;
         public int FinalCostDate = 6;
         public int FrontageCost = 7;
         public int TotalCostPlot = 8;
         public int ShedCost = 9;
         public int TotalCost = 10;
         public int FinalAreaApproved = 11;
         public int PLanApprovalDate = 12;
         public int LimitExtensionReason = 13;
         public int RequiredTimePeriodExtension = 14;
         public int ConstructionCompleteDate = 15;
         public int MachineryInstalledDate = 16;
         public int PreviousOrderDate = 17;
         public int PreviousExtensionGranted = 18;
         public int previousNUPenalty = 19;
         public int ProductChangeFrom = 20;
         public int ProductChangeTo = 21;
         public int ProductName1 = 22;
         public int ProductName2 = 23;
         public int ProductName3 = 24;
         public int ProductName4 = 25;
         public int PowerRequirement = 26;
         public int WaterRequirement = 27;
         public int GPCBRequired = 28;
         public int CreatedBy = 29;
         public int IsActive = 30;
         public int Operation = 31;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSignPDF
      public class SPSelectSignPDF
      {
         public string SPName = "SPSelectSignPDF";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPLeaseAPPLICATIONDETAILSREPORTFOOTER
      public class SPLeaseAPPLICATIONDETAILSREPORTFOOTER
      {
         public string SPName = "SPLeaseAPPLICATIONDETAILSREPORTFOOTER";
         public int StatusId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectIncompleteDocumentList
      public class SPSelectIncompleteDocumentList
      {
         public string SPName = "SPSelectIncompleteDocumentList";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSublettingModuleHOFlowUserByBranchAndRole
      public class SPSelectSublettingModuleHOFlowUserByBranchAndRole
      {
         public string SPName = "SPSelectSublettingModuleHOFlowUserByBranchAndRole";
         public int BranchId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateOfficeUserMaster
      public class SPInsertUpdateOfficeUserMaster
      {
         public string SPName = "SPInsertUpdateOfficeUserMaster";
         public int UserId = 0;
         public int FirstName = 1;
         public int MiddleName = 2;
         public int LastName = 3;
         public int RoleId = 4;
         public int RegionId = 5;
         public int DivisionId = 6;
         public int ContactNo = 7;
         public int MobileNo = 8;
         public int MailTriggerEmailId = 9;
         public int EmailId = 10;
         public int Password = 11;
         public int ModifiedBy = 12;
         public int CreatedBy = 13;
         public int IsActive = 14;
         public int Operation = 15;
         public int EmployeeCode = 16;
         public int OraDesignation = 17;
         public int OraClass = 18;
         public int OraDesignationCode = 19;
         public int OraClassCode = 20;
         public int OraEmployeeFullName = 21;
         public int UserType = 22;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectAmalgamationModuleInvoice
      public class SPSelectAmalgamationModuleInvoice
      {
         public string SPName = "SPSelectAmalgamationModuleInvoice";
         public int ApplicationFormId = 0;
         public int UserId = 1;
         public int TxId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSurrenderQueryDocumentListByApplicationId
      public class SPSelectSurrenderQueryDocumentListByApplicationId
      {
         public string SPName = "SPSelectSurrenderQueryDocumentListByApplicationId";
         public int AplicationFormId = 0;
         public int ConstituteTypeTransferor = 1;
         public int ActionID = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region M_SPInsertGeneralApplicationFormDetails
      public class M_SPInsertGeneralApplicationFormDetails
      {
         public string SPName = "M_SPInsertGeneralApplicationFormDetails";
         public int ApplicationFormDate = 0;
         public int ApplicationId = 1;
         public int ApplicantFirstName = 2;
         public int ApplicantContactNo = 3;
         public int ApplicantMobileNo = 4;
         public int ApplicantEmailId = 5;
         public int CompanyName = 6;
         public int CompanyEmailId = 7;
         public int CompanyWebsite = 8;
         public int ConsititutionTypeId = 9;
         public int AlloteeName = 10;
         public int EstateId = 11;
         public int RegionId = 12;
         public int PlotShedTypeId = 13;
         public int PlotShedNumber = 14;
         public int PlotArea = 15;
         public int PlotAllotmentDate = 16;
         public int PlotAgreementDate = 17;
         public int PlotPhysicalPossessionDate = 18;
         public int PlotDeedDate = 19;
         public int UnitEmailId = 20;
         public int UnitMobileNo = 21;
         public int UnitAddress = 22;
         public int Relationwithunit = 23;
         public int ApplicantIdentity = 24;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTWORApplicationModuleInvoiceForCancel
      public class SPSelectTWORApplicationModuleInvoiceForCancel
      {
         public string SPName = "SPSelectTWORApplicationModuleInvoiceForCancel";
         public int ApplicationFormId = 0;
         public int UserId = 1;
         public int TxId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPBuildinPlanMISReportA
      public class SPBuildinPlanMISReportA
      {
         public string SPName = "SPBuildinPlanMISReportA";
         public int FromDate = 0;
         public int Todate = 1;
         public int RegionId = 2;
         public int StatusId = 3;
         public int EstateId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectStateMasterByStateId
      public class SPSelectStateMasterByStateId
      {
         public string SPName = "SPSelectStateMasterByStateId";
         public int StateId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectBranchMasterByBranchId
      public class SPSelectBranchMasterByBranchId
      {
         public string SPName = "SPSelectBranchMasterByBranchId";
         public int BranchId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectOfficeUserMasterByEmployeeCodeandUserIdForDuplication
      public class SPSelectOfficeUserMasterByEmployeeCodeandUserIdForDuplication
      {
         public string SPName = "SPSelectOfficeUserMasterByEmployeeCodeandUserIdForDuplication";
         public int EmployeeCode = 0;
         public int UserId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region GetAmalgamationReportforfooterbyRegionId
      public class GetAmalgamationReportforfooterbyRegionId
      {
         public string SPName = "GetAmalgamationReportforfooterbyRegionId";
         public int RegionId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubdivisionModuleFormalReport
      public class SPSelectSubdivisionModuleFormalReport
      {
         public string SPName = "SPSelectSubdivisionModuleFormalReport";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSubDivisionApplicationDetailsReportFooter
      public class SPSubDivisionApplicationDetailsReportFooter
      {
         public string SPName = "SPSubDivisionApplicationDetailsReportFooter";
         public int ACTIONID = 0;
         public int ActionType = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateSublettingModuleApplicationInManagerHOLoop
      public class SpUpdateSublettingModuleApplicationInManagerHOLoop
      {
         public string SPName = "SpUpdateSublettingModuleApplicationInManagerHOLoop";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int NewAssinedActionId = 2;
         public int AssignedRoleId = 3;
         public int DepartmentId = 4;
         public int Remarks = 5;
         public int HOAdditionalDocs = 6;
         public int BranchUserId = 7;
         public int CurrentBranchId = 8;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetPendingDayAtGIDCendForSubletting
      public class SPGetPendingDayAtGIDCendForSubletting
      {
         public string SPName = "SPGetPendingDayAtGIDCendForSubletting";
         public int ApplicationFormId = 0;
         public int Days = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectOfficeUserMasterByEmailId
      public class SPSelectOfficeUserMasterByEmailId
      {
         public string SPName = "SPSelectOfficeUserMasterByEmailId";
         public int EmailId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectAmalgamationModuleInvoiceByHeader
      public class SPSelectAmalgamationModuleInvoiceByHeader
      {
         public string SPName = "SPSelectAmalgamationModuleInvoiceByHeader";
         public int ApplicationFormId = 0;
         public int TxId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectWaterSupplyApplicationInvoiceForCancel
      public class SPSelectWaterSupplyApplicationInvoiceForCancel
      {
         public string SPName = "SPSelectWaterSupplyApplicationInvoiceForCancel";
         public int ApplicationFormId = 0;
         public int UserId = 1;
         public int TxId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPBuildinPlanMISDetailsReportB
      public class SPBuildinPlanMISDetailsReportB
      {
         public string SPName = "SPBuildinPlanMISDetailsReportB";
         public int FromDate = 0;
         public int Todate = 1;
         public int RegionId = 2;
         public int StatusId = 3;
         public int EstateId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectBranchMasterByBranchName
      public class SPSelectBranchMasterByBranchName
      {
         public string SPName = "SPSelectBranchMasterByBranchName";
         public int BranchName = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertCRDailyApplicationDetailsForPreview2R
      public class SPInsertCRDailyApplicationDetailsForPreview2R
      {
         public string SPName = "SPInsertCRDailyApplicationDetailsForPreview2R";
         public int ApplicationId = 0;
         public int ApplicationFormId = 1;
         public int AppForwardDate = 2;
         public int AppActualForwardDate = 3;
         public int ActionId = 4;
         public int AssignRoleId = 5;
         public int Remark = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateUserDigitalSignDetails
      public class SPUpdateUserDigitalSignDetails
      {
         public string SPName = "SPUpdateUserDigitalSignDetails";
         public int UserId = 0;
         public int EmailId = 1;
         public int RoleId = 2;
         public int DSHash = 3;
         public int DSVersion = 4;
         public int DSSerialNumber = 5;
         public int DSIssuer = 6;
         public int DSSubject = 7;
         public int DSPublicKey = 8;
         public int DSValidFrom = 9;
         public int DSValidTo = 10;
         public int DSCnName = 11;
         public int DSThumbPrint = 12;
         public int DSPubKeyLen = 13;
         public int DSSubjectAlternativeName = 14;
         public int DSCrtString = 15;
         public int DSServerDate = 16;
         public int EmailIDBase64 = 17;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectEstateMasterByRegionIdForAppTran
      public class SPSelectEstateMasterByRegionIdForAppTran
      {
         public string SPName = "SPSelectEstateMasterByRegionIdForAppTran";
         public int RegionId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region M_SPGetDetailsByPlotShedNumber
      public class M_SPGetDetailsByPlotShedNumber
      {
         public string SPName = "M_SPGetDetailsByPlotShedNumber";
         public int PlotShedNo = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDrainageApplicationInvoiceForCancel
      public class SPSelectDrainageApplicationInvoiceForCancel
      {
         public string SPName = "SPSelectDrainageApplicationInvoiceForCancel";
         public int ApplicationFormId = 0;
         public int UserId = 1;
         public int TxId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPBuildinPlanMISReportB
      public class SPBuildinPlanMISReportB
      {
         public string SPName = "SPBuildinPlanMISReportB";
         public int FromDate = 0;
         public int Todate = 1;
         public int RegionId = 2;
         public int StatusId = 3;
         public int EstateId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateStateMaster
      public class SPInsertUpdateStateMaster
      {
         public string SPName = "SPInsertUpdateStateMaster";
         public int StateId = 0;
         public int State = 1;
         public int CountryId = 2;
         public int UserId = 3;
         public int IsActive = 4;
         public int Operation = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteBranchMasterByBranchId
      public class SPDeleteBranchMasterByBranchId
      {
         public string SPName = "SPDeleteBranchMasterByBranchId";
         public int BranchId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateSubdivisionModuleOutwardByApplicationFormId
      public class SPUpdateSubdivisionModuleOutwardByApplicationFormId
      {
         public string SPName = "SPUpdateSubdivisionModuleOutwardByApplicationFormId";
         public int ApplicationFormId = 0;
         public int OutwardDocumentName = 1;
         public int isPTO = 2;
         public int IsAggredTransferMode = 3;
         public int FormalTrasferOrInFormalTrasfer = 4;
         public int ModifiedBy = 5;
         public int Remarks = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPTransferApplicationDetailsReportFooterTemp
      public class SPTransferApplicationDetailsReportFooterTemp
      {
         public string SPName = "SPTransferApplicationDetailsReportFooterTemp";
         public int ACTIONID = 0;
         public int ActionType = 1;
         public int BeforeAfter = 2;
         public int OldApplicationStatusId = 3;
         public int PTOIssueCMD = 4;
         public int IsApplicationReceived = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPLeaseAPPLICATIONDETAILSREPORT_old
      public class SPLeaseAPPLICATIONDETAILSREPORT_old
      {
         public string SPName = "SPLeaseAPPLICATIONDETAILSREPORT_old";
         public int REGIONID = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectBuildingPlanApprovalApplicationInvoiceForCancel
      public class SPSelectBuildingPlanApprovalApplicationInvoiceForCancel
      {
         public string SPName = "SPSelectBuildingPlanApprovalApplicationInvoiceForCancel";
         public int ApplicationFormId = 0;
         public int UserId = 1;
         public int TxId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteTwoRModuleFinancialDetails
      public class SPDeleteTwoRModuleFinancialDetails
      {
         public string SPName = "SPDeleteTwoRModuleFinancialDetails";
         public int FinancialInstitutionId = 0;
         public int ApplicationFormId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPTransferApplicationDetailsReportTemp
      public class SPTransferApplicationDetailsReportTemp
      {
         public string SPName = "SPTransferApplicationDetailsReportTemp";
         public int REGIONID = 0;
         public int ACTIONID = 1;
         public int ActionType = 2;
         public int BeforeAfter = 3;
         public int OldApplicationStatusId = 4;
         public int PTOIssueCMD = 5;
         public int IsApplicationReceived = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region Sp_InsertupdateAmalgamationPORecord
      public class Sp_InsertupdateAmalgamationPORecord
      {
         public string SPName = "Sp_InsertupdateAmalgamationPORecord";
         public int Mode = 0;
         public int ApplicationFormId = 1;
         public int UserId = 2;
         public int DocumentXML = 3;
         public int POConditionNo = 4;
         public int POCondition = 5;
         public int POConditionId = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateGeneralApplicationForm
      public class SPInsertUpdateGeneralApplicationForm
      {
         public string SPName = "SPInsertUpdateGeneralApplicationForm";
         public int ApplicationFormId = 0;
         public int StatusId = 1;
         public int ActionId = 2;
         public int ApplicationFormDate = 3;
         public int ApplicationId = 4;
         public int ReferenceNo = 5;
         public int AssignedRoleId = 6;
         public int ApplicantFirstName = 7;
         public int ApplicantMiddleName = 8;
         public int ApplicantLastName = 9;
         public int ApplicantAddress = 10;
         public int ApplicantPincode = 11;
         public int ApplicantCityId = 12;
         public int ApplicantTalukaId = 13;
         public int ApplicantDistrictId = 14;
         public int ApplicantStateId = 15;
         public int ApplicantCountryId = 16;
         public int ApplicantContactNo = 17;
         public int ApplicantMobileNo = 18;
         public int ApplicantEmailId = 19;
         public int ApplicantCategoryId = 20;
         public int CompanyDetailSameAsApplicant = 21;
         public int CompanyName = 22;
         public int CompanyAddress = 23;
         public int CompanyCityId = 24;
         public int CompanyTalukaId = 25;
         public int CompanyDistrictId = 26;
         public int CompanyStateId = 27;
         public int CompanyCountryId = 28;
         public int CompanyPincode = 29;
         public int CompanyContactNo = 30;
         public int CompanyMobileNo = 31;
         public int CompanyEmailId = 32;
         public int CompanyWebsite = 33;
         public int ConsititutionTypeId = 34;
         public int AlloteeName = 35;
         public int EstateId = 36;
         public int RegionId = 37;
         public int PlotShedTypeId = 38;
         public int PlotShedNumber = 39;
         public int PlotArea = 40;
         public int PlotAllotmentDate = 41;
         public int PlotAllotmentOrderNo = 42;
         public int PlotAgreementDate = 43;
         public int PlotPhysicalPossessionDate = 44;
         public int PlotDeedId = 45;
         public int PlotDeedDate = 46;
         public int PlotContactNo = 47;
         public int PlotFaxNo = 48;
         public int PlotCategoryId = 49;
         public int CreatedBy = 50;
         public int IsSubmitted = 51;
         public int DeedType = 52;
         public int PreviouslyTakenDeed = 53;
         public int Operation = 54;
         public int IFP_PersonId = 55;
         public int IFP_IsFromIFP = 56;
         public int IFP_ApplicationId = 57;
         public int IFP_ProjectId = 58;
         public int UnitEmailId = 59;
         public int UnitMobileNo = 60;
         public int UnitAddress = 61;
         public int IsNameDifference = 62;
         public int Relationwithunit = 63;
         public int ApplicantIdentity = 64;
         public int IsFromMobileApp = 65;
         public int PartyCode = 66;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdatePlotTypeMaster
      public class SPInsertUpdatePlotTypeMaster
      {
         public string SPName = "SPInsertUpdatePlotTypeMaster";
         public int PlotTypeId = 0;
         public int PlotType = 1;
         public int UserId = 2;
         public int IsActive = 3;
         public int Operation = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region M_SPGetPlotShedNumberDetails
      public class M_SPGetPlotShedNumberDetails
      {
         public string SPName = "M_SPGetPlotShedNumberDetails";
         public int EstateId = 0;
         public int PlotTypeId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferModuleInvoiceForCancel
      public class SPSelectTransferModuleInvoiceForCancel
      {
         public string SPName = "SPSelectTransferModuleInvoiceForCancel";
         public int ApplicationFormId = 0;
         public int UserId = 1;
         public int TxId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPBuildinPlanMISDetailsReportD
      public class SPBuildinPlanMISDetailsReportD
      {
         public string SPName = "SPBuildinPlanMISDetailsReportD";
         public int FromDate = 0;
         public int Todate = 1;
         public int RegionId = 2;
         public int StatusId = 3;
         public int EstateId = 4;
         public int RoleId = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectROUModuleInvoiceByHeader_old
      public class SPSelectROUModuleInvoiceByHeader_old
      {
         public string SPName = "SPSelectROUModuleInvoiceByHeader_old";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSummaryRoleWise
      public class SPSelectSummaryRoleWise
      {
         public string SPName = "SPSelectSummaryRoleWise";
         public int RoleId = 0;
         public int RegionId = 1;
         public int UserId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSublettingModuleDetailsListForViewByApplicationFormId
      public class SPSelectSublettingModuleDetailsListForViewByApplicationFormId
      {
         public string SPName = "SPSelectSublettingModuleDetailsListForViewByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectUserDigitalSignDetails
      public class SPSelectUserDigitalSignDetails
      {
         public string SPName = "SPSelectUserDigitalSignDetails";
         public int UserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateTransferModuleForOldApplications
      public class SPUpdateTransferModuleForOldApplications
      {
         public string SPName = "SPUpdateTransferModuleForOldApplications";
         public int ApplicationFormId = 0;
         public int OldApplicationStatusId = 1;
         public int DateOfPTO = 2;
         public int PTODocument = 3;
         public int DateOfFTO = 4;
         public int FTODocument = 5;
         public int ActionId = 6;
         public int OldAppRemarks = 7;
         public int ModifiedBy = 8;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPBuildinPlanMISReportD
      public class SPBuildinPlanMISReportD
      {
         public string SPName = "SPBuildinPlanMISReportD";
         public int FromDate = 0;
         public int Todate = 1;
         public int RegionId = 2;
         public int StatusId = 3;
         public int EstateId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteCityMasterByCityId
      public class SPDeleteCityMasterByCityId
      {
         public string SPName = "SPDeleteCityMasterByCityId";
         public int CityId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectOfficeUserMasterForGrievanceLogin
      public class SPSelectOfficeUserMasterForGrievanceLogin
      {
         public string SPName = "SPSelectOfficeUserMasterForGrievanceLogin";
         public int EmailId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectBuildingCompletionSelfCertificationByApplicationFormIdForView
      public class SPSelectBuildingCompletionSelfCertificationByApplicationFormIdForView
      {
         public string SPName = "SPSelectBuildingCompletionSelfCertificationByApplicationFormIdForView";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectGrievanceApplicantUserMasterByUserId
      public class SPSelectGrievanceApplicantUserMasterByUserId
      {
         public string SPName = "SPSelectGrievanceApplicantUserMasterByUserId";
         public int UserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetPendingDayFromLastActionAtGIDCendForSurrender
      public class SPGetPendingDayFromLastActionAtGIDCendForSurrender
      {
         public string SPName = "SPGetPendingDayFromLastActionAtGIDCendForSurrender";
         public int ApplicationFormId = 0;
         public int Days = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSubDivisionApplicationRemarksHistoryForReport
      public class SPSubDivisionApplicationRemarksHistoryForReport
      {
         public string SPName = "SPSubDivisionApplicationRemarksHistoryForReport";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubdivisionModuleInvoiceForCancel
      public class SPSelectSubdivisionModuleInvoiceForCancel
      {
         public string SPName = "SPSelectSubdivisionModuleInvoiceForCancel";
         public int ApplicationFormId = 0;
         public int UserId = 1;
         public int TxId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPBuildinPlanMISReportC
      public class SPBuildinPlanMISReportC
      {
         public string SPName = "SPBuildinPlanMISReportC";
         public int FromDate = 0;
         public int Todate = 1;
         public int RegionId = 2;
         public int StatusId = 3;
         public int EstateId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateCityMaster
      public class SPInsertUpdateCityMaster
      {
         public string SPName = "SPInsertUpdateCityMaster";
         public int CityId = 0;
         public int City = 1;
         public int TalukaId = 2;
         public int UserId = 3;
         public int IsActive = 4;
         public int Operation = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpGetMenubyMenuId
      public class SpGetMenubyMenuId
      {
         public string SPName = "SpGetMenubyMenuId";
         public int MenuId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectROUModuleHOFlowUserRoleCount
      public class SPSelectROUModuleHOFlowUserRoleCount
      {
         public string SPName = "SPSelectROUModuleHOFlowUserRoleCount";
         public int BranchId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSubLettingApplicationRemarksHistoryForReport
      public class SPSubLettingApplicationRemarksHistoryForReport
      {
         public string SPName = "SPSubLettingApplicationRemarksHistoryForReport";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDocumentDetails
      public class SPSelectDocumentDetails
      {
         public string SPName = "SPSelectDocumentDetails";
         public int RegionId = 0;
         public int EstateId = 1;
         public int PlotShedTypeId = 2;
         public int ApplicantName = 3;
         public int PlotNumber = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SelectPlotTypeMasterByPlotTypeId
      public class SelectPlotTypeMasterByPlotTypeId
      {
         public string SPName = "SelectPlotTypeMasterByPlotTypeId";
         public int PlotTypeId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region M_SPGetRegionDetails
      public class M_SPGetRegionDetails
      {
         public string SPName = "M_SPGetRegionDetails";
         public int EstateName = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpViewSubdivisionDocumentForApplicant
      public class SpViewSubdivisionDocumentForApplicant
      {
         public string SPName = "SpViewSubdivisionDocumentForApplicant";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPCheckUniqueReferenceNoForPlinthSelfCertification
      public class SPCheckUniqueReferenceNoForPlinthSelfCertification
      {
         public string SPName = "SPCheckUniqueReferenceNoForPlinthSelfCertification";
         public int ReferenceNo = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeletePlotCategoryMasterByPlotCategoryId
      public class SPDeletePlotCategoryMasterByPlotCategoryId
      {
         public string SPName = "SPDeletePlotCategoryMasterByPlotCategoryId";
         public int PlotCategoryId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPartyNameByEstateIdAndPlotTypeId
      public class SPSelectPartyNameByEstateIdAndPlotTypeId
      {
         public string SPName = "SPSelectPartyNameByEstateIdAndPlotTypeId";
         public int EstateId = 0;
         public int PlotTypeId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPlotTypeMasterByPlotType
      public class SPSelectPlotTypeMasterByPlotType
      {
         public string SPName = "SPSelectPlotTypeMasterByPlotType";
         public int PlotType = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectROUModuleInvoiceForCancel
      public class SPSelectROUModuleInvoiceForCancel
      {
         public string SPName = "SPSelectROUModuleInvoiceForCancel";
         public int ApplicationFormId = 0;
         public int UserId = 1;
         public int TxId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPBuildinPlanMISDetailsReportC
      public class SPBuildinPlanMISDetailsReportC
      {
         public string SPName = "SPBuildinPlanMISDetailsReportC";
         public int FromDate = 0;
         public int Todate = 1;
         public int RegionId = 2;
         public int StatusId = 3;
         public int EstateId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPCheckUserOfIFP
      public class SPCheckUserOfIFP
      {
         public string SPName = "SPCheckUserOfIFP";
         public int IFP_PersonId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectCRReportByUserId
      public class SPSelectCRReportByUserId
      {
         public string SPName = "SPSelectCRReportByUserId";
         public int EmployeeCode = 0;
         public int Region = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectAmalgamationDetailByApplicationFormId
      public class SPSelectAmalgamationDetailByApplicationFormId
      {
         public string SPName = "SPSelectAmalgamationDetailByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertBuildingCompletion
      public class SPInsertBuildingCompletion
      {
         public string SPName = "SPInsertBuildingCompletion";
         public int ApplicationFormId = 0;
         public int ReferenceNo = 1;
         public int ActionId = 2;
         public int AssignedRoleId = 3;
         public int ApplicationId = 4;
         public int ApplicationFormDate = 5;
         public int Name = 6;
         public int MobileNo = 7;
         public int EstateId = 8;
         public int RegionId = 9;
         public int PlotShedType = 10;
         public int PlotShedNo = 11;
         public int PlotShedArea = 12;
         public int AllotmentDate = 13;
         public int Address = 14;
         public int BuildingPlanReferenceNo = 15;
         public int BuildingPlanDate = 16;
         public int ArchitectName = 17;
         public int BuildingConstructionArea = 18;
         public int BuildingCompletionFee = 19;
         public int PartyCode = 20;
         public int BuildingPlanApprovalLetter = 21;
         public int BuildingCompletionSelfCertification = 22;
         public int SubmissionDate = 23;
         public int FinalPaymentStatus = 24;
         public int IsActive = 25;
         public int CreatedBy = 26;
         public int CreationOn = 27;
         public int ModifiedBy = 28;
         public int ModifiedOn = 29;
         public int OraEstateId = 30;
         public int OraRegionId = 31;
         public int OraPlotTypeId = 32;
         public int AttechmentDoc = 33;
         public int AllotteeName = 34;
         public int Mode = 35;
         public int EmailId = 36;
         public int IsSubmitted = 37;
         public int IsCertificatePlanDevelopment = 38;
         public int ArchitectRegisterNumber = 39;
         public int ArchitectRegisterWith = 40;
         public int ArchitectRegisterDate = 41;
         public int PlinthBuildingLayoutPlan = 42;
         public int SGSTAmount = 43;
         public int CGSTAmount = 44;
         public int BaseAmount = 45;
         public int ACCHEAD_C = 46;
         public int ACC_M = 47;
         public int FROM_D = 48;
         public int TO_D = 49;
         public int ACC_NO = 50;
         public int SGST_A = 51;
         public int CGST_A = 52;
         public int ACC_N = 53;
         public int TotalAdministrativeCharges = 54;
         public int AlloteeGSTNo = 55;
         public int BuildingPlanUI = 56;
         public int BuildingPlanDeptUniqueId = 57;
         public int BuildingPlanEODBApplicationId = 58;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpAmalgamationApplicationRemarksHistoryForReport
      public class SpAmalgamationApplicationRemarksHistoryForReport
      {
         public string SPName = "SpAmalgamationApplicationRemarksHistoryForReport";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region ErrorLogCRUD
      public class ErrorLogCRUD
      {
         public string SPName = "ErrorLogCRUD";
         public int ErrorId = 0;
         public int Exception = 1;
         public int ClassName = 2;
         public int FunctionName = 3;
         public int mode = 4;
         public int where = 5;
         public int PageNumber = 6;
         public int PageSize = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertTransactionReferenceNoPaymentDetailsForAmalgamationPO
      public class SPInsertTransactionReferenceNoPaymentDetailsForAmalgamationPO
      {
         public string SPName = "SPInsertTransactionReferenceNoPaymentDetailsForAmalgamationPO";
         public int TxId = 0;
         public int ApplicationFormId = 1;
         public int POPayment = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeletePlotTypeMasterByPlotTypeId
      public class SPDeletePlotTypeMasterByPlotTypeId
      {
         public string SPName = "SPDeletePlotTypeMasterByPlotTypeId";
         public int PlotTypeId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region M_SPGetAllUserDetailsByApplicantUserId
      public class M_SPGetAllUserDetailsByApplicantUserId
      {
         public string SPName = "M_SPGetAllUserDetailsByApplicantUserId";
         public int ApplicantUserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubLettingModuleInvoiceForCancel
      public class SPSelectSubLettingModuleInvoiceForCancel
      {
         public string SPName = "SPSelectSubLettingModuleInvoiceForCancel";
         public int ApplicationFormId = 0;
         public int UserId = 1;
         public int TxId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectEstatePriceForTransferByApplicationFormId
      public class SPSelectEstatePriceForTransferByApplicationFormId
      {
         public string SPName = "SPSelectEstatePriceForTransferByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdatePlotCategoryMaster
      public class SPInsertUpdatePlotCategoryMaster
      {
         public string SPName = "SPInsertUpdatePlotCategoryMaster";
         public int PlotCategoryId = 0;
         public int PlotCategory = 1;
         public int UserId = 2;
         public int IsActive = 3;
         public int Operation = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubDocumentMasterForCompletionByRoleId
      public class SPSelectSubDocumentMasterForCompletionByRoleId
      {
         public string SPName = "SPSelectSubDocumentMasterForCompletionByRoleId";
         public int RoleId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectOfficeUserMasterByUserId
      public class SPSelectOfficeUserMasterByUserId
      {
         public string SPName = "SPSelectOfficeUserMasterByUserId";
         public int UserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region M_SPGetAllUserDetails
      public class M_SPGetAllUserDetails
      {
         public string SPName = "M_SPGetAllUserDetails";
         public int UserId = 0;
         public int Password = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectAmalgamationModuleInvoiceForCancel
      public class SPSelectAmalgamationModuleInvoiceForCancel
      {
         public string SPName = "SPSelectAmalgamationModuleInvoiceForCancel";
         public int ApplicationFormId = 0;
         public int UserId = 1;
         public int TxId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDocumentRepositoryByRegionEstate
      public class SPSelectDocumentRepositoryByRegionEstate
      {
         public string SPName = "SPSelectDocumentRepositoryByRegionEstate";
         public int RegionId = 0;
         public int EstateId = 1;
         public int FromDate = 2;
         public int ToDate = 3;
         public int UserId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubdivisionPaymentAdminCharge
      public class SPSelectSubdivisionPaymentAdminCharge
      {
         public string SPName = "SPSelectSubdivisionPaymentAdminCharge";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectRoleNameByRoleId
      public class SPSelectRoleNameByRoleId
      {
         public string SPName = "SPSelectRoleNameByRoleId";
         public int RoleId = 0;
         public int BranchId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectCheckEstateforImpactPlan
      public class SPSelectCheckEstateforImpactPlan
      {
         public string SPName = "SPSelectCheckEstateforImpactPlan";
         public int EstateId = 0;
         public int RegionId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubDocumentMasterByRoleId
      public class SPSelectSubDocumentMasterByRoleId
      {
         public string SPName = "SPSelectSubDocumentMasterByRoleId";
         public int RoleId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteOfficeUserMasterByUserId
      public class SPDeleteOfficeUserMasterByUserId
      {
         public string SPName = "SPDeleteOfficeUserMasterByUserId";
         public int UserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region M_SPGetUserDetails
      public class M_SPGetUserDetails
      {
         public string SPName = "M_SPGetUserDetails";
         public int UserId = 0;
         public int Password = 1;
         public int Count = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubdivisionModulePSOInvoice
      public class SPSelectSubdivisionModulePSOInvoice
      {
         public string SPName = "SPSelectSubdivisionModulePSOInvoice";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateTwoRApplicationModulePlotDetailsPayment17032017
      public class SPUpdateTwoRApplicationModulePlotDetailsPayment17032017
      {
         public string SPName = "SPUpdateTwoRApplicationModulePlotDetailsPayment17032017";
         public int ApplicationFormId = 0;
         public int PlotShedNumber = 1;
         public int EstateId = 2;
         public int RegionId = 3;
         public int AdminST = 4;
         public int AdminCharge = 5;
         public int AdminSBC = 6;
         public int AdminKKC = 7;
         public int PrevailingAllotmentPrice = 8;
         public int TotalAllotmentPrice = 9;
         public int TotalAllotmentFees = 10;
         public int UserId = 11;
         public int AllotFee = 12;
         public int AllotST = 13;
         public int AllotKKC = 14;
         public int AllotSBC = 15;
         public int LoanRequested = 16;
         public int Name = 17;
         public int Address = 18;
         public int TimePeriodRequired = 19;
         public int SGSTAmount = 20;
         public int CGSTAmount = 21;
         public int ACCHEAD_C = 22;
         public int ACC_M = 23;
         public int FROM_D = 24;
         public int TO_D = 25;
         public int ACC_NO = 26;
         public int SGST_A = 27;
         public int CGST_A = 28;
         public int ACC_N = 29;
         public int COLL_SGSTAmount = 30;
         public int COLL_CGSTAmount = 31;
         public int COLL_ACCHEAD_C = 32;
         public int COLL_ACC_M = 33;
         public int COLL_FROM_D = 34;
         public int COLL_TO_D = 35;
         public int COLL_ACC_NO = 36;
         public int COLL_SGST_A = 37;
         public int COLL_CGST_A = 38;
         public int COLL_ACC_N = 39;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPlinthCertificationByApplicationFormIdForView
      public class SPSelectPlinthCertificationByApplicationFormIdForView
      {
         public string SPName = "SPSelectPlinthCertificationByApplicationFormIdForView";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetPendingDayAtGIDCendForSurrender
      public class SPGetPendingDayAtGIDCendForSurrender
      {
         public string SPName = "SPGetPendingDayAtGIDCendForSurrender";
         public int ApplicationFormId = 0;
         public int Days = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPrevailingAllotmentPriceFor2R17032017
      public class SPSelectPrevailingAllotmentPriceFor2R17032017
      {
         public string SPName = "SPSelectPrevailingAllotmentPriceFor2R17032017";
         public int EstateId = 0;
         public int PlottypeId = 1;
         public int FinancialYearOfApplication = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPAOForwardToAMTwoRApplication
      public class SPAOForwardToAMTwoRApplication
      {
         public string SPName = "SPAOForwardToAMTwoRApplication";
         public int ApplicationFormId = 0;
         public int AssignedRoleId = 1;
         public int ModifiedBy = 2;
         public int BackwardRemark = 3;
         public int Path = 4;
         public int AODCC = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPlotCategoryMasterByPlotCategory
      public class SPSelectPlotCategoryMasterByPlotCategory
      {
         public string SPName = "SPSelectPlotCategoryMasterByPlotCategory";
         public int PlotCategory = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubdivisionModulePSOInvoiceByHeader
      public class SPSelectSubdivisionModulePSOInvoiceByHeader
      {
         public string SPName = "SPSelectSubdivisionModulePSOInvoiceByHeader";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPLotDetailsForAllotmentPrice17032017
      public class SPSelectPLotDetailsForAllotmentPrice17032017
      {
         public string SPName = "SPSelectPLotDetailsForAllotmentPrice17032017";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateApplicantUserMaster1
      public class SPInsertUpdateApplicantUserMaster1
      {
         public string SPName = "SPInsertUpdateApplicantUserMaster1";
         public int ApplicantUserId = 0;
         public int FirstName = 1;
         public int MiddleName = 2;
         public int LastName = 3;
         public int ContactNo = 4;
         public int MobileNo = 5;
         public int ModifiedOn = 6;
         public int ModifiedBy = 7;
         public int IsActive = 8;
         public int RegisteredAddress = 9;
         public int Prefix = 10;
         public int ApplicantIdentityProof = 11;
         public int ApplicantOfficeIdentityProof = 12;
         public int UserId = 13;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDEEForwardToAMTwoRApplication
      public class SPDEEForwardToAMTwoRApplication
      {
         public string SPName = "SPDEEForwardToAMTwoRApplication";
         public int ApplicationFormId = 0;
         public int AssignedRoleId = 1;
         public int ModifiedBy = 2;
         public int BackwardRemark = 3;
         public int Path = 4;
         public int DEEDCC = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPCheckUniqueTransactionReferenceNo
      public class SPCheckUniqueTransactionReferenceNo
      {
         public string SPName = "SPCheckUniqueTransactionReferenceNo";
         public int TxId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSublettingModuleHOFlowUserRoleCount
      public class SPSelectSublettingModuleHOFlowUserRoleCount
      {
         public string SPName = "SPSelectSublettingModuleHOFlowUserRoleCount";
         public int BranchId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectCityMasterByCity
      public class SPSelectCityMasterByCity
      {
         public string SPName = "SPSelectCityMasterByCity";
         public int City = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTwoRApplicationDDByTwoRAppDDId
      public class SPSelectTwoRApplicationDDByTwoRAppDDId
      {
         public string SPName = "SPSelectTwoRApplicationDDByTwoRAppDDId";
         public int TwoRAppDDId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpInsertUpdateEstateAllotmentPrice
      public class SpInsertUpdateEstateAllotmentPrice
      {
         public string SPName = "SpInsertUpdateEstateAllotmentPrice";
         public int id = 0;
         public int mode = 1;
         public int RegionId = 2;
         public int EstateId = 3;
         public int PlotTypeId = 4;
         public int FinancialYear = 5;
         public int Price = 6;
         public int CreatedBy = 7;
         public int CreatedOn = 8;
         public int ModifiedBy = 9;
         public int ModifiedOn = 10;
         public int IsActive = 11;
         public int param = 12;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectApplicantUserMasterByUserId
      public class SPSelectApplicantUserMasterByUserId
      {
         public string SPName = "SPSelectApplicantUserMasterByUserId";
         public int UserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateRoleEstateMapping
      public class SPInsertUpdateRoleEstateMapping
      {
         public string SPName = "SPInsertUpdateRoleEstateMapping";
         public int RoleEstateMappingId = 0;
         public int UserId = 1;
         public int RegionId = 2;
         public int EstateId = 3;
         public int CreatedBy = 4;
         public int IsActive = 5;
         public int Operation = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectAmalgamationAEPhotoDetailByApplicationFormId
      public class SPSelectAmalgamationAEPhotoDetailByApplicationFormId
      {
         public string SPName = "SPSelectAmalgamationAEPhotoDetailByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPaymentRecieptDetails
      public class SPSelectPaymentRecieptDetails
      {
         public string SPName = "SPSelectPaymentRecieptDetails";
         public int txnId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region Sp_InsertupdatePTORecord
      public class Sp_InsertupdatePTORecord
      {
         public string SPName = "Sp_InsertupdatePTORecord";
         public int Mode = 0;
         public int ApplicationFormId = 1;
         public int IsLicenceAgreement = 2;
         public int IsLeaseDeed = 3;
         public int AgreementDate = 4;
         public int UserId = 5;
         public int DocumentXML = 6;
         public int PSOConditionNo = 7;
         public int PSOCondition = 8;
         public int PSOConditionId = 9;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSurrenderAODetailsbByApplicationFormid
      public class SPSelectSurrenderAODetailsbByApplicationFormid
      {
         public string SPName = "SPSelectSurrenderAODetailsbByApplicationFormid";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPCheckAODetailsForApplicationID
      public class SPCheckAODetailsForApplicationID
      {
         public string SPName = "SPCheckAODetailsForApplicationID";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPTWORAPPLICATIONDETAILSREPORT
      public class SPTWORAPPLICATIONDETAILSREPORT
      {
         public string SPName = "SPTWORAPPLICATIONDETAILSREPORT";
         public int REGIONID = 0;
         public int ACTIONID = 1;
         public int ActionType = 2;
         public int IsApplicationReceived = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectCityMasterByCityId
      public class SPSelectCityMasterByCityId
      {
         public string SPName = "SPSelectCityMasterByCityId";
         public int CityId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTwoRApplicationDemandDraftByApplicationFormId
      public class SPSelectTwoRApplicationDemandDraftByApplicationFormId
      {
         public string SPName = "SPSelectTwoRApplicationDemandDraftByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectApplicantUserMasterByUserId1
      public class SPSelectApplicantUserMasterByUserId1
      {
         public string SPName = "SPSelectApplicantUserMasterByUserId1";
         public int UserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetPendingDayAtGIDCendForBuildingPlanApprovalForIFP_04042018
      public class SPGetPendingDayAtGIDCendForBuildingPlanApprovalForIFP_04042018
      {
         public string SPName = "SPGetPendingDayAtGIDCendForBuildingPlanApprovalForIFP_04042018";
         public int ReferenceNo = 0;
         public int Days = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectRemarksForTestingDSVerify
      public class SPSelectRemarksForTestingDSVerify
      {
         public string SPName = "SPSelectRemarksForTestingDSVerify";
         public int EmailId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPCheckUniqueReferenceNo
      public class SPCheckUniqueReferenceNo
      {
         public string SPName = "SPCheckUniqueReferenceNo";
         public int ReferenceNo = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectRoleMenubyRoleId
      public class SPSelectRoleMenubyRoleId
      {
         public string SPName = "SPSelectRoleMenubyRoleId";
         public int RoleId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSurrenderApplication
      public class SPSelectSurrenderApplication
      {
         public string SPName = "SPSelectSurrenderApplication";
         public int AssignedRoleId = 0;
         public int SearchValue = 1;
         public int SearchId = 2;
         public int RegionId = 3;
         public int UserId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelect2RApplicationPaymentDetailByTxId
      public class SPSelect2RApplicationPaymentDetailByTxId
      {
         public string SPName = "SPSelect2RApplicationPaymentDetailByTxId";
         public int TxId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSUBDIVISIONAPPLICATIONDETAILSREPORTFOOTER_NEW
      public class SPSUBDIVISIONAPPLICATIONDETAILSREPORTFOOTER_NEW
      {
         public string SPName = "SPSUBDIVISIONAPPLICATIONDETAILSREPORTFOOTER_NEW";
         public int StatusId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectRegionForEstateMapping
      public class SPSelectRegionForEstateMapping
      {
         public string SPName = "SPSelectRegionForEstateMapping";
         public int RegionId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertTransactionReferenceNoPaymentDetails
      public class SPInsertTransactionReferenceNoPaymentDetails
      {
         public string SPName = "SPInsertTransactionReferenceNoPaymentDetails";
         public int TxId = 0;
         public int ApplicationFormId = 1;
         public int ApplicationId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPlotCategoryMasterByPlotCategoryId
      public class SPSelectPlotCategoryMasterByPlotCategoryId
      {
         public string SPName = "SPSelectPlotCategoryMasterByPlotCategoryId";
         public int PlotCategoryId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSurrenderApplicationByApplicationFormId
      public class SPSelectSurrenderApplicationByApplicationFormId
      {
         public string SPName = "SPSelectSurrenderApplicationByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPTWORAPPLICATIONDETAILSREPORTFOOTER
      public class SPTWORAPPLICATIONDETAILSREPORTFOOTER
      {
         public string SPName = "SPTWORAPPLICATIONDETAILSREPORTFOOTER";
         public int ACTIONID = 0;
         public int ActionType = 1;
         public int IsApplicationReceived = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdate2RApplicationDemandDraft
      public class SPInsertUpdate2RApplicationDemandDraft
      {
         public string SPName = "SPInsertUpdate2RApplicationDemandDraft";
         public int TwoRApplicationDemandDraftId = 0;
         public int ApplicationFormId = 1;
         public int ReferenceNo = 2;
         public int ApplicationId = 3;
         public int DDNo = 4;
         public int BankName = 5;
         public int BranchName = 6;
         public int Amount = 7;
         public int CreatedBy = 8;
         public int IsActive = 9;
         public int DDDate = 10;
         public int DDAgainst = 11;
         public int Operation = 12;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelect2RApplicationPaymentDetailByTwoRPlotId17032017
      public class SPSelect2RApplicationPaymentDetailByTwoRPlotId17032017
      {
         public string SPName = "SPSelect2RApplicationPaymentDetailByTwoRPlotId17032017";
         public int TwoRPlotId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSurrenderHOFlowAllBranch
      public class SPSelectSurrenderHOFlowAllBranch
      {
         public string SPName = "SPSelectSurrenderHOFlowAllBranch";
         public int BranchId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubDivisionModuleDashboardNew
      public class SPSelectSubDivisionModuleDashboardNew
      {
         public string SPName = "SPSelectSubDivisionModuleDashboardNew";
         public int BeforeAfter = 0;
         public int RegionId = 1;
         public int StatusId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectIndustryTypeMasterByIndustryType
      public class SPSelectIndustryTypeMasterByIndustryType
      {
         public string SPName = "SPSelectIndustryTypeMasterByIndustryType";
         public int IndustryType = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTwoRApplicationListDetails17032017
      public class SPSelectTwoRApplicationListDetails17032017
      {
         public string SPName = "SPSelectTwoRApplicationListDetails17032017";
         public int AssignedRoleId = 0;
         public int SearchValue = 1;
         public int SearchId = 2;
         public int RegionId = 3;
         public int UserId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertInvoiceForWater
      public class SPInsertInvoiceForWater
      {
         public string SPName = "SPInsertInvoiceForWater";
         public int ApplicationId = 0;
         public int ApplicationFormId = 1;
         public int CreatedBy = 2;
         public int RegionId = 3;
         public int TxId = 4;
         public int TxRefNo = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectActionOfApplication
      public class SPSelectActionOfApplication
      {
         public string SPName = "SPSelectActionOfApplication";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateTwoRApplication
      public class SPInsertUpdateTwoRApplication
      {
         public string SPName = "SPInsertUpdateTwoRApplication";
         public int ApplicationFormId = 0;
         public int ApplicationId = 1;
         public int ReferenceNo = 2;
         public int IsFullPayment = 3;
         public int LoanRequested = 4;
         public int AreaOfPlot = 5;
         public int PrevailingAllotmentPrice = 6;
         public int TotalAllotmentPrice = 7;
         public int TotalAllotmentFees = 8;
         public int IsPermissionRequired = 9;
         public int TimePeriodRequired = 10;
         public int NameOfBank = 11;
         public int IsPastOtherInstitutePermission = 12;
         public int PastBankName = 13;
         public int Date2RPermission = 14;
         public int PastBankNOC = 15;
         public int Has2RPermissionIssued = 16;
         public int IsPastRequestAmountSame = 17;
         public int ChangeOfAmount = 18;
         public int AdministrativeCharge = 19;
         public int FinancialInstitution1 = 20;
         public int FinancialInstitution2 = 21;
         public int FinancialInstitution3 = 22;
         public int FinancialInstitution4 = 23;
         public int ApplicantDocumentList = 24;
         public int CreatedBy = 25;
         public int IsActive = 26;
         public int Operation = 27;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertDocumentDetails
      public class SPInsertDocumentDetails
      {
         public string SPName = "SPInsertDocumentDetails";
         public int RegionId = 0;
         public int EstateId = 1;
         public int PlotShedTypeId = 2;
         public int PlotNumber = 3;
         public int ApplicantName = 4;
         public int DocumentSubId = 5;
         public int DocumentName = 6;
         public int CreatedBy = 7;
         public int CreationDate = 8;
         public int IsActive = 9;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSurrenderApplicationSummaryReportNew
      public class SPSurrenderApplicationSummaryReportNew
      {
         public string SPName = "SPSurrenderApplicationSummaryReportNew";
         public int REGIONID = 0;
         public int ACTIONID = 1;
         public int ActionType = 2;
         public int BeforeAfter = 3;
         public int OldApplicationStatusId = 4;
         public int RescindmentIssue = 5;
         public int StatusId = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectIndustryTypeMasterByIndustryTypeId
      public class SPSelectIndustryTypeMasterByIndustryTypeId
      {
         public string SPName = "SPSelectIndustryTypeMasterByIndustryTypeId";
         public int IndustryTypeId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetSurrenderonPaymentTxtIdbyApplicationFormId
      public class SPGetSurrenderonPaymentTxtIdbyApplicationFormId
      {
         public string SPName = "SPGetSurrenderonPaymentTxtIdbyApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSubDivisionApplicationDetailsReport
      public class SPSubDivisionApplicationDetailsReport
      {
         public string SPName = "SPSubDivisionApplicationDetailsReport";
         public int REGIONID = 0;
         public int StatusId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertInvoiceForDrainage
      public class SPInsertInvoiceForDrainage
      {
         public string SPName = "SPInsertInvoiceForDrainage";
         public int ApplicationId = 0;
         public int ApplicationFormId = 1;
         public int CreatedBy = 2;
         public int RegionId = 3;
         public int TxId = 4;
         public int TxRefNo = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectRoleEstateMappingByRoleEstateMappingId
      public class SPSelectRoleEstateMappingByRoleEstateMappingId
      {
         public string SPName = "SPSelectRoleEstateMappingByRoleEstateMappingId";
         public int RoleEstateMappingId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertSubDivisionApplication
      public class SPInsertSubDivisionApplication
      {
         public string SPName = "SPInsertSubDivisionApplication";
         public int ReferenceNo = 0;
         public int EstateId = 1;
         public int RegionId = 2;
         public int TypeOfPlotShed = 3;
         public int PlotShedNo = 4;
         public int PlotArea = 5;
         public int DateofAllotment = 6;
         public int IsChemical = 7;
         public int NameofApplicant = 8;
         public int ConstitutionTypeId = 9;
         public int ApplicantLandlineNo = 10;
         public int ApplicantMobileNo = 11;
         public int ApplicantEmailId = 12;
         public int IsPlotLessThan250 = 13;
         public int IsPlotMin9MtrGIDC = 14;
         public int IsPlotSubDivisionOpen = 15;
         public int IsPlotSubDivisionUtilized = 16;
         public int IsExistingEntryPointGIDC = 17;
         public int IsCOPOriginalPlot = 18;
         public int IsInternalRoadInSubDivision = 19;
         public int IsProDataCommonAreaDone = 20;
         public int IsAssociationMembersPlot = 21;
         public int IsProposedBetweenFamilyMembers = 22;
         public int FamilyRelationId = 23;
         public int FamilyRelationDocument = 24;
         public int IsExistingPartnerWithExistingGIDC = 25;
         public int ExistingGIDCFamilyRelationId = 26;
         public int ExistingGIDCFamilyRelationDocument = 27;
         public int IsBuildingPlanPlotApproved = 28;
         public int BuldingApprovedDate = 29;
         public int BuldingPlanPassingAuthority = 30;
         public int BuldingPlanDocument = 31;
         public int IsRevisedBuildingPlanPlotApproved = 32;
         public int RevisedBuldingApprovedDate = 33;
         public int RevisedBuldingPlanPassingAuthority = 34;
         public int RevisedBuldingPlanDocument = 35;
         public int IsGIDCInformedPlanApproval = 36;
         public int GIDCInformedDateOfLetter = 37;
         public int GIDCInformedLetterNo = 38;
         public int IsViolativeConstructionPlot = 39;
         public int ViolativeConstructionPlotArea = 40;
         public int IsOriginalPlotSubDivision = 41;
         public int OriginalPlotSubDivisionDateOfSubdivision = 42;
         public int OriginalPlotSubDivisionApprovalAuthority = 43;
         public int OriginalPlotSubDivisionDocument = 44;
         public int IsNocSubDivisionGIDC = 45;
         public int NOCDateApproval = 46;
         public int NOCLetterNo = 47;
         public int NOCDocument = 48;
         public int IsNOCPaidGIDC = 49;
         public int NOCPaidGIDCPaymentDate = 50;
         public int NOCPaidGIDCAmount = 51;
         public int NOCPaidGIDCDocument = 52;
         public int IsIncorporatedGIDCDDPlan = 53;
         public int IncorporatedDate = 54;
         public int IncorporatedDocument = 55;
         public int IsLegalMatterPendingPlot = 56;
         public int CaseNo = 57;
         public int PresentStatus = 58;
         public int DirectionGiven = 59;
         public int NoOfSubDivisionPlot = 60;
         public int PurposeOfSubDivision = 61;
         public int AreaCalculationSheet = 62;
         public int SketchOfSubDivisionDocument = 63;
         public int UndertakingFacilitiesAndAreaDocument = 64;
         public int UndertakingLessThan50GCPlotDocument = 65;
         public int UtilisationElectricityBillDocument = 66;
         public int UtilisationWaterSupplyBillDocument = 67;
         public int SectionType = 68;
         public int CreatedBy = 69;
         public int ApplicantIdentity = 70;
         public int IsSubmitted = 71;
         public int AdminTotalCharge = 72;
         public int AdminKKC = 73;
         public int AdminSBC = 74;
         public int AdminST = 75;
         public int AdminCharge = 76;
         public int COPArea = 77;
         public int IntarnalArea = 78;
         public int AvailableArea = 79;
         public int UndertakingOfCreation = 80;
         public int TotalAreaper = 81;
         public int COPAreaper = 82;
         public int InternalRoadAreaper = 83;
         public int Availableplotareaper = 84;
         public int IsNocObtained = 85;
         public int NOCApprovalLetterNo = 86;
         public int NOCApprovalDate = 87;
         public int UploadNOC = 88;
         public int IsProposalApproved = 89;
         public int NameofLocalAuthority = 90;
         public int PlanPassingLetterNo = 91;
         public int PlanPassingLetterDate = 92;
         public int UploadPlanPassingLetter = 93;
         public int UploadApprovedSketch = 94;
         public int AccountDues = 95;
         public int WaterDues = 96;
         public int OtherDues = 97;
         public int DrainageDues = 98;
         public int NDCAccount = 99;
         public int NDCEngineering = 100;
         public int OSINST_A = 101;
         public int OSIDPPI_A = 102;
         public int OSSC_A = 103;
         public int OSSC_ST = 104;
         public int OSSC_EC = 105;
         public int OSSWCSC = 106;
         public int OSSCKKC = 107;
         public int OSNAA_A = 108;
         public int OSNAA_ST = 109;
         public int OSNAA_EC = 110;
         public int OSSWCNAA = 111;
         public int OSNAAKKC = 112;
         public int OSLR_A = 113;
         public int OSLR_ST = 114;
         public int OSLR_EC = 115;
         public int OSSWCLR = 116;
         public int OSLRKKC = 117;
         public int OSIR_A = 118;
         public int OSIUF_A = 119;
         public int OSIUF_ST = 120;
         public int OSIUF_EC = 121;
         public int OSFULLPAYMENT_A = 122;
         public int PartyCode = 123;
         public int IsFromMobileApp = 124;
         public int LRCOSINST_A = 125;
         public int LRCOSIDP_A = 126;
         public int SGSTAmount = 127;
         public int CGSTAmount = 128;
         public int ACCHEAD_C = 129;
         public int ACC_M = 130;
         public int FROM_D = 131;
         public int TO_D = 132;
         public int ACC_NO = 133;
         public int SGST_A = 134;
         public int CGST_A = 135;
         public int ACC_N = 136;
         public int AC_SGSTAmount = 137;
         public int AC_CGSTAmount = 138;
         public int AC_ACCHEAD_C = 139;
         public int AC_ACC_M = 140;
         public int AC_FROM_D = 141;
         public int AC_TO_D = 142;
         public int AC_ACC_NO = 143;
         public int AC_SGST_A = 144;
         public int AC_CGST_A = 145;
         public int AC_ACC_N = 146;
         public int EN_SGSTAmount = 147;
         public int EN_CGSTAmount = 148;
         public int EN_ACCHEAD_C = 149;
         public int EN_ACC_M = 150;
         public int EN_FROM_D = 151;
         public int EN_TO_D = 152;
         public int EN_ACC_NO = 153;
         public int EN_SGST_A = 154;
         public int EN_CGST_A = 155;
         public int EN_ACC_N = 156;
         public int AlloteeGSTNo = 157;
         public int AlloteeName = 158;
         public int SC_OS_CGST = 159;
         public int SC_OS_SGST = 160;
         public int NAA_OS_CGST = 161;
         public int NAA_OS_SGST = 162;
         public int LR_OS_CGST = 163;
         public int LR_OS_SGST = 164;
         public int INTREV_OS_CGST = 165;
         public int INTREV_OS_SGST = 166;
         public int SC_BASE = 167;
         public int SC_SGSTAmount = 168;
         public int SC_CGSTAmount = 169;
         public int SC_ACCHEAD_C = 170;
         public int SC_ACC_M = 171;
         public int SC_FROM_D = 172;
         public int SC_TO_D = 173;
         public int SC_ACC_NO = 174;
         public int SC_SGST_A = 175;
         public int SC_CGST_A = 176;
         public int SC_ACC_N = 177;
         public int NAA_BASE = 178;
         public int NAA_SGSTAmount = 179;
         public int NAA_CGSTAmount = 180;
         public int NAA_ACCHEAD_C = 181;
         public int NAA_ACC_M = 182;
         public int NAA_FROM_D = 183;
         public int NAA_TO_D = 184;
         public int NAA_ACC_NO = 185;
         public int NAA_SGST_A = 186;
         public int NAA_CGST_A = 187;
         public int NAA_ACC_N = 188;
         public int LR_BASE = 189;
         public int LR_SGSTAmount = 190;
         public int LR_CGSTAmount = 191;
         public int LR_ACCHEAD_C = 192;
         public int LR_ACC_M = 193;
         public int LR_FROM_D = 194;
         public int LR_TO_D = 195;
         public int LR_ACC_NO = 196;
         public int LR_SGST_A = 197;
         public int LR_CGST_A = 198;
         public int LR_ACC_N = 199;
         public int INT_BASE = 200;
         public int INT_SGSTAmount = 201;
         public int INT_CGSTAmount = 202;
         public int INT_ACCHEAD_C = 203;
         public int INT_ACC_M = 204;
         public int INT_FROM_D = 205;
         public int INT_TO_D = 206;
         public int INT_ACC_NO = 207;
         public int INT_SGST_A = 208;
         public int INT_CGST_A = 209;
         public int INT_ACC_N = 210;
         public int IsSEZ = 211;
         public int REVINT_CSGST_OS = 212;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertCRDailyApplicationDetailsForAmalgamation
      public class SPInsertCRDailyApplicationDetailsForAmalgamation
      {
         public string SPName = "SPInsertCRDailyApplicationDetailsForAmalgamation";
         public int ApplicationId = 0;
         public int ApplicationFormId = 1;
         public int AppForwardDate = 2;
         public int AppActualForwardDate = 3;
         public int ActionId = 4;
         public int AssignRoleId = 5;
         public int EstateId = 6;
         public int Remark = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectBuildingPlanArchiveApprovalApplication
      public class SPSelectBuildingPlanArchiveApprovalApplication
      {
         public string SPName = "SPSelectBuildingPlanArchiveApprovalApplication";
         public int AssignedRoleId = 0;
         public int SearchValue = 1;
         public int SearchId = 2;
         public int RegionId = 3;
         public int UserId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdatePaymentDetailsFor2R17032017
      public class SPUpdatePaymentDetailsFor2R17032017
      {
         public string SPName = "SPUpdatePaymentDetailsFor2R17032017";
         public int ApplicationFormId = 0;
         public int TxId = 1;
         public int TxRefNo = 2;
         public int TxStatus = 3;
         public int TxAmount = 4;
         public int TxMsg = 5;
         public int pgTxnNo = 6;
         public int issuerRefNo = 7;
         public int authIdCode = 8;
         public int firstName = 9;
         public int lastName = 10;
         public int pgRespCode = 11;
         public int addressZip = 12;
         public int signature = 13;
         public int TwoRPlotId = 14;
         public int paymentMode = 15;
         public int TxGateway = 16;
         public int cardType = 17;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPAMBackwardToDAApplication
      public class SPAMBackwardToDAApplication
      {
         public string SPName = "SPAMBackwardToDAApplication";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
         public int BackwardRemark = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpSelectGrievanceEstateMasterByRegionId
      public class SpSelectGrievanceEstateMasterByRegionId
      {
         public string SPName = "SpSelectGrievanceEstateMasterByRegionId";
         public int RegionId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region GetCRProgressReportforHO
      public class GetCRProgressReportforHO
      {
         public string SPName = "GetCRProgressReportforHO";
         public int RegionId = 0;
         public int EmployeeCode = 1;
         public int Designation = 2;
         public int ClassId = 3;
         public int Name = 4;
         public int CurrentRatingId = 5;
         public int ReportName = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpWaterSupplyApplicationRemarksHistoryReport
      public class SpWaterSupplyApplicationRemarksHistoryReport
      {
         public string SPName = "SpWaterSupplyApplicationRemarksHistoryReport";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPHelpdeskForwardToAMTwoRApplication
      public class SPHelpdeskForwardToAMTwoRApplication
      {
         public string SPName = "SPHelpdeskForwardToAMTwoRApplication";
         public int ApplicationFormId = 0;
         public int AssignedRoleId = 1;
         public int ModifiedBy = 2;
         public int BackwardRemark = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSubDivisionUpdateRoleWiseByAdmin05012016
      public class SPSubDivisionUpdateRoleWiseByAdmin05012016
      {
         public string SPName = "SPSubDivisionUpdateRoleWiseByAdmin05012016";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int ActionId = 2;
         public int AssignedRoleId = 3;
         public int RemarksCommon = 4;
         public int EstablishingDA = 5;
         public int ExistingPartnersDA = 6;
         public int BuildingPlanDA = 7;
         public int OriginalPlotDA = 8;
         public int OriginalPlotSubDA = 9;
         public int NOCDA = 10;
         public int FeesDA = 11;
         public int DDPlanDA = 12;
         public int SketchDA = 13;
         public int UndertakingDA = 14;
         public int GCDA = 15;
         public int ElectricityDA = 16;
         public int WaterSupplyDA = 17;
         public int EstablishingAM = 18;
         public int ExistingPartnersAM = 19;
         public int BuildingPlanAM = 20;
         public int OriginalPlotAM = 21;
         public int OriginalPlotSubAM = 22;
         public int NOCAM = 23;
         public int FeesAM = 24;
         public int DDPlanAM = 25;
         public int SketchAM = 26;
         public int UndertakingAM = 27;
         public int GCAM = 28;
         public int ElectricityAM = 29;
         public int WaterSupplyAM = 30;
         public int EstablishingRM = 31;
         public int ExistingPartnersRM = 32;
         public int BuildingPlanRM = 33;
         public int OriginalPlotRM = 34;
         public int OriginalPlotSubRM = 35;
         public int NOCRM = 36;
         public int FeesRM = 37;
         public int DDPlanRM = 38;
         public int SketchRM = 39;
         public int UndertakingRM = 40;
         public int GCRM = 41;
         public int ElectricityRM = 42;
         public int WaterSupplyRM = 43;
         public int EstablishingDM = 44;
         public int ExistingPartnersDM = 45;
         public int BuildingPlanDM = 46;
         public int OriginalPlotDM = 47;
         public int OriginalPlotSubDM = 48;
         public int NOCDM = 49;
         public int FeesDM = 50;
         public int DDPlanDM = 51;
         public int SketchDM = 52;
         public int UndertakingDM = 53;
         public int GCDM = 54;
         public int ElectricityDM = 55;
         public int WaterSupplyDM = 56;
         public int EstablishingVCMD = 57;
         public int ExistingPartnersVCMD = 58;
         public int BuildingPlanVCMD = 59;
         public int OriginalPlotVCMD = 60;
         public int OriginalPlotSubVCMD = 61;
         public int NOCVCMD = 62;
         public int FeesVCMD = 63;
         public int DDPlanVCMD = 64;
         public int SketchVCMD = 65;
         public int UndertakingVCMD = 66;
         public int GCVCMD = 67;
         public int ElectricityVCMD = 68;
         public int WaterSupplyVCMD = 69;
         public int RoleId = 70;
         public int AssignActionId = 71;
         public int Flag = 72;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateAmalgamationDocumentTransaction
      public class SPInsertUpdateAmalgamationDocumentTransaction
      {
         public string SPName = "SPInsertUpdateAmalgamationDocumentTransaction";
         public int Mode = 0;
         public int ApplicationFormId = 1;
         public int Documentmasterid = 2;
         public int RoleId = 3;
         public int UserId = 4;
         public int DocumentOKorNotOKDA = 5;
         public int DocumentRemarksDA = 6;
         public int DocumentOKorNotOKAM = 7;
         public int DocumentRemarksAM = 8;
         public int DocumentOKorNotOKRM = 9;
         public int DocumentRemarksRM = 10;
         public int Document = 11;
         public int Remarks = 12;
         public int ActionId = 13;
         public int AssignActionId = 14;
         public int AssignedRoleId = 15;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectEstateMasterForPlanAuthority
      public class SPSelectEstateMasterForPlanAuthority
      {
         public string SPName = "SPSelectEstateMasterForPlanAuthority";
         public int regionId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateSurrenderApplicationInManagerHOLoop
      public class SpUpdateSurrenderApplicationInManagerHOLoop
      {
         public string SPName = "SpUpdateSurrenderApplicationInManagerHOLoop";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int NewAssinedActionId = 2;
         public int AssignedRoleId = 3;
         public int DepartmentId = 4;
         public int Remarks = 5;
         public int HOAdditionalDocs = 6;
         public int BranchUserId = 7;
         public int CurrentBranchId = 8;
         public int ConstructionValue = 9;
         public int SiteVerificationReport = 10;
         public int IsPlotOROpenConstructed = 11;
         public int IsForwardToHOManager = 12;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateIndustryTypeMaster
      public class SPInsertUpdateIndustryTypeMaster
      {
         public string SPName = "SPInsertUpdateIndustryTypeMaster";
         public int IndustryTypeId = 0;
         public int IndustryType = 1;
         public int UserId = 2;
         public int IsActive = 3;
         public int Operation = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertTwoRApplicationModulePlotDetails17032017
      public class SPInsertTwoRApplicationModulePlotDetails17032017
      {
         public string SPName = "SPInsertTwoRApplicationModulePlotDetails17032017";
         public int ApplicationFormId = 0;
         public int RegionId = 1;
         public int EstateId = 2;
         public int PlotShedTypeId = 3;
         public int PlotShedNumber = 4;
         public int LeadPlot = 5;
         public int AlloteeName = 6;
         public int PlotAllotmentDate = 7;
         public int PlotArea = 8;
         public int CreatedBy = 9;
         public int ACC_DUES = 10;
         public int WATER_DUES = 11;
         public int DRNG_DUES = 12;
         public int Other_DUES = 13;
         public int FinancialYear = 14;
         public int OraRegionId = 15;
         public int OraEstateId = 16;
         public int PartyCode = 17;
         public int OSINST_A = 18;
         public int OSIDPPI_A = 19;
         public int OSSC_A = 20;
         public int OSSC_ST = 21;
         public int OSSC_EC = 22;
         public int OSSWCSC = 23;
         public int OSSCKKC = 24;
         public int OSNAA_A = 25;
         public int OSNAA_ST = 26;
         public int OSNAA_EC = 27;
         public int OSSWCNAA = 28;
         public int OSNAAKKC = 29;
         public int OSLR_A = 30;
         public int OSLR_ST = 31;
         public int OSLR_EC = 32;
         public int OSSWCLR = 33;
         public int OSLRKKC = 34;
         public int OSIR_A = 35;
         public int OSIUF_A = 36;
         public int OSIUF_ST = 37;
         public int OSIUF_EC = 38;
         public int OSFULLPAYMENT_A = 39;
         public int LRCOSINST_A = 40;
         public int LRCOSIDP_A = 41;
         public int PlotDeedDate = 42;
         public int AC_SGSTAmount = 43;
         public int AC_CGSTAmount = 44;
         public int AC_ACCHEAD_C = 45;
         public int AC_ACC_M = 46;
         public int AC_FROM_D = 47;
         public int AC_TO_D = 48;
         public int AC_ACC_NO = 49;
         public int AC_SGST_A = 50;
         public int AC_CGST_A = 51;
         public int AC_ACC_N = 52;
         public int EN_SGSTAmount = 53;
         public int EN_CGSTAmount = 54;
         public int EN_ACCHEAD_C = 55;
         public int EN_ACC_M = 56;
         public int EN_FROM_D = 57;
         public int EN_TO_D = 58;
         public int EN_ACC_NO = 59;
         public int EN_SGST_A = 60;
         public int EN_CGST_A = 61;
         public int EN_ACC_N = 62;
         public int ABC = 63;
         public int SC_OS_CGST = 64;
         public int SC_OS_SGST = 65;
         public int NAA_OS_CGST = 66;
         public int NAA_OS_SGST = 67;
         public int LR_OS_CGST = 68;
         public int LR_OS_SGST = 69;
         public int INTREV_OS_CGST = 70;
         public int INTREV_OS_SGST = 71;
         public int SC_BaseAmount = 72;
         public int NAA_BaseAmount = 73;
         public int LR_BaseAmount = 74;
         public int INT_BaseAmount = 75;
         public int SC_ACCHEAD_C = 76;
         public int SC_ACC_M = 77;
         public int SC_FROM_D = 78;
         public int SC_TO_D = 79;
         public int SC_ACC_NO = 80;
         public int SC_SGST_A = 81;
         public int SC_CGST_A = 82;
         public int SC_ACC_N = 83;
         public int SC_SGSTAmount = 84;
         public int SC_CGSTAmount = 85;
         public int NAA_ACCHEAD_C = 86;
         public int NAA_ACC_M = 87;
         public int NAA_FROM_D = 88;
         public int NAA_TO_D = 89;
         public int NAA_ACC_NO = 90;
         public int NAA_SGST_A = 91;
         public int NAA_CGST_A = 92;
         public int NAA_ACC_N = 93;
         public int NAA_SGSTAmount = 94;
         public int NAA_CGSTAmount = 95;
         public int LR_ACCHEAD_C = 96;
         public int LR_ACC_M = 97;
         public int LR_FROM_D = 98;
         public int LR_TO_D = 99;
         public int LR_ACC_NO = 100;
         public int LR_SGST_A = 101;
         public int LR_CGST_A = 102;
         public int LR_ACC_N = 103;
         public int LR_SGSTAmount = 104;
         public int LR_CGSTAmount = 105;
         public int INT_ACCHEAD_C = 106;
         public int INT_ACC_M = 107;
         public int INT_FROM_D = 108;
         public int INT_TO_D = 109;
         public int INT_ACC_NO = 110;
         public int INT_SGST_A = 111;
         public int INT_CGST_A = 112;
         public int INT_ACC_N = 113;
         public int INT_SGSTAmount = 114;
         public int INT_CGSTAmount = 115;
         public int AssignmentDeedDate = 116;
         public int RectificationDate = 117;
         public int ConveyanceDeedDate = 118;
         public int SEZ = 119;
         public int REVINT_CSGST_OS = 120;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertActionTransactionEntryLease
      public class SPInsertActionTransactionEntryLease
      {
         public string SPName = "SPInsertActionTransactionEntryLease";
         public int ActionId = 0;
         public int ApplicationFormId = 1;
         public int ApplicationId = 2;
         public int BackwardRemark = 3;
         public int createdBy = 4;
         public int ActForwardDate = 5;
         public int CycleId = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateGSTNoforWaterSupplyApplication
      public class SPUpdateGSTNoforWaterSupplyApplication
      {
         public string SPName = "SPUpdateGSTNoforWaterSupplyApplication";
         public int ApplicationFormId = 0;
         public int AlloteeGSTNo = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectCRReportDetails
      public class SPSelectCRReportDetails
      {
         public string SPName = "SPSelectCRReportDetails";
         public int EmployeeCode = 0;
         public int Received = 1;
         public int Month = 2;
         public int applicationid = 3;
         public int Year = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPHelpdeskForwardToRMTwoRApplication
      public class SPHelpdeskForwardToRMTwoRApplication
      {
         public string SPName = "SPHelpdeskForwardToRMTwoRApplication";
         public int ApplicationFormId = 0;
         public int AssignedRoleId = 1;
         public int ModifiedBy = 2;
         public int BackwardRemark = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubDivisionModuleByApplicationFormIdForView
      public class SPSelectSubDivisionModuleByApplicationFormIdForView
      {
         public string SPName = "SPSelectSubDivisionModuleByApplicationFormIdForView";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateGeneralApplicationForIFP
      public class SPUpdateGeneralApplicationForIFP
      {
         public string SPName = "SPUpdateGeneralApplicationForIFP";
         public int ApplicationFormId = 0;
         public int IFP_ApplicationId = 1;
         public int IsIFP_Sync = 2;
         public int IFPActionId = 3;
         public int Operation = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetPendingDayFromLastActionAtGIDCendForSubdivisionModule
      public class SPGetPendingDayFromLastActionAtGIDCendForSubdivisionModule
      {
         public string SPName = "SPGetPendingDayFromLastActionAtGIDCendForSubdivisionModule";
         public int ApplicationFormId = 0;
         public int Days = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteIndustryTypeMasterByIndustryTypeId
      public class SPDeleteIndustryTypeMasterByIndustryTypeId
      {
         public string SPName = "SPDeleteIndustryTypeMasterByIndustryTypeId";
         public int IndustryTypeId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectBuildingPlanViewApplicationList
      public class SPSelectBuildingPlanViewApplicationList
      {
         public string SPName = "SPSelectBuildingPlanViewApplicationList";
         public int AssignedRoleId = 0;
         public int SearchValue = 1;
         public int SearchId = 2;
         public int RegionId = 3;
         public int UserId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDUMMYCRYSTALREPORT
      public class SPDUMMYCRYSTALREPORT
      {
         public string SPName = "SPDUMMYCRYSTALREPORT";
         public int applicationformid = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateForwardDateLease
      public class SPUpdateForwardDateLease
      {
         public string SPName = "SPUpdateForwardDateLease";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
         public int CycleId = 2;
         public int flag = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateGSTNoforDrainageApplication
      public class SPUpdateGSTNoforDrainageApplication
      {
         public string SPName = "SPUpdateGSTNoforDrainageApplication";
         public int ApplicationFormId = 0;
         public int AlloteeGSTNo = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteRoleEstateMappingByUserId
      public class SPDeleteRoleEstateMappingByUserId
      {
         public string SPName = "SPDeleteRoleEstateMappingByUserId";
         public int UserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSubDivisionUpdateApplicationForTechnicalScrutiny05012016
      public class SPSubDivisionUpdateApplicationForTechnicalScrutiny05012016
      {
         public string SPName = "SPSubDivisionUpdateApplicationForTechnicalScrutiny05012016";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int RoleId = 2;
         public int CurrentApplicationActionId = 3;
         public int AssignedRoleId = 4;
         public int ActionId = 5;
         public int IsPlotRegularShape = 6;
         public int IsTheirAnyMarginRelaxation = 7;
         public int MarginSketch = 8;
         public int MarginAreaTable = 9;
         public int Islocated9Mtr = 10;
         public int IsPlotFacingGIDCRoad500sqrMtr = 11;
         public int IsWidthDepthRatiomaintained = 12;
         public int IsCOPKeptMaintained = 13;
         public int IsWidthOfRoadMaintained = 14;
         public int IsCommonArea = 15;
         public int IsAnyAdditionalInfrastructure = 16;
         public int IsAnyAdditionalEntryPoint = 17;
         public int IsMinimum50PerConstruction = 18;
         public int Udertakingof50Per = 19;
         public int IsCommonFacilityCpo = 20;
         public int IsPreventingGDCR = 21;
         public int UploadSketchAcceptance = 22;
         public int UploadSketchofGDCR = 23;
         public int DDPlanShowingLocation = 24;
         public int Remark = 25;
         public int GCDocument = 26;
         public int IsAgree = 27;
         public int ChangeRemarks = 28;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpInsertUpdateAmalgamationMdoduleAdmin
      public class SpInsertUpdateAmalgamationMdoduleAdmin
      {
         public string SPName = "SpInsertUpdateAmalgamationMdoduleAdmin";
         public int Mode = 0;
         public int ApplicationformId = 1;
         public int RoleId = 2;
         public int ActionId = 3;
         public int UserId = 4;
         public int AssignedRoleId = 5;
         public int AssignActionId = 6;
         public int Remarks = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SP_UpdatePartyCode
      public class SP_UpdatePartyCode
      {
         public string SPName = "SP_UpdatePartyCode";
         public int Mode = 0;
         public int PlotShedNo = 1;
         public int partyCode = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectIncompleteTwoRApplicationDocument
      public class SPSelectIncompleteTwoRApplicationDocument
      {
         public string SPName = "SPSelectIncompleteTwoRApplicationDocument";
         public int RoleId = 0;
         public int ApplicationFormId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetPendingDayFromLastActionAtGIDCendFor2R
      public class SPGetPendingDayFromLastActionAtGIDCendFor2R
      {
         public string SPName = "SPGetPendingDayFromLastActionAtGIDCendFor2R";
         public int ReferenceNo = 0;
         public int Days = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTwoRApplicationModulePlotDetails17032017
      public class SPSelectTwoRApplicationModulePlotDetails17032017
      {
         public string SPName = "SPSelectTwoRApplicationModulePlotDetails17032017";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectApplicationPaymentDetailSubDivisionByApplicationFormId05012017
      public class SPSelectApplicationPaymentDetailSubDivisionByApplicationFormId05012017
      {
         public string SPName = "SPSelectApplicationPaymentDetailSubDivisionByApplicationFormId05012017";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateAmalgamationApplicationByApplicationFormId
      public class SPUpdateAmalgamationApplicationByApplicationFormId
      {
         public string SPName = "SPUpdateAmalgamationApplicationByApplicationFormId";
         public int ApplicationFormId = 0;
         public int EstateId = 1;
         public int RegionId = 2;
         public int TypeofPlotShed = 3;
         public int PlotShedNo = 4;
         public int PlotShedArea = 5;
         public int AllotmentDate = 6;
         public int isChemical = 7;
         public int NameofUnit = 8;
         public int UnitConstitutionType = 9;
         public int ApplicantName = 10;
         public int ApplicantLandLine = 11;
         public int ApplicantMobile = 12;
         public int ApplicantEmail = 13;
         public int RelationId = 14;
         public int ApplicantIdentity = 15;
         public int ApplicantRegOfficeAddress = 16;
         public int ApplicantRegOfficeAddressProof = 17;
         public int IsNameofUnitdiff = 18;
         public int NameofTransferorFTO = 19;
         public int FinalTransferOrder = 20;
         public int RegOfficeAddressFTO = 21;
         public int RegOfficeAddressIdentityFTO = 22;
         public int IsMoreThenOneAllotted = 23;
         public int IsMoreThenOneAdjacentPlot = 24;
         public int IsBuildingApproved = 25;
         public int BuildingPlanApprovalDuration = 26;
         public int DateofApprovedBuildingPlan = 27;
         public int IsPlotUtilizedBefore = 28;
         public int IsConstructionLessThan20 = 29;
         public int IsConstructionAsPerCircular = 30;
         public int IsPlotsUtilizedAfter = 31;
         public int IsPlots20PerMinConstruction = 32;
         public int IsPlotsAsPerGDCRofGIDC = 33;
         public int IsMarginRelaxationReq = 34;
         public int IsApprovedAsPerVCMD = 35;
         public int IsNocObtained = 36;
         public int NOCApprovalLetterNo = 37;
         public int NOCApprovalDate = 38;
         public int UploadNOC = 39;
         public int IsProposalApproved = 40;
         public int NameofLocalAuthority = 41;
         public int PlanPassingLetterNo = 42;
         public int PlanPassingLetterDate = 43;
         public int UploadPlanPassingLetter = 44;
         public int UploadApprovedSketch = 45;
         public int IsSubmitted = 46;
         public int CreatedBy = 47;
         public int ModifiedBy = 48;
         public int SectionType = 49;
         public int NameofApplicant = 50;
         public int AdminCharge = 51;
         public int AdminKKC = 52;
         public int AdminSBC = 53;
         public int AdminST = 54;
         public int TotalAdministrativeCharge = 55;
         public int ACC_DUES = 56;
         public int WATER_DUES = 57;
         public int DRAINAGE_DUES = 58;
         public int Other_DUES = 59;
         public int NoDuesRM = 60;
         public int NoDuesEngineering = 61;
         public int OCADocument = 62;
         public int DocumentXML = 63;
         public int PartyCode = 64;
         public int OSINST_A = 65;
         public int OSIDPPI_A = 66;
         public int OSSC_A = 67;
         public int OSSC_ST = 68;
         public int OSSC_EC = 69;
         public int OSSWCSC = 70;
         public int OSSCKKC = 71;
         public int OSNAA_A = 72;
         public int OSNAA_ST = 73;
         public int OSNAA_EC = 74;
         public int OSSWCNAA = 75;
         public int OSNAAKKC = 76;
         public int OSLR_A = 77;
         public int OSLR_ST = 78;
         public int OSLR_EC = 79;
         public int OSSWCLR = 80;
         public int OSLRKKC = 81;
         public int OSIR_A = 82;
         public int OSIUF_A = 83;
         public int OSIUF_ST = 84;
         public int OSIUF_EC = 85;
         public int OSFULLPAYMENT_A = 86;
         public int IsFromMobileApp = 87;
         public int LRCOSINST_A = 88;
         public int LRCOSIDP_A = 89;
         public int SGSTAmount = 90;
         public int CGSTAmount = 91;
         public int ACCHEAD_C = 92;
         public int ACC_M = 93;
         public int FROM_D = 94;
         public int TO_D = 95;
         public int ACC_NO = 96;
         public int SGST_A = 97;
         public int CGST_A = 98;
         public int ACC_N = 99;
         public int AC_SGSTAmount = 100;
         public int AC_CGSTAmount = 101;
         public int AC_ACCHEAD_C = 102;
         public int AC_ACC_M = 103;
         public int AC_FROM_D = 104;
         public int AC_TO_D = 105;
         public int AC_ACC_NO = 106;
         public int AC_SGST_A = 107;
         public int AC_CGST_A = 108;
         public int AC_ACC_N = 109;
         public int EN_SGSTAmount = 110;
         public int EN_CGSTAmount = 111;
         public int EN_ACCHEAD_C = 112;
         public int EN_ACC_M = 113;
         public int EN_FROM_D = 114;
         public int EN_TO_D = 115;
         public int EN_ACC_NO = 116;
         public int EN_SGST_A = 117;
         public int EN_CGST_A = 118;
         public int EN_ACC_N = 119;
         public int SC_SGSTAmount = 120;
         public int SC_CGSTAmount = 121;
         public int SC_ACCHEAD_C = 122;
         public int SC_ACC_M = 123;
         public int SC_FROM_D = 124;
         public int SC_TO_D = 125;
         public int SC_ACC_NO = 126;
         public int SC_SGST_A = 127;
         public int SC_CGST_A = 128;
         public int SC_ACC_N = 129;
         public int SC_BaseAmount = 130;
         public int NAA_SGSTAmount = 131;
         public int NAA_CGSTAmount = 132;
         public int NAA_ACCHEAD_C = 133;
         public int NAA_ACC_M = 134;
         public int NAA_FROM_D = 135;
         public int NAA_TO_D = 136;
         public int NAA_ACC_NO = 137;
         public int NAA_SGST_A = 138;
         public int NAA_CGST_A = 139;
         public int NAA_ACC_N = 140;
         public int NAA_BaseAmount = 141;
         public int LR_SGSTAmount = 142;
         public int LR_CGSTAmount = 143;
         public int LR_ACCHEAD_C = 144;
         public int LR_ACC_M = 145;
         public int LR_FROM_D = 146;
         public int LR_TO_D = 147;
         public int LR_ACC_NO = 148;
         public int LR_SGST_A = 149;
         public int LR_CGST_A = 150;
         public int LR_ACC_N = 151;
         public int LR_BaseAmount = 152;
         public int INT_SGSTAmount = 153;
         public int INT_CGSTAmount = 154;
         public int INT_ACCHEAD_C = 155;
         public int INT_ACC_M = 156;
         public int INT_FROM_D = 157;
         public int INT_TO_D = 158;
         public int INT_ACC_NO = 159;
         public int INT_SGST_A = 160;
         public int INT_CGST_A = 161;
         public int INT_ACC_N = 162;
         public int INT_BaseAmount = 163;
         public int SC_OS_CGST = 164;
         public int SC_OS_SGST = 165;
         public int NAA_OS_CGST = 166;
         public int NAA_OS_SGST = 167;
         public int LR_OS_CGST = 168;
         public int LR_OS_SGST = 169;
         public int INTREV_OS_CGST = 170;
         public int INTREV_OS_SGST = 171;
         public int AlloteeGSTNo = 172;
         public int IsSEZ = 173;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSubDivisionApplicationDetailsReportNew
      public class SPSubDivisionApplicationDetailsReportNew
      {
         public string SPName = "SPSubDivisionApplicationDetailsReportNew";
         public int REGIONID = 0;
         public int ACTIONID = 1;
         public int ActionType = 2;
         public int BeforeAfter = 3;
         public int OldApplicationStatusId = 4;
         public int PTOIssueCMD = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPTWORAPPLICATIONDETAILSREPORTOLD
      public class SPTWORAPPLICATIONDETAILSREPORTOLD
      {
         public string SPName = "SPTWORAPPLICATIONDETAILSREPORTOLD";
         public int REGIONID = 0;
         public int ACTIONID = 1;
         public int ActionType = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectRegionAddressCurrentYearByEstateId
      public class SPSelectRegionAddressCurrentYearByEstateId
      {
         public string SPName = "SPSelectRegionAddressCurrentYearByEstateId";
         public int EstateId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPAMBackwardToDALeaseDocument
      public class SPAMBackwardToDALeaseDocument
      {
         public string SPName = "SPAMBackwardToDALeaseDocument";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
         public int BackwardRemark = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region UpdateApplicationGSTNoWhilePOPayment
      public class UpdateApplicationGSTNoWhilePOPayment
      {
         public string SPName = "UpdateApplicationGSTNoWhilePOPayment";
         public int ApplicationFormId = 0;
         public int AlloteeGSTNo = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectUserEstate
      public class SPSelectUserEstate
      {
         public string SPName = "SPSelectUserEstate";
         public int UserId = 0;
         public int ApplicationId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubdivisionApplicationPaymentDetailByApplicationFormId
      public class SPSelectSubdivisionApplicationPaymentDetailByApplicationFormId
      {
         public string SPName = "SPSelectSubdivisionApplicationPaymentDetailByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectOracleRegionEstateIdByRegionEstateId07042018
      public class SPSelectOracleRegionEstateIdByRegionEstateId07042018
      {
         public string SPName = "SPSelectOracleRegionEstateIdByRegionEstateId07042018";
         public int RegionId = 0;
         public int EstateId = 1;
         public int PlotTypeId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSurrenderHOFlowUserRoleCount
      public class SPSelectSurrenderHOFlowUserRoleCount
      {
         public string SPName = "SPSelectSurrenderHOFlowUserRoleCount";
         public int BranchId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertAmalgamationApplication
      public class SPInsertAmalgamationApplication
      {
         public string SPName = "SPInsertAmalgamationApplication";
         public int ReferenceNo = 0;
         public int EstateId = 1;
         public int RegionId = 2;
         public int TypeofPlotShed = 3;
         public int PlotShedNo = 4;
         public int PlotShedArea = 5;
         public int AllotmentDate = 6;
         public int isChemical = 7;
         public int NameofUnit = 8;
         public int UnitConstitutionType = 9;
         public int ApplicantName = 10;
         public int ApplicantLandLine = 11;
         public int ApplicantMobile = 12;
         public int ApplicantEmail = 13;
         public int RelationId = 14;
         public int ApplicantIdentity = 15;
         public int ApplicantRegOfficeAddress = 16;
         public int ApplicantRegOfficeAddressProof = 17;
         public int IsNameofUnitdiff = 18;
         public int NameofTransferorFTO = 19;
         public int FinalTransferOrder = 20;
         public int RegOfficeAddressFTO = 21;
         public int RegOfficeAddressIdentityFTO = 22;
         public int IsMoreThenOneAllotted = 23;
         public int IsMoreThenOneAdjacentPlot = 24;
         public int IsBuildingApproved = 25;
         public int BuildingPlanApprovalDuration = 26;
         public int DateofApprovedBuildingPlan = 27;
         public int IsPlotUtilizedBefore = 28;
         public int IsConstructionLessThan20 = 29;
         public int IsConstructionAsPerCircular = 30;
         public int IsPlotsUtilizedAfter = 31;
         public int IsPlots20PerMinConstruction = 32;
         public int IsPlotsAsPerGDCRofGIDC = 33;
         public int IsMarginRelaxationReq = 34;
         public int IsApprovedAsPerVCMD = 35;
         public int IsNocObtained = 36;
         public int NOCApprovalLetterNo = 37;
         public int NOCApprovalDate = 38;
         public int UploadNOC = 39;
         public int IsProposalApproved = 40;
         public int NameofLocalAuthority = 41;
         public int PlanPassingLetterNo = 42;
         public int PlanPassingLetterDate = 43;
         public int UploadPlanPassingLetter = 44;
         public int UploadApprovedSketch = 45;
         public int IsSubmitted = 46;
         public int CreatedBy = 47;
         public int ModifiedBy = 48;
         public int SectionType = 49;
         public int OCACopy = 50;
         public int AdminCharge = 51;
         public int AdminKKC = 52;
         public int AdminSBC = 53;
         public int AdminST = 54;
         public int TotalAdministrativeCharge = 55;
         public int ACC_DUES = 56;
         public int WATER_DUES = 57;
         public int DRAINAGE_DUES = 58;
         public int Other_DUES = 59;
         public int NoDuesRM = 60;
         public int NoDuesEngineering = 61;
         public int OCADocument = 62;
         public int DocumentXML = 63;
         public int PartyCode = 64;
         public int OSINST_A = 65;
         public int OSIDPPI_A = 66;
         public int OSSC_A = 67;
         public int OSSC_ST = 68;
         public int OSSC_EC = 69;
         public int OSSWCSC = 70;
         public int OSSCKKC = 71;
         public int OSNAA_A = 72;
         public int OSNAA_ST = 73;
         public int OSNAA_EC = 74;
         public int OSSWCNAA = 75;
         public int OSNAAKKC = 76;
         public int OSLR_A = 77;
         public int OSLR_ST = 78;
         public int OSLR_EC = 79;
         public int OSSWCLR = 80;
         public int OSLRKKC = 81;
         public int OSIR_A = 82;
         public int OSIUF_A = 83;
         public int OSIUF_ST = 84;
         public int OSIUF_EC = 85;
         public int OSFULLPAYMENT_A = 86;
         public int IsFromMobileApp = 87;
         public int LRCOSINST_A = 88;
         public int LRCOSIDP_A = 89;
         public int SGSTAmount = 90;
         public int CGSTAmount = 91;
         public int ACCHEAD_C = 92;
         public int ACC_M = 93;
         public int FROM_D = 94;
         public int TO_D = 95;
         public int ACC_NO = 96;
         public int SGST_A = 97;
         public int CGST_A = 98;
         public int ACC_N = 99;
         public int AC_SGSTAmount = 100;
         public int AC_CGSTAmount = 101;
         public int AC_ACCHEAD_C = 102;
         public int AC_ACC_M = 103;
         public int AC_FROM_D = 104;
         public int AC_TO_D = 105;
         public int AC_ACC_NO = 106;
         public int AC_SGST_A = 107;
         public int AC_CGST_A = 108;
         public int AC_ACC_N = 109;
         public int EN_SGSTAmount = 110;
         public int EN_CGSTAmount = 111;
         public int EN_ACCHEAD_C = 112;
         public int EN_ACC_M = 113;
         public int EN_FROM_D = 114;
         public int EN_TO_D = 115;
         public int EN_ACC_NO = 116;
         public int EN_SGST_A = 117;
         public int EN_CGST_A = 118;
         public int EN_ACC_N = 119;
         public int SC_SGSTAmount = 120;
         public int SC_CGSTAmount = 121;
         public int SC_ACCHEAD_C = 122;
         public int SC_ACC_M = 123;
         public int SC_FROM_D = 124;
         public int SC_TO_D = 125;
         public int SC_ACC_NO = 126;
         public int SC_SGST_A = 127;
         public int SC_CGST_A = 128;
         public int SC_ACC_N = 129;
         public int SC_BaseAmount = 130;
         public int NAA_SGSTAmount = 131;
         public int NAA_CGSTAmount = 132;
         public int NAA_ACCHEAD_C = 133;
         public int NAA_ACC_M = 134;
         public int NAA_FROM_D = 135;
         public int NAA_TO_D = 136;
         public int NAA_ACC_NO = 137;
         public int NAA_SGST_A = 138;
         public int NAA_CGST_A = 139;
         public int NAA_ACC_N = 140;
         public int NAA_BaseAmount = 141;
         public int LR_SGSTAmount = 142;
         public int LR_CGSTAmount = 143;
         public int LR_ACCHEAD_C = 144;
         public int LR_ACC_M = 145;
         public int LR_FROM_D = 146;
         public int LR_TO_D = 147;
         public int LR_ACC_NO = 148;
         public int LR_SGST_A = 149;
         public int LR_CGST_A = 150;
         public int LR_ACC_N = 151;
         public int LR_BaseAmount = 152;
         public int INT_SGSTAmount = 153;
         public int INT_CGSTAmount = 154;
         public int INT_ACCHEAD_C = 155;
         public int INT_ACC_M = 156;
         public int INT_FROM_D = 157;
         public int INT_TO_D = 158;
         public int INT_ACC_NO = 159;
         public int INT_SGST_A = 160;
         public int INT_CGST_A = 161;
         public int INT_ACC_N = 162;
         public int INT_BaseAmount = 163;
         public int SC_OS_CGST = 164;
         public int SC_OS_SGST = 165;
         public int NAA_OS_CGST = 166;
         public int NAA_OS_SGST = 167;
         public int LR_OS_CGST = 168;
         public int LR_OS_SGST = 169;
         public int INTREV_OS_CGST = 170;
         public int INTREV_OS_SGST = 171;
         public int AlloteeGSTNo = 172;
         public int IsSEZ = 173;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetPendingDayAtGIDCendForSubdivision
      public class SPGetPendingDayAtGIDCendForSubdivision
      {
         public string SPName = "SPGetPendingDayAtGIDCendForSubdivision";
         public int ApplicationFormId = 0;
         public int Days = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectOfficeUserMasterForLogin
      public class SPSelectOfficeUserMasterForLogin
      {
         public string SPName = "SPSelectOfficeUserMasterForLogin";
         public int EmailId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPlotShedNumberByPlotShedDetails
      public class SPSelectPlotShedNumberByPlotShedDetails
      {
         public string SPName = "SPSelectPlotShedNumberByPlotShedDetails";
         public int RegionId = 0;
         public int EstateId = 1;
         public int PlotShedTypeId = 2;
         public int PlotShedNumber = 3;
         public int ApplicationId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpInspectorReplyQuery
      public class SpInspectorReplyQuery
      {
         public string SPName = "SpInspectorReplyQuery";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int SiteInspectionReportAttachment = 2;
         public int InspectionRemarks = 3;
         public int InspectionPhoto = 4;
         public int QueryAnswerDEELine1 = 5;
         public int QueryAnswerDEELine2 = 6;
         public int QueryAnswerDEELine3 = 7;
         public int QueryAnswerDEELine4 = 8;
         public int QueryAnswerDEELine5 = 9;
         public int ActionId = 10;
         public int ReplyAttachmentInspector = 11;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubdivisionApplicationOfficeUserDetailsByRoleIdForEmail
      public class SPSelectSubdivisionApplicationOfficeUserDetailsByRoleIdForEmail
      {
         public string SPName = "SPSelectSubdivisionApplicationOfficeUserDetailsByRoleIdForEmail";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPAMCompliencesAwaited
      public class SPAMCompliencesAwaited
      {
         public string SPName = "SPAMCompliencesAwaited";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region spGetCheckListForSubdivisionModule
      public class spGetCheckListForSubdivisionModule
      {
         public string SPName = "spGetCheckListForSubdivisionModule";
         public int ApplicationFormid = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateSubDivisionApplicationByApplicationFormId
      public class SPUpdateSubDivisionApplicationByApplicationFormId
      {
         public string SPName = "SPUpdateSubDivisionApplicationByApplicationFormId";
         public int ApplicationFormId = 0;
         public int EstateId = 1;
         public int RegionId = 2;
         public int TypeOfPlotShed = 3;
         public int PlotShedNo = 4;
         public int PlotArea = 5;
         public int DateofAllotment = 6;
         public int IsChemical = 7;
         public int NameofApplicant = 8;
         public int ConstitutionTypeId = 9;
         public int ApplicantLandlineNo = 10;
         public int ApplicantMobileNo = 11;
         public int ApplicantEmailId = 12;
         public int IsPlotLessThan250 = 13;
         public int IsPlotMin9MtrGIDC = 14;
         public int IsPlotSubDivisionOpen = 15;
         public int IsPlotSubDivisionUtilized = 16;
         public int IsExistingEntryPointGIDC = 17;
         public int IsCOPOriginalPlot = 18;
         public int IsInternalRoadInSubDivision = 19;
         public int IsProDataCommonAreaDone = 20;
         public int IsAssociationMembersPlot = 21;
         public int IsProposedBetweenFamilyMembers = 22;
         public int FamilyRelationId = 23;
         public int FamilyRelationDocument = 24;
         public int IsExistingPartnerWithExistingGIDC = 25;
         public int ExistingGIDCFamilyRelationId = 26;
         public int ExistingGIDCFamilyRelationDocument = 27;
         public int IsBuildingPlanPlotApproved = 28;
         public int BuldingApprovedDate = 29;
         public int BuldingPlanPassingAuthority = 30;
         public int BuldingPlanDocument = 31;
         public int IsRevisedBuildingPlanPlotApproved = 32;
         public int RevisedBuldingApprovedDate = 33;
         public int RevisedBuldingPlanPassingAuthority = 34;
         public int RevisedBuldingPlanDocument = 35;
         public int IsGIDCInformedPlanApproval = 36;
         public int GIDCInformedDateOfLetter = 37;
         public int GIDCInformedLetterNo = 38;
         public int IsViolativeConstructionPlot = 39;
         public int ViolativeConstructionPlotArea = 40;
         public int IsOriginalPlotSubDivision = 41;
         public int OriginalPlotSubDivisionDateOfSubdivision = 42;
         public int OriginalPlotSubDivisionApprovalAuthority = 43;
         public int OriginalPlotSubDivisionDocument = 44;
         public int IsNocSubDivisionGIDC = 45;
         public int NOCDateApproval = 46;
         public int NOCLetterNo = 47;
         public int NOCDocument = 48;
         public int IsNOCPaidGIDC = 49;
         public int NOCPaidGIDCPaymentDate = 50;
         public int NOCPaidGIDCAmount = 51;
         public int NOCPaidGIDCDocument = 52;
         public int IsIncorporatedGIDCDDPlan = 53;
         public int IncorporatedDate = 54;
         public int IncorporatedDocument = 55;
         public int IsLegalMatterPendingPlot = 56;
         public int CaseNo = 57;
         public int PresentStatus = 58;
         public int DirectionGiven = 59;
         public int NoOfSubDivisionPlot = 60;
         public int PurposeOfSubDivision = 61;
         public int AreaCalculationSheet = 62;
         public int SketchOfSubDivisionDocument = 63;
         public int UndertakingFacilitiesAndAreaDocument = 64;
         public int UndertakingLessThan50GCPlotDocument = 65;
         public int UtilisationElectricityBillDocument = 66;
         public int UtilisationWaterSupplyBillDocument = 67;
         public int SectionType = 68;
         public int ModifiedBy = 69;
         public int ApplicantIdentity = 70;
         public int IsSubmitted = 71;
         public int AdminTotalCharge = 72;
         public int AdminKKC = 73;
         public int AdminSBC = 74;
         public int AdminST = 75;
         public int AdminCharge = 76;
         public int COPArea = 77;
         public int IntarnalArea = 78;
         public int AvailableArea = 79;
         public int UndertakingOfCreation = 80;
         public int TotalAreaper = 81;
         public int COPAreaper = 82;
         public int InternalRoadAreaper = 83;
         public int Availableplotareaper = 84;
         public int IsNocObtained = 85;
         public int NOCApprovalLetterNo = 86;
         public int NOCApprovalDate = 87;
         public int UploadNOC = 88;
         public int IsProposalApproved = 89;
         public int NameofLocalAuthority = 90;
         public int PlanPassingLetterNo = 91;
         public int PlanPassingLetterDate = 92;
         public int UploadPlanPassingLetter = 93;
         public int UploadApprovedSketch = 94;
         public int AccountDues = 95;
         public int WaterDues = 96;
         public int OtherDues = 97;
         public int DrainageDues = 98;
         public int NDCAccount = 99;
         public int NDCEngineering = 100;
         public int OSINST_A = 101;
         public int OSIDPPI_A = 102;
         public int OSSC_A = 103;
         public int OSSC_ST = 104;
         public int OSSC_EC = 105;
         public int OSSWCSC = 106;
         public int OSSCKKC = 107;
         public int OSNAA_A = 108;
         public int OSNAA_ST = 109;
         public int OSNAA_EC = 110;
         public int OSSWCNAA = 111;
         public int OSNAAKKC = 112;
         public int OSLR_A = 113;
         public int OSLR_ST = 114;
         public int OSLR_EC = 115;
         public int OSSWCLR = 116;
         public int OSLRKKC = 117;
         public int OSIR_A = 118;
         public int OSIUF_A = 119;
         public int OSIUF_ST = 120;
         public int OSIUF_EC = 121;
         public int OSFULLPAYMENT_A = 122;
         public int PartyCode = 123;
         public int IsFromMobileApp = 124;
         public int LRCOSINST_A = 125;
         public int LRCOSIDP_A = 126;
         public int SGSTAmount = 127;
         public int CGSTAmount = 128;
         public int ACCHEAD_C = 129;
         public int ACC_M = 130;
         public int FROM_D = 131;
         public int TO_D = 132;
         public int ACC_NO = 133;
         public int SGST_A = 134;
         public int CGST_A = 135;
         public int ACC_N = 136;
         public int AC_SGSTAmount = 137;
         public int AC_CGSTAmount = 138;
         public int AC_ACCHEAD_C = 139;
         public int AC_ACC_M = 140;
         public int AC_FROM_D = 141;
         public int AC_TO_D = 142;
         public int AC_ACC_NO = 143;
         public int AC_SGST_A = 144;
         public int AC_CGST_A = 145;
         public int AC_ACC_N = 146;
         public int EN_SGSTAmount = 147;
         public int EN_CGSTAmount = 148;
         public int EN_ACCHEAD_C = 149;
         public int EN_ACC_M = 150;
         public int EN_FROM_D = 151;
         public int EN_TO_D = 152;
         public int EN_ACC_NO = 153;
         public int EN_SGST_A = 154;
         public int EN_CGST_A = 155;
         public int EN_ACC_N = 156;
         public int AlloteeGSTNo = 157;
         public int AlloteeName = 158;
         public int SC_OS_CGST = 159;
         public int SC_OS_SGST = 160;
         public int NAA_OS_CGST = 161;
         public int NAA_OS_SGST = 162;
         public int LR_OS_CGST = 163;
         public int LR_OS_SGST = 164;
         public int INTREV_OS_CGST = 165;
         public int INTREV_OS_SGST = 166;
         public int SC_BASE = 167;
         public int SC_SGSTAmount = 168;
         public int SC_CGSTAmount = 169;
         public int SC_ACCHEAD_C = 170;
         public int SC_ACC_M = 171;
         public int SC_FROM_D = 172;
         public int SC_TO_D = 173;
         public int SC_ACC_NO = 174;
         public int SC_SGST_A = 175;
         public int SC_CGST_A = 176;
         public int SC_ACC_N = 177;
         public int NAA_BASE = 178;
         public int NAA_SGSTAmount = 179;
         public int NAA_CGSTAmount = 180;
         public int NAA_ACCHEAD_C = 181;
         public int NAA_ACC_M = 182;
         public int NAA_FROM_D = 183;
         public int NAA_TO_D = 184;
         public int NAA_ACC_NO = 185;
         public int NAA_SGST_A = 186;
         public int NAA_CGST_A = 187;
         public int NAA_ACC_N = 188;
         public int LR_BASE = 189;
         public int LR_SGSTAmount = 190;
         public int LR_CGSTAmount = 191;
         public int LR_ACCHEAD_C = 192;
         public int LR_ACC_M = 193;
         public int LR_FROM_D = 194;
         public int LR_TO_D = 195;
         public int LR_ACC_NO = 196;
         public int LR_SGST_A = 197;
         public int LR_CGST_A = 198;
         public int LR_ACC_N = 199;
         public int INT_BASE = 200;
         public int INT_SGSTAmount = 201;
         public int INT_CGSTAmount = 202;
         public int INT_ACCHEAD_C = 203;
         public int INT_ACC_M = 204;
         public int INT_FROM_D = 205;
         public int INT_TO_D = 206;
         public int INT_ACC_NO = 207;
         public int INT_SGST_A = 208;
         public int INT_CGST_A = 209;
         public int INT_ACC_N = 210;
         public int IsSEZ = 211;
         public int REVINT_CSGST_OS = 212;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdatePaymentDetailsAmalgamation
      public class SPUpdatePaymentDetailsAmalgamation
      {
         public string SPName = "SPUpdatePaymentDetailsAmalgamation";
         public int ApplicationFormId = 0;
         public int TxId = 1;
         public int TxRefNo = 2;
         public int TxStatus = 3;
         public int TxAmount = 4;
         public int TxMsg = 5;
         public int pgTxnNo = 6;
         public int issuerRefNo = 7;
         public int authIdCode = 8;
         public int firstName = 9;
         public int lastName = 10;
         public int pgRespCode = 11;
         public int addressZip = 12;
         public int signature = 13;
         public int Head = 14;
         public int paymentMode = 15;
         public int TxGateway = 16;
         public int cardType = 17;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpInspectorUploadBuildingPlanApprovalSiteInspectionReport
      public class SpInspectorUploadBuildingPlanApprovalSiteInspectionReport
      {
         public string SPName = "SpInspectorUploadBuildingPlanApprovalSiteInspectionReport";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int SiteInspectionReportAttachment = 2;
         public int InspectionRemarks = 3;
         public int InspectionPhoto = 4;
         public int AttachmentDEE = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectBuildingPlanApprovalIFPDetials
      public class SPSelectBuildingPlanApprovalIFPDetials
      {
         public string SPName = "SPSelectBuildingPlanApprovalIFPDetials";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPAMForwardToHelpdeskCorrigendum
      public class SPAMForwardToHelpdeskCorrigendum
      {
         public string SPName = "SPAMForwardToHelpdeskCorrigendum";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
         public int BackwardRemark = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region M_SPInsertUpdateApplicantUserMaster1
      public class M_SPInsertUpdateApplicantUserMaster1
      {
         public string SPName = "M_SPInsertUpdateApplicantUserMaster1";
         public int ApplicantUserId = 0;
         public int FirstName = 1;
         public int MiddleName = 2;
         public int LastName = 3;
         public int ContactNo = 4;
         public int MobileNo = 5;
         public int ModifiedOn = 6;
         public int ModifiedBy = 7;
         public int IsActive = 8;
         public int RegisteredAddress = 9;
         public int Prefix = 10;
         public int ApplicantIdentityProof = 11;
         public int ApplicantOfficeIdentityProof = 12;
         public int UserId = 13;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteGeneralApplicationFormByApplicationFormId
      public class SPDeleteGeneralApplicationFormByApplicationFormId
      {
         public string SPName = "SPDeleteGeneralApplicationFormByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubDivisionModuleByApplicationFormId
      public class SPSelectSubDivisionModuleByApplicationFormId
      {
         public string SPName = "SPSelectSubDivisionModuleByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateROUModuleDACalculation
      public class SPInsertUpdateROUModuleDACalculation
      {
         public string SPName = "SPInsertUpdateROUModuleDACalculation";
         public int Mode = 0;
         public int ApplicationFormId = 1;
         public int userId = 2;
         public int ROUArea = 3;
         public int ROUChargesFees = 4;
         public int ROUChargesfeesSGST = 5;
         public int ROUChargesfeesCGST = 6;
         public int TotalRouCharges = 7;
         public int OtherChargesFees = 8;
         public int RoadCuttingSGST = 9;
         public int RoadCuttingCGST = 10;
         public int TotalOtherCharges = 11;
         public int TotalPaybleAmount = 12;
         public int ROUCharge_ACCHEAD_C = 13;
         public int ROUCharge_ACC_M = 14;
         public int ROUCharge_FROM_D = 15;
         public int ROUCharge_TO_D = 16;
         public int ROUCharge_ACC_NO = 17;
         public int ROUCharge_SGST_A = 18;
         public int ROUCharge_CGST_A = 19;
         public int ROUCharge_ACC_N = 20;
         public int RoadCutting_ACCHEAD_C = 21;
         public int RoadCutting_ACC_M = 22;
         public int RoadCutting_FROM_D = 23;
         public int RoadCutting_TO_D = 24;
         public int RoadCutting_ACC_NO = 25;
         public int RoadCutting_SGST_A = 26;
         public int RoadCutting_CGST_A = 27;
         public int RoadCutting_ACC_N = 28;
         public int IsAgreeDA = 29;
         public int RemarksDA = 30;
         public int IsAgreeAM = 31;
         public int RemarksAM = 32;
         public int IsAgreeRM = 33;
         public int RemarksRM = 34;
         public int IsAgreeDM = 35;
         public int RemarksDM = 36;
         public int IsAgreeVCMD = 37;
         public int RemarksVCMD = 38;
         public int IsSubmitted = 39;
         public int AccountDues = 40;
         public int WaterDues = 41;
         public int OtherDues = 42;
         public int DrainageDues = 43;
         public int OSINST_A = 44;
         public int OSIDPPI_A = 45;
         public int OSSC_A = 46;
         public int OSSC_ST = 47;
         public int OSSC_EC = 48;
         public int OSSWCSC = 49;
         public int OSSCKKC = 50;
         public int OSNAA_A = 51;
         public int OSNAA_ST = 52;
         public int OSNAA_EC = 53;
         public int OSSWCNAA = 54;
         public int OSNAAKKC = 55;
         public int OSLR_A = 56;
         public int OSLR_ST = 57;
         public int OSLR_EC = 58;
         public int OSSWCLR = 59;
         public int OSLRKKC = 60;
         public int OSIR_A = 61;
         public int OSIUF_A = 62;
         public int OSIUF_ST = 63;
         public int OSIUF_EC = 64;
         public int OSFULLPAYMENT_A = 65;
         public int LRCOSINST_A = 66;
         public int LRCOSIDP_A = 67;
         public int EN_ACCHEAD_C = 68;
         public int EN_ACC_M = 69;
         public int EN_FROM_D = 70;
         public int EN_TO_D = 71;
         public int EN_ACC_NO = 72;
         public int EN_SGST_A = 73;
         public int EN_CGST_A = 74;
         public int EN_ACC_N = 75;
         public int EN_SGSTAmount = 76;
         public int EN_CGSTAmount = 77;
         public int EN_BaseAmount = 78;
         public int SC_ACCHEAD_C = 79;
         public int SC_ACC_M = 80;
         public int SC_FROM_D = 81;
         public int SC_TO_D = 82;
         public int SC_ACC_NO = 83;
         public int SC_SGST_A = 84;
         public int SC_CGST_A = 85;
         public int SC_ACC_N = 86;
         public int SC_SGSTAmount = 87;
         public int SC_CGSTAmount = 88;
         public int SC_BaseAmount = 89;
         public int NAA_ACCHEAD_C = 90;
         public int NAA_ACC_M = 91;
         public int NAA_FROM_D = 92;
         public int NAA_TO_D = 93;
         public int NAA_ACC_NO = 94;
         public int NAA_SGST_A = 95;
         public int NAA_CGST_A = 96;
         public int NAA_ACC_N = 97;
         public int NAA_SGSTAmount = 98;
         public int NAA_CGSTAmount = 99;
         public int NAA_BaseAmount = 100;
         public int LR_ACCHEAD_C = 101;
         public int LR_ACC_M = 102;
         public int LR_FROM_D = 103;
         public int LR_TO_D = 104;
         public int LR_ACC_NO = 105;
         public int LR_SGST_A = 106;
         public int LR_CGST_A = 107;
         public int LR_ACC_N = 108;
         public int LR_SGSTAmount = 109;
         public int LR_CGSTAmount = 110;
         public int LR_BaseAmount = 111;
         public int INT_ACCHEAD_C = 112;
         public int INT_ACC_M = 113;
         public int INT_FROM_D = 114;
         public int INT_TO_D = 115;
         public int INT_ACC_NO = 116;
         public int INT_SGST_A = 117;
         public int INT_CGST_A = 118;
         public int INT_ACC_N = 119;
         public int INT_SGSTAmount = 120;
         public int INT_CGSTAmount = 121;
         public int INT_BaseAmount = 122;
         public int SC_OS_CGST = 123;
         public int SC_OS_SGST = 124;
         public int NAA_OS_CGST = 125;
         public int NAA_OS_SGST = 126;
         public int LR_OS_CGST = 127;
         public int LR_OS_SGST = 128;
         public int INTREV_OS_CGST = 129;
         public int INTREV_OS_SGST = 130;
         public int RoadCuttingCharges = 131;
         public int MaintenanceDeposit = 132;
         public int OtherCharges = 133;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPBuildinPlanMISReportBNew
      public class SPBuildinPlanMISReportBNew
      {
         public string SPName = "SPBuildinPlanMISReportBNew";
         public int FromDate = 0;
         public int Todate = 1;
         public int RegionId = 2;
         public int StatusId = 3;
         public int EstateId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPlanApprovalOfficerDetails
      public class SPSelectPlanApprovalOfficerDetails
      {
         public string SPName = "SPSelectPlanApprovalOfficerDetails";
         public int userId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertTransactionReferenceNoPaymentDetailsForAmalgamation
      public class SPInsertTransactionReferenceNoPaymentDetailsForAmalgamation
      {
         public string SPName = "SPInsertTransactionReferenceNoPaymentDetailsForAmalgamation";
         public int TxId = 0;
         public int ApplicationFormId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSubDivisionApplicationDetailsReportFooterNew
      public class SPSubDivisionApplicationDetailsReportFooterNew
      {
         public string SPName = "SPSubDivisionApplicationDetailsReportFooterNew";
         public int ACTIONID = 0;
         public int ActionType = 1;
         public int BeforeAfter = 2;
         public int OldApplicationStatusId = 3;
         public int PTOIssueCMD = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSurrenderApplicationList
      public class SPSelectSurrenderApplicationList
      {
         public string SPName = "SPSelectSurrenderApplicationList";
         public int UserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferModuleFormalReport
      public class SPSelectTransferModuleFormalReport
      {
         public string SPName = "SPSelectTransferModuleFormalReport";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteDivisionMasterByDivisionId
      public class SPDeleteDivisionMasterByDivisionId
      {
         public string SPName = "SPDeleteDivisionMasterByDivisionId";
         public int DivisionId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectUserEstateByCircleIDForInspector
      public class SPSelectUserEstateByCircleIDForInspector
      {
         public string SPName = "SPSelectUserEstateByCircleIDForInspector";
         public int UserId = 0;
         public int ApplicationTypeId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectWaterSupplyApplicationIFPDetials
      public class SPSelectWaterSupplyApplicationIFPDetials
      {
         public string SPName = "SPSelectWaterSupplyApplicationIFPDetials";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectOracleRegionEstateIdByRegionEstateId
      public class SPSelectOracleRegionEstateIdByRegionEstateId
      {
         public string SPName = "SPSelectOracleRegionEstateIdByRegionEstateId";
         public int RegionId = 0;
         public int EstateId = 1;
         public int PlotTypeId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPAMForwardToHelpdeskLeaseApplicationQuery
      public class SPAMForwardToHelpdeskLeaseApplicationQuery
      {
         public string SPName = "SPAMForwardToHelpdeskLeaseApplicationQuery";
         public int ApplicationFormId = 0;
         public int AssignedRoleId = 1;
         public int ModifiedBy = 2;
         public int BackwardRemark = 3;
         public int AMRemainDoc = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region M_SPInsertUpdateApplicantUserMaster
      public class M_SPInsertUpdateApplicantUserMaster
      {
         public string SPName = "M_SPInsertUpdateApplicantUserMaster";
         public int ApplicantUserId = 0;
         public int FirstName = 1;
         public int MiddleName = 2;
         public int LastName = 3;
         public int ContactNo = 4;
         public int MobileNo = 5;
         public int ModifiedOn = 6;
         public int ModifiedBy = 7;
         public int IsActive = 8;
         public int RegisteredAddress = 9;
         public int Prefix = 10;
         public int ApplicantIdentityProof = 11;
         public int ApplicantOfficeIdentityProof = 12;
         public int UserId = 13;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertOracleEmployeeDetails
      public class SPInsertOracleEmployeeDetails
      {
         public string SPName = "SPInsertOracleEmployeeDetails";
         public int Emp_Code = 0;
         public int EmpFullName = 1;
         public int EmpShortName = 2;
         public int DesignationCode = 3;
         public int Designation = 4;
         public int SNO_N = 5;
         public int Class = 6;
         public int PhotoPath = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPaymentRecieptDetailsSubDivision05012017
      public class SPSelectPaymentRecieptDetailsSubDivision05012017
      {
         public string SPName = "SPSelectPaymentRecieptDetailsSubDivision05012017";
         public int txnId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectAmalgamationModuleForReferenceNo
      public class SPSelectAmalgamationModuleForReferenceNo
      {
         public string SPName = "SPSelectAmalgamationModuleForReferenceNo";
         public int EstateId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetPendingDayFromLastActionAtGIDCendForWaterSupply
      public class SPGetPendingDayFromLastActionAtGIDCendForWaterSupply
      {
         public string SPName = "SPGetPendingDayFromLastActionAtGIDCendForWaterSupply";
         public int ReferenceNo = 0;
         public int Days = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateDivisionMaster
      public class SPInsertUpdateDivisionMaster
      {
         public string SPName = "SPInsertUpdateDivisionMaster";
         public int DivisionId = 0;
         public int Division = 1;
         public int UserId = 2;
         public int IsActive = 3;
         public int Operation = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectUserEstateApplicationTypeMappingByApplicationId
      public class SPSelectUserEstateApplicationTypeMappingByApplicationId
      {
         public string SPName = "SPSelectUserEstateApplicationTypeMappingByApplicationId";
         public int UserId = 0;
         public int ApplicationId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDrainageApplicationIFPDetials
      public class SPSelectDrainageApplicationIFPDetials
      {
         public string SPName = "SPSelectDrainageApplicationIFPDetials";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateTwoRApplicationModulePlotDetails17032017
      public class SPUpdateTwoRApplicationModulePlotDetails17032017
      {
         public string SPName = "SPUpdateTwoRApplicationModulePlotDetails17032017";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPAMForwardToRMLeaseApplicationCorrigendum 
      public class SPAMForwardToRMLeaseApplicationCorrigendum 
      {
         public string SPName = "SPAMForwardToRMLeaseApplicationCorrigendum ";
         public int ApplicationFormId = 0;
         public int AssignedRoleId = 1;
         public int ModifiedBy = 2;
         public int BackwardRemark = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubDivisionApplicationPaymentDetailByTxId
      public class SPSelectSubDivisionApplicationPaymentDetailByTxId
      {
         public string SPName = "SPSelectSubDivisionApplicationPaymentDetailByTxId";
         public int TxId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetPendingDayAtGIDCendForWaterSupply
      public class SPGetPendingDayAtGIDCendForWaterSupply
      {
         public string SPName = "SPGetPendingDayAtGIDCendForWaterSupply";
         public int ReferenceNo = 0;
         public int Days = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateApplicationWiseEstateForUser
      public class SPInsertUpdateApplicationWiseEstateForUser
      {
         public string SPName = "SPInsertUpdateApplicationWiseEstateForUser";
         public int UserId = 0;
         public int ApplicationTypeId = 1;
         public int UserEstateIds = 2;
         public int CreatedBy = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateGeneralApplicationForIFPPortal
      public class SPUpdateGeneralApplicationForIFPPortal
      {
         public string SPName = "SPUpdateGeneralApplicationForIFPPortal";
         public int ApplicationFormId = 0;
         public int IsIFP_Sync = 1;
         public int IFPActionId = 2;
         public int ModifiedBy = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPaymentRecieptDetails2R17032017
      public class SPSelectPaymentRecieptDetails2R17032017
      {
         public string SPName = "SPSelectPaymentRecieptDetails2R17032017";
         public int txnId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPAMForwardToRMLeaseDocument
      public class SPAMForwardToRMLeaseDocument
      {
         public string SPName = "SPAMForwardToRMLeaseDocument";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
         public int BackwardRemark = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPTransferInActivePTOCondition
      public class SPTransferInActivePTOCondition
      {
         public string SPName = "SPTransferInActivePTOCondition";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectNotApplicableDocument
      public class SPSelectNotApplicableDocument
      {
         public string SPName = "SPSelectNotApplicableDocument";
         public int ApplicationId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPaymentRecieptDetailsForSubDivision05012017
      public class SPSelectPaymentRecieptDetailsForSubDivision05012017
      {
         public string SPName = "SPSelectPaymentRecieptDetailsForSubDivision05012017";
         public int txnId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateStatusApplication
      public class SPUpdateStatusApplication
      {
         public string SPName = "SPUpdateStatusApplication";
         public int ApplicationFormId = 0;
         public int StatusId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSublettingPaymentAdminCharge
      public class SPSelectSublettingPaymentAdminCharge
      {
         public string SPName = "SPSelectSublettingPaymentAdminCharge";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpTransferApplicationRemarksHistoryForReport
      public class SpTransferApplicationRemarksHistoryForReport
      {
         public string SPName = "SpTransferApplicationRemarksHistoryForReport";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPAmalgamationApplicationDetailsReportFooter
      public class SPAmalgamationApplicationDetailsReportFooter
      {
         public string SPName = "SPAmalgamationApplicationDetailsReportFooter";
         public int ACTIONID = 0;
         public int ActionType = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPROUApplicationSummaryReportNew
      public class SPROUApplicationSummaryReportNew
      {
         public string SPName = "SPROUApplicationSummaryReportNew";
         public int BeforeAfter = 0;
         public int RegionId = 1;
         public int StatusId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetPendingDayFromLastActionAtGIDCendForDrainageConnection
      public class SPGetPendingDayFromLastActionAtGIDCendForDrainageConnection
      {
         public string SPName = "SPGetPendingDayFromLastActionAtGIDCendForDrainageConnection";
         public int ReferenceNo = 0;
         public int Days = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateSurrenderApplicationQueryDocuments
      public class SPUpdateSurrenderApplicationQueryDocuments
      {
         public string SPName = "SPUpdateSurrenderApplicationQueryDocuments";
         public int ApplicationFormId = 0;
         public int ActionId = 1;
         public int QueryDocumentsXML = 2;
         public int Remarks = 3;
         public int UserId = 4;
         public int QueryDocumentsReply = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertTransactionReferenceNoPaymentDetailsFor2R17032017
      public class SPInsertTransactionReferenceNoPaymentDetailsFor2R17032017
      {
         public string SPName = "SPInsertTransactionReferenceNoPaymentDetailsFor2R17032017";
         public int TxId = 0;
         public int ApplicationFormId = 1;
         public int TwoRPlotId = 2;
         public int GSTNo = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPAMForwardToRMQueryApplication
      public class SPAMForwardToRMQueryApplication
      {
         public string SPName = "SPAMForwardToRMQueryApplication";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
         public int BackwardRemark = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateRemarksOnHold
      public class SPUpdateRemarksOnHold
      {
         public string SPName = "SPUpdateRemarksOnHold";
         public int ApplicationFormId = 0;
         public int Remarks = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdatePaymentDetailsByServerResponseForSubdivision
      public class SPUpdatePaymentDetailsByServerResponseForSubdivision
      {
         public string SPName = "SPUpdatePaymentDetailsByServerResponseForSubdivision";
         public int TxId = 0;
         public int TxRefNo = 1;
         public int TxStatus = 2;
         public int TxAmount = 3;
         public int TxMsg = 4;
         public int pgTxnNo = 5;
         public int issuerRefNo = 6;
         public int authIdCode = 7;
         public int firstName = 8;
         public int lastName = 9;
         public int pgRespCode = 10;
         public int addressZip = 11;
         public int signature = 12;
         public int Head = 13;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateAmalgamationModuleApplicationByAE
      public class SpUpdateAmalgamationModuleApplicationByAE
      {
         public string SPName = "SpUpdateAmalgamationModuleApplicationByAE";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int CurrentApplicationActionId = 2;
         public int NewAssinedActionId = 3;
         public int ConstructionReport = 4;
         public int ConstructionReportRemarks = 5;
         public int CompletedConstructionReport = 6;
         public int tblAEPhoto = 7;
         public int IsRelaxation = 8;
         public int IndustrTypeId = 9;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPAmalgamationApplicationDetailsReport
      public class SPAmalgamationApplicationDetailsReport
      {
         public string SPName = "SPAmalgamationApplicationDetailsReport";
         public int REGIONID = 0;
         public int ACTIONID = 1;
         public int ActionType = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetPendingDayAtGIDCendForDrainageConnection
      public class SPGetPendingDayAtGIDCendForDrainageConnection
      {
         public string SPName = "SPGetPendingDayAtGIDCendForDrainageConnection";
         public int ReferenceNo = 0;
         public int Days = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region spUpdateTechnicalScrutinyAmalgamation
      public class spUpdateTechnicalScrutinyAmalgamation
      {
         public string SPName = "spUpdateTechnicalScrutinyAmalgamation";
         public int Mode = 0;
         public int ApplicationFormId = 1;
         public int RoleId = 2;
         public int IsMarginplotIsApplicableAE = 3;
         public int IsPlotRegulerInShapeAE = 4;
         public int IsInfraRequiredbyGIDCAE = 5;
         public int IsGidcGDCRAE = 6;
         public int IsConstructionLess20perAE = 7;
         public int IsConstructionCircularAE = 8;
         public int SiteVerificationReportAE = 9;
         public int IsMarginplotIsApplicableDEE = 10;
         public int IsPlotRegulerInShapeDEE = 11;
         public int IsInfraRequiredbyGIDCDEE = 12;
         public int IsGidcGDCRDEE = 13;
         public int IsConstructionLess20perDEE = 14;
         public int IsConstructionCircularDEE = 15;
         public int IsMarginplotIsApplicableXEN = 16;
         public int IsPlotRegulerInShapeXEN = 17;
         public int IsInfraRequiredbyGIDCXEN = 18;
         public int IsGidcGDCRXEN = 19;
         public int IsConstructionLess20perXEN = 20;
         public int IsConstructionCircularXEN = 21;
         public int IsLandAcquiredByGIDC = 22;
         public int SurveyorPhoto = 23;
         public int SurveyorReport = 24;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDivisionMasterByDivision
      public class SPSelectDivisionMasterByDivision
      {
         public string SPName = "SPSelectDivisionMasterByDivision";
         public int Division = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectMenuListByUserId
      public class SPSelectMenuListByUserId
      {
         public string SPName = "SPSelectMenuListByUserId";
         public int UserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPCheckUniqueTransactionReferenceNo17032017
      public class SPCheckUniqueTransactionReferenceNo17032017
      {
         public string SPName = "SPCheckUniqueTransactionReferenceNo17032017";
         public int TxId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPAOForwardToAMCheckedCorrigendum
      public class SPAOForwardToAMCheckedCorrigendum
      {
         public string SPName = "SPAOForwardToAMCheckedCorrigendum";
         public int ApplicationFormId = 0;
         public int AssignedRoleId = 1;
         public int ModifiedBy = 2;
         public int BackwardRemark = 3;
         public int Path = 4;
         public int AODCC = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdatePaymentDetailsSubDivision05012017
      public class SPUpdatePaymentDetailsSubDivision05012017
      {
         public string SPName = "SPUpdatePaymentDetailsSubDivision05012017";
         public int ApplicationFormId = 0;
         public int TxId = 1;
         public int TxRefNo = 2;
         public int TxStatus = 3;
         public int TxAmount = 4;
         public int TxMsg = 5;
         public int pgTxnNo = 6;
         public int issuerRefNo = 7;
         public int authIdCode = 8;
         public int firstName = 9;
         public int lastName = 10;
         public int pgRespCode = 11;
         public int addressZip = 12;
         public int signature = 13;
         public int Head = 14;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectInspectionPlotShedNoByEstateId
      public class SPSelectInspectionPlotShedNoByEstateId
      {
         public string SPName = "SPSelectInspectionPlotShedNoByEstateId";
         public int EstateId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertIntoDWGMapping
      public class SPInsertIntoDWGMapping
      {
         public string SPName = "SPInsertIntoDWGMapping";
         public int RegiondName = 0;
         public int Estateid = 1;
         public int EstateName = 2;
         public int RegionShortName = 3;
         public int OfficeAddress = 4;
         public int PlanApprovalOfficer = 5;
         public int EmployeeCode = 6;
         public int Post = 7;
         public int MobileNo = 8;
         public int EmailId = 9;
         public int IsActive = 10;
         public int Action = 11;
         public int Id = 12;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectUndertakingByApplicationFormId
      public class SPSelectUndertakingByApplicationFormId
      {
         public string SPName = "SPSelectUndertakingByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertAmalgamationPlotDetails
      public class SPInsertAmalgamationPlotDetails
      {
         public string SPName = "SPInsertAmalgamationPlotDetails";
         public int Id = 0;
         public int ApplicationFormid = 1;
         public int PlotShedno = 2;
         public int PlotShedArea = 3;
         public int TypeofPlotShed = 4;
         public int NameofUnit = 5;
         public int AllotmentDate = 6;
         public int IsLeaseDone = 7;
         public int LeaseDeedCopy = 8;
         public int CreatedBy = 9;
         public int modifiedBy = 10;
         public int IsActive = 11;
         public int LeaseDeedDate = 12;
         public int PartyCode = 13;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDivisionMasterByDivisionId
      public class SPSelectDivisionMasterByDivisionId
      {
         public string SPName = "SPSelectDivisionMasterByDivisionId";
         public int DivisionId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateMenuForUser
      public class SPInsertUpdateMenuForUser
      {
         public string SPName = "SPInsertUpdateMenuForUser";
         public int UserId = 0;
         public int MenuIds = 1;
         public int CreatedBy = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetPaymentFlagFor2R17032017
      public class SPGetPaymentFlagFor2R17032017
      {
         public string SPName = "SPGetPaymentFlagFor2R17032017";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPAOForwardToAMLeaseApplication
      public class SPAOForwardToAMLeaseApplication
      {
         public string SPName = "SPAOForwardToAMLeaseApplication";
         public int ApplicationFormId = 0;
         public int AssignedRoleId = 1;
         public int ModifiedBy = 2;
         public int BackwardRemark = 3;
         public int Path = 4;
         public int AODCC = 5;
         public int IsCostFixation = 6;
         public int IsShedPriceDiff = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectApplicationPaymentDetailSubDivisionByTxId05012017
      public class SPSelectApplicationPaymentDetailSubDivisionByTxId05012017
      {
         public string SPName = "SPSelectApplicationPaymentDetailSubDivisionByTxId05012017";
         public int TxId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferModuleDocumentTransactionByApplicationIdPublic05102016
      public class SPSelectTransferModuleDocumentTransactionByApplicationIdPublic05102016
      {
         public string SPName = "SPSelectTransferModuleDocumentTransactionByApplicationIdPublic05102016";
         public int AplicationFormId = 0;
         public int ConstituteTypeTransferor = 1;
         public int ConstituteTypeTransferee = 2;
         public int DeathCaseType = 3;
         public int DeathWIllType = 4;
         public int TrasferGSFC = 5;
         public int TrasferCoOperative = 6;
         public int IsIndustrial = 7;
         public int IsExitPolicy = 8;
         public int IsChemical = 9;
         public int IsUtilized = 10;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectAmalgamationPlotDetailsbyID
      public class SPSelectAmalgamationPlotDetailsbyID
      {
         public string SPName = "SPSelectAmalgamationPlotDetailsbyID";
         public int AmalgPlotId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetPendingDayFromLastActionAtGIDCendForROUModule
      public class SPGetPendingDayFromLastActionAtGIDCendForROUModule
      {
         public string SPName = "SPGetPendingDayFromLastActionAtGIDCendForROUModule";
         public int ApplicationFormId = 0;
         public int Days = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpROUModuleConcludingRemarksHistory
      public class SpROUModuleConcludingRemarksHistory
      {
         public string SPName = "SpROUModuleConcludingRemarksHistory";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSurrenderPaymentAdminCharge
      public class SPSelectSurrenderPaymentAdminCharge
      {
         public string SPName = "SPSelectSurrenderPaymentAdminCharge";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectOfficeUserMasterByEmailIdCheckForUpdate
      public class SPSelectOfficeUserMasterByEmailIdCheckForUpdate
      {
         public string SPName = "SPSelectOfficeUserMasterByEmailIdCheckForUpdate";
         public int EmailId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTwoRApplicationModulePlotDetailsDisplay17032017
      public class SPSelectTwoRApplicationModulePlotDetailsDisplay17032017
      {
         public string SPName = "SPSelectTwoRApplicationModulePlotDetailsDisplay17032017";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPAOForwardToDALeaseApplicationCorrigendum
      public class SPAOForwardToDALeaseApplicationCorrigendum
      {
         public string SPName = "SPAOForwardToDALeaseApplicationCorrigendum";
         public int ApplicationFormId = 0;
         public int AssignedRoleId = 1;
         public int ModifiedBy = 2;
         public int BackwardRemark = 3;
         public int Path = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdatePaymentDetailsSubDivision
      public class SPUpdatePaymentDetailsSubDivision
      {
         public string SPName = "SPUpdatePaymentDetailsSubDivision";
         public int ApplicationFormIdNotuse = 0;
         public int TxId = 1;
         public int TxRefNo = 2;
         public int TxStatus = 3;
         public int TxAmount = 4;
         public int TxMsg = 5;
         public int pgTxnNo = 6;
         public int issuerRefNo = 7;
         public int authIdCode = 8;
         public int firstName = 9;
         public int lastName = 10;
         public int pgRespCode = 11;
         public int addressZip = 12;
         public int signature = 13;
         public int Head = 14;
         public int paymentMode = 15;
         public int TxGateway = 16;
         public int cardType = 17;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPCheckUniqueTransactionReferenceNoForBuildingCompletion
      public class SPCheckUniqueTransactionReferenceNoForBuildingCompletion
      {
         public string SPName = "SPCheckUniqueTransactionReferenceNoForBuildingCompletion";
         public int TxId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectFromDWGMapping
      public class SPSelectFromDWGMapping
      {
         public string SPName = "SPSelectFromDWGMapping";
         public int SearchText = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectAmalgamationPlotDetails
      public class SPSelectAmalgamationPlotDetails
      {
         public string SPName = "SPSelectAmalgamationPlotDetails";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectConstitutionTypeMasterByConstitutionType
      public class SPSelectConstitutionTypeMasterByConstitutionType
      {
         public string SPName = "SPSelectConstitutionTypeMasterByConstitutionType";
         public int ConstitutionType = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTwoRTransactionForSameUnit01092016
      public class SPSelectTwoRTransactionForSameUnit01092016
      {
         public string SPName = "SPSelectTwoRTransactionForSameUnit01092016";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SP_SelectDocumentMasterDataForSubletting
      public class SP_SelectDocumentMasterDataForSubletting
      {
         public string SPName = "SP_SelectDocumentMasterDataForSubletting";
         public int mode = 0;
         public int ApplicationFormId = 1;
         public int ActionId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectOfficeUserMasterSearch
      public class SPSelectOfficeUserMasterSearch
      {
         public string SPName = "SPSelectOfficeUserMasterSearch";
         public int SearchText = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateTwoRApplicationModulePlotDetailsForAccountDues17032017
      public class SPUpdateTwoRApplicationModulePlotDetailsForAccountDues17032017
      {
         public string SPName = "SPUpdateTwoRApplicationModulePlotDetailsForAccountDues17032017";
         public int TwoRPlotId = 0;
         public int DuesFile = 1;
         public int Opresation = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPApplicationOutwardFromHelpdesk
      public class SPApplicationOutwardFromHelpdesk
      {
         public string SPName = "SPApplicationOutwardFromHelpdesk";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectBuildingCompletionApplication
      public class SPSelectBuildingCompletionApplication
      {
         public string SPName = "SPSelectBuildingCompletionApplication";
         public int AssignedRoleId = 0;
         public int SearchValue = 1;
         public int SearchId = 2;
         public int RegionId = 3;
         public int UserId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertTransactionReferenceNoPaymentDetailsSubDivision05012017
      public class SPInsertTransactionReferenceNoPaymentDetailsSubDivision05012017
      {
         public string SPName = "SPInsertTransactionReferenceNoPaymentDetailsSubDivision05012017";
         public int TxId = 0;
         public int ApplicationFormId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateTransfer25092016
      public class SPUpdateTransfer25092016
      {
         public string SPName = "SPUpdateTransfer25092016";
         public int ApplicationFormId = 0;
         public int ApplicantName = 1;
         public int ApplicantAddress = 2;
         public int RegionId = 3;
         public int EstateId = 4;
         public int TypeOfPlotShed = 5;
         public int PlotShedNo = 6;
         public int PlotArea = 7;
         public int NameofIndividualTransferor = 8;
         public int CinTransferor = 9;
         public int AuthorisedPersonTransferor = 10;
         public int ContactNoTransferor = 11;
         public int EmailIdTransferor = 12;
         public int NameofIndividualTransferee = 13;
         public int CinTransferee = 14;
         public int AuthorisedPersonTransferee = 15;
         public int ContactNoTransferee = 16;
         public int EmailIdTransferee = 17;
         public int NameofAllottee = 18;
         public int AddressofAllottee = 19;
         public int DateofAllotment = 20;
         public int DateofAgreement = 21;
         public int DateofPossession = 22;
         public int DateofLeaseDeed = 23;
         public int DateofCorrigendum = 24;
         public int NameofTrasferee = 25;
         public int AddressofTrasferee = 26;
         public int NameofProduct = 27;
         public int NameofRawMaterials = 28;
         public int RequirementofRawMaterialsperMonth = 29;
         public int ProductioninMonth = 30;
         public int WaterRequirement1stYear = 31;
         public int WaterRequirement2ndYear = 32;
         public int WaterRequirement3rdYear = 33;
         public int WaterRequirement4thYear = 34;
         public int PowerRequirement1stYear = 35;
         public int PowerRequirement2ndYear = 36;
         public int PowerRequirement3rdYear = 37;
         public int PowerRequirement4thYear = 38;
         public int TotalInvestmentInyourProject = 39;
         public int NoofManPowerRequired = 40;
         public int FormalTrasferOrInFormalTrasfer = 41;
         public int ModifiedBy = 42;
         public int IsSubmitted = 43;
         public int DocumentXML = 44;
         public int tblTransferor = 45;
         public int tblTransferee = 46;
         public int ConstitutionTypeId = 47;
         public int DeathCaseTransfer = 48;
         public int DeathWillType = 49;
         public int DeathCaseTransferWill = 50;
         public int NOC2RPermissionTaken = 51;
         public int NOCAttachment = 52;
         public int TrasferGSFC = 53;
         public int TrasferCoOperative = 54;
         public int FTOName = 55;
         public int FTOFile = 56;
         public int ConstitutionTypeIdTransferee = 57;
         public int UndertakingTransfer = 58;
         public int UndertakingTransferee = 59;
         public int LeaseDeed = 60;
         public int LeaseDeedDocument = 61;
         public int NOC2RReferenceNo = 62;
         public int IsExistingAllottee = 63;
         public int tblUTransferor = 64;
         public int tblUTransferee = 65;
         public int LeaseDeedPlotArea = 66;
         public int IsIssuedCorrigendum = 67;
         public int CorrigendumArea = 68;
         public int CorrigendumFile = 69;
         public int ProductioninDate = 70;
         public int ApplicantLandlineNo = 71;
         public int ApplicantMobileNo = 72;
         public int ApplicantEmailId = 73;
         public int ApplicantRelationUnit = 74;
         public int IsTransferSubDivision = 75;
         public int IsCarriedOutPlot = 76;
         public int PlanPassingDate = 77;
         public int PlanPassedFile = 78;
         public int ConcernedAuthority = 79;
         public int ConcernedAuthorityName = 80;
         public int ConstructionCarriedArea = 81;
         public int GroundCoveragePercentage = 82;
         public int ApplicantIdentity = 83;
         public int IsAmalgamation = 84;
         public int IsFamilyMembers = 85;
         public int FamilyRelation = 86;
         public int FamilyRelationDocument = 87;
         public int TransferExitPolicy = 88;
         public int ExitPolicyBuildingPlanFile = 89;
         public int ExitPolicyGPDBFile = 90;
         public int ExitPolicyNotorizedFile = 91;
         public int IsChemical = 92;
         public int PossessionReceiptFile = 93;
         public int IsUtilized = 94;
         public int DateOfConveyanceDeed = 95;
         public int ConveyanceDeedPlotArea = 96;
         public int ConveyanceDeedDocument = 97;
         public int CorrigendumTypeArea = 98;
         public int CorrigendumTypeName = 99;
         public int DateofCorrigendumName = 100;
         public int CorrigendumValueName = 101;
         public int CorrigendumFileName = 102;
         public int CorrigendumTypeProperty = 103;
         public int DateofCorrigendumProperty = 104;
         public int CorrigendumValueProperty = 105;
         public int CorrigendumFileProperty = 106;
         public int PartyCode = 107;
         public int IsFromMobileApp = 108;
         public int PeriodOfUtilization = 109;
         public int IsPropertyClosedAfterUtilization = 110;
         public int IsPropertyOpen = 111;
         public int ApplicationFor = 112;
         public int ManufacturingOf = 113;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteAmalgamationPlotDetails
      public class SPDeleteAmalgamationPlotDetails
      {
         public string SPName = "SPDeleteAmalgamationPlotDetails";
         public int AmalgPlotId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateOfficeUserMasterForChangePassword
      public class SPUpdateOfficeUserMasterForChangePassword
      {
         public string SPName = "SPUpdateOfficeUserMasterForChangePassword";
         public int EmailId = 0;
         public int Password = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTwoRTransactionForPast01092016
      public class SPSelectTwoRTransactionForPast01092016
      {
         public string SPName = "SPSelectTwoRTransactionForPast01092016";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region sp_selectDocByID
      public class sp_selectDocByID
      {
         public string SPName = "sp_selectDocByID";
         public int mode = 0;
         public int RegionId = 1;
         public int EstateId = 2;
         public int PlotShedTypeId = 3;
         public int PlotNumber = 4;
         public int DocName = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSlectMenuByUserId
      public class SPSlectMenuByUserId
      {
         public string SPName = "SPSlectMenuByUserId";
         public int UserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSubLettingApplicationRemarksHistory
      public class SPSubLettingApplicationRemarksHistory
      {
         public string SPName = "SPSubLettingApplicationRemarksHistory";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateGeneralApplicationForm17032017
      public class SPInsertUpdateGeneralApplicationForm17032017
      {
         public string SPName = "SPInsertUpdateGeneralApplicationForm17032017";
         public int ApplicationFormId = 0;
         public int StatusId = 1;
         public int ActionId = 2;
         public int ApplicationFormDate = 3;
         public int ApplicationId = 4;
         public int ReferenceNo = 5;
         public int AssignedRoleId = 6;
         public int ApplicantFirstName = 7;
         public int ApplicantContactNo = 8;
         public int ApplicantMobileNo = 9;
         public int ApplicantEmailId = 10;
         public int Relationwithunit = 11;
         public int ApplicantIdentity = 12;
         public int PlotAgreementDate = 13;
         public int PlotPhysicalPossessionDate = 14;
         public int PlotDeedDate = 15;
         public int PlotContactNo = 16;
         public int UnitMobileNo = 17;
         public int UnitEmailId = 18;
         public int UnitAddress = 19;
         public int CompanyName = 20;
         public int ConsititutionTypeId = 21;
         public int CompanyWebsite = 22;
         public int IsNameDifference = 23;
         public int FTOName = 24;
         public int FTOFile = 25;
         public int CompanyDetailSameAsApplicant = 26;
         public int CompanyAddress = 27;
         public int CompanyContactNo = 28;
         public int CompanyMobileNo = 29;
         public int CompanyEmailId = 30;
         public int UserId = 31;
         public int Operation = 32;
         public int IsApplyForMultiPlot = 33;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDABackwardApplicationWithCorrectionLeaseDocument
      public class SPDABackwardApplicationWithCorrectionLeaseDocument
      {
         public string SPName = "SPDABackwardApplicationWithCorrectionLeaseDocument";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateSubdivisionModuleForSubdivisionStatus
      public class SPUpdateSubdivisionModuleForSubdivisionStatus
      {
         public string SPName = "SPUpdateSubdivisionModuleForSubdivisionStatus";
         public int ApplicationFormId = 0;
         public int SubDivisionStatusId = 1;
         public int DateOfSubdivision = 2;
         public int SubdivisionOrderDocument = 3;
         public int DateOfNOCIssued = 4;
         public int SubDivisionNOCDoc = 5;
         public int ModifiedBy = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPAMToHelpdeskApproveReject
      public class SPAMToHelpdeskApproveReject
      {
         public string SPName = "SPAMToHelpdeskApproveReject";
         public int ApplicationFormId = 0;
         public int ActionId = 1;
         public int UserId = 2;
         public int AssignedRoleId = 3;
         public int BackwardRemark = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPCheckUniqueTransactionReferenceNoForSubDivision05012017
      public class SPCheckUniqueTransactionReferenceNoForSubDivision05012017
      {
         public string SPName = "SPCheckUniqueTransactionReferenceNoForSubDivision05012017";
         public int TxId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateForwardDateNewTransfer29102016
      public class SPUpdateForwardDateNewTransfer29102016
      {
         public string SPName = "SPUpdateForwardDateNewTransfer29102016";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
         public int ActionId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpTwoRApplicationRemarksHistoryForReport
      public class SpTwoRApplicationRemarksHistoryForReport
      {
         public string SPName = "SpTwoRApplicationRemarksHistoryForReport";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectAmalgamationModuleByApplicationFormIdForView
      public class SPSelectAmalgamationModuleByApplicationFormIdForView
      {
         public string SPName = "SPSelectAmalgamationModuleByApplicationFormIdForView";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectConstitutionMasterByConstitutionTypeId
      public class SPSelectConstitutionMasterByConstitutionTypeId
      {
         public string SPName = "SPSelectConstitutionMasterByConstitutionTypeId";
         public int ConstitutionTypeId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateTwoRPayment01092016
      public class SPUpdateTwoRPayment01092016
      {
         public string SPName = "SPUpdateTwoRPayment01092016";
         public int IsPaymentDoneFor2R = 0;
         public int ReferenceNo = 1;
         public int ModifiedBy = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region spGetdocIdWise
      public class spGetdocIdWise
      {
         public string SPName = "spGetdocIdWise";
         public int EstateId = 0;
         public int RegionId = 1;
         public int PlotShedTypeId = 2;
         public int PlotNumber = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteMenuFromUserMenuMapping
      public class SPDeleteMenuFromUserMenuMapping
      {
         public string SPName = "SPDeleteMenuFromUserMenuMapping";
         public int UserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateTwoRApplicationModule17032017
      public class SPUpdateTwoRApplicationModule17032017
      {
         public string SPName = "SPUpdateTwoRApplicationModule17032017";
         public int ApplicationFormId = 0;
         public int LoanRequested = 1;
         public int Name = 2;
         public int Address = 3;
         public int TimePeriodRequired = 4;
         public int IsLoanTakenFromMultipleBank = 5;
         public int IsPerFinInstiSame = 6;
         public int IsPerSameBank = 7;
         public int BankNameEarlier = 8;
         public int BankbranchEarlier = 9;
         public int IsPastOtherInstitutePermission = 10;
         public int ApplicantDocumentList = 11;
         public int Operation = 12;
         public int UserId = 13;
         public int PermissionletterNumber = 14;
         public int PermissionletterDate = 15;
         public int PermissionAmount = 16;
         public int IsFromMobileApp = 17;
         public int GSTNO = 18;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDABackwardToHelpdeskApplication
      public class SPDABackwardToHelpdeskApplication
      {
         public string SPName = "SPDABackwardToHelpdeskApplication";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
         public int BackwardRemark = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetSubdivisionStatusbyApplicationFormId
      public class SPGetSubdivisionStatusbyApplicationFormId
      {
         public string SPName = "SPGetSubdivisionStatusbyApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSubDivisionSelectForPayfees05012017
      public class SPSubDivisionSelectForPayfees05012017
      {
         public string SPName = "SPSubDivisionSelectForPayfees05012017";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectFromDWGMappingById
      public class SPSelectFromDWGMappingById
      {
         public string SPName = "SPSelectFromDWGMappingById";
         public int Id = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectAmalgamationByUserId
      public class SPSelectAmalgamationByUserId
      {
         public string SPName = "SPSelectAmalgamationByUserId";
         public int UserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectConstitutionTypeMasterByConstitutionTypeId
      public class SPSelectConstitutionTypeMasterByConstitutionTypeId
      {
         public string SPName = "SPSelectConstitutionTypeMasterByConstitutionTypeId";
         public int ConstitutionTypeId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectMenuByUserId
      public class SPSelectMenuByUserId
      {
         public string SPName = "SPSelectMenuByUserId";
         public int UserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateSublettingDocumentTransaction
      public class SPInsertUpdateSublettingDocumentTransaction
      {
         public string SPName = "SPInsertUpdateSublettingDocumentTransaction";
         public int Mode = 0;
         public int ApplicationFormId = 1;
         public int Documentmasterid = 2;
         public int RoleId = 3;
         public int UserId = 4;
         public int DocumentOKorNotOKDA = 5;
         public int DocumentRemarksDA = 6;
         public int DocumentOKorNotOKDEE = 7;
         public int DocumentRemarksDEE = 8;
         public int DocumentOKorNotOKAM = 9;
         public int DocumentRemarksAM = 10;
         public int DocumentOKorNotOKRM = 11;
         public int DocumentRemarksRM = 12;
         public int DocumentOKorNotOKDM = 13;
         public int DocumentRemarksDM = 14;
         public int DocumentOKorNotOKVCMD = 15;
         public int DocumentRemarksVCMD = 16;
         public int Document = 17;
         public int Remarks = 18;
         public int ActionId = 19;
         public int AssignActionId = 20;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDABackwardToHelpdeskFinalLeaseDocument
      public class SPDABackwardToHelpdeskFinalLeaseDocument
      {
         public string SPName = "SPDABackwardToHelpdeskFinalLeaseDocument";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
         public int BackwardRemark = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetBuildingCompletionPaymentTxtIdbyApplicationFormId
      public class SPGetBuildingCompletionPaymentTxtIdbyApplicationFormId
      {
         public string SPName = "SPGetBuildingCompletionPaymentTxtIdbyApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSubDivisionDocumentVerification05012017
      public class SPSubDivisionDocumentVerification05012017
      {
         public string SPName = "SPSubDivisionDocumentVerification05012017";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int UserRoleId = 2;
         public int CurrentApplicationActionId = 3;
         public int AssignedRoleId = 4;
         public int AssignedActionId = 5;
         public int Remark = 6;
         public int ApplicationFee = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectAmalgamationDocumentTransactionByApplicationIdPublic
      public class SPSelectAmalgamationDocumentTransactionByApplicationIdPublic
      {
         public string SPName = "SPSelectAmalgamationDocumentTransactionByApplicationIdPublic";
         public int ApplicationFormId = 0;
         public int ConstitutionType = 1;
         public int PlotShedTypeId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertTransferModule22102016
      public class SPInsertTransferModule22102016
      {
         public string SPName = "SPInsertTransferModule22102016";
         public int ReferenceNo = 0;
         public int ApplicantName = 1;
         public int ApplicantAddress = 2;
         public int RegionId = 3;
         public int EstateId = 4;
         public int TypeOfPlotShed = 5;
         public int PlotShedNo = 6;
         public int PlotArea = 7;
         public int NameofIndividualTransferor = 8;
         public int CinTransferor = 9;
         public int AuthorisedPersonTransferor = 10;
         public int ContactNoTransferor = 11;
         public int EmailIdTransferor = 12;
         public int NameofIndividualTransferee = 13;
         public int CinTransferee = 14;
         public int AuthorisedPersonTransferee = 15;
         public int ContactNoTransferee = 16;
         public int EmailIdTransferee = 17;
         public int NameofAllottee = 18;
         public int AddressofAllottee = 19;
         public int DateofAllotment = 20;
         public int DateofAgreement = 21;
         public int DateofPossession = 22;
         public int DateofLeaseDeed = 23;
         public int DateofCorrigendum = 24;
         public int NameofTrasferee = 25;
         public int AddressofTrasferee = 26;
         public int NameofProduct = 27;
         public int NameofRawMaterials = 28;
         public int RequirementofRawMaterialsperMonth = 29;
         public int ProductioninMonth = 30;
         public int WaterRequirement1stYear = 31;
         public int WaterRequirement2ndYear = 32;
         public int WaterRequirement3rdYear = 33;
         public int WaterRequirement4thYear = 34;
         public int PowerRequirement1stYear = 35;
         public int PowerRequirement2ndYear = 36;
         public int PowerRequirement3rdYear = 37;
         public int PowerRequirement4thYear = 38;
         public int TotalInvestmentInyourProject = 39;
         public int NoofManPowerRequired = 40;
         public int FormalTrasferOrInFormalTrasfer = 41;
         public int CreatedBy = 42;
         public int IsSubmitted = 43;
         public int DocumentXML = 44;
         public int tblTransferor = 45;
         public int tblTransferee = 46;
         public int ConstitutionTypeId = 47;
         public int DeathCaseTransfer = 48;
         public int DeathWillType = 49;
         public int DeathCaseTransferWill = 50;
         public int NOC2RPermissionTaken = 51;
         public int NOCAttachment = 52;
         public int TrasferGSFC = 53;
         public int TrasferCoOperative = 54;
         public int FTOName = 55;
         public int FTOFile = 56;
         public int ConstitutionTypeIdTransferee = 57;
         public int UndertakingTransfer = 58;
         public int UndertakingTransferee = 59;
         public int LeaseDeed = 60;
         public int LeaseDeedDocument = 61;
         public int NOC2RReferenceNo = 62;
         public int IsExistingAllottee = 63;
         public int tblUTransferor = 64;
         public int tblUTransferee = 65;
         public int LeaseDeedPlotArea = 66;
         public int IsIssuedCorrigendum = 67;
         public int CorrigendumArea = 68;
         public int CorrigendumFile = 69;
         public int ProductioninDate = 70;
         public int ApplicantLandlineNo = 71;
         public int ApplicantMobileNo = 72;
         public int ApplicantEmailId = 73;
         public int ApplicantRelationUnit = 74;
         public int IsTransferSubDivision = 75;
         public int IsCarriedOutPlot = 76;
         public int PlanPassingDate = 77;
         public int PlanPassedFile = 78;
         public int ConcernedAuthority = 79;
         public int ConcernedAuthorityName = 80;
         public int ConstructionCarriedArea = 81;
         public int GroundCoveragePercentage = 82;
         public int ApplicantIdentity = 83;
         public int IsAmalgamation = 84;
         public int IsFamilyMembers = 85;
         public int FamilyRelation = 86;
         public int FamilyRelationDocument = 87;
         public int TransferExitPolicy = 88;
         public int ExitPolicyBuildingPlanFile = 89;
         public int ExitPolicyGPDBFile = 90;
         public int ExitPolicyNotorizedFile = 91;
         public int IsChemical = 92;
         public int PossessionReceiptFile = 93;
         public int IsUtilized = 94;
         public int DateOfConveyanceDeed = 95;
         public int ConveyanceDeedPlotArea = 96;
         public int ConveyanceDeedDocument = 97;
         public int CorrigendumTypeArea = 98;
         public int CorrigendumTypeName = 99;
         public int DateofCorrigendumName = 100;
         public int CorrigendumValueName = 101;
         public int CorrigendumFileName = 102;
         public int CorrigendumTypeProperty = 103;
         public int DateofCorrigendumProperty = 104;
         public int CorrigendumValueProperty = 105;
         public int CorrigendumFileProperty = 106;
         public int PartyCode = 107;
         public int IsFromMobileApp = 108;
         public int PeriodOfUtilization = 109;
         public int IsPropertyClosedAfterUtilization = 110;
         public int IsPropertyOpen = 111;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpDrainageApplicationRemarksHistoryForReport
      public class SpDrainageApplicationRemarksHistoryForReport
      {
         public string SPName = "SpDrainageApplicationRemarksHistoryForReport";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPCheckUniqueReferenceNoForAmalgamationModule
      public class SPCheckUniqueReferenceNoForAmalgamationModule
      {
         public string SPName = "SPCheckUniqueReferenceNoForAmalgamationModule";
         public int ReferenceNo = 0;
         public int EstateId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region spInsertUpdateDocRepository
      public class spInsertUpdateDocRepository
      {
         public string SPName = "spInsertUpdateDocRepository";
         public int mode = 0;
         public int RegionId = 1;
         public int EstateId = 2;
         public int PlotShedTypeId = 3;
         public int PlotNumber = 4;
         public int ApplicantName = 5;
         public int DocumentSubId = 6;
         public int DocumentDate = 7;
         public int DocumentName = 8;
         public int CreatedBy = 9;
         public int DocumentDetailsId = 10;
         public int PlotArea = 11;
         public int PartyCode = 12;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteRegionMasterByRegionId
      public class SPDeleteRegionMasterByRegionId
      {
         public string SPName = "SPDeleteRegionMasterByRegionId";
         public int RegionId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDAForwardAMCorrigendum
      public class SPDAForwardAMCorrigendum
      {
         public string SPName = "SPDAForwardAMCorrigendum";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
         public int BackwardRemark = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectWaterSupplyInvoiceByHeader
      public class SPSelectWaterSupplyInvoiceByHeader
      {
         public string SPName = "SPSelectWaterSupplyInvoiceByHeader";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertCRDailyApplicationDetailsForTransfer
      public class SPInsertCRDailyApplicationDetailsForTransfer
      {
         public string SPName = "SPInsertCRDailyApplicationDetailsForTransfer";
         public int ApplicationId = 0;
         public int ApplicationFormId = 1;
         public int AppForwardDate = 2;
         public int AppActualForwardDate = 3;
         public int ActionId = 4;
         public int AssignRoleId = 5;
         public int EstateId = 6;
         public int Remark = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubDivisionModuleApplicationListDetails
      public class SPSelectSubDivisionModuleApplicationListDetails
      {
         public string SPName = "SPSelectSubDivisionModuleApplicationListDetails";
         public int AssignedRoleId = 0;
         public int SearchValue = 1;
         public int SearchId = 2;
         public int RegionId = 3;
         public int UserId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectEstatePriceForAmalgamationByApplicationFormId
      public class SPSelectEstatePriceForAmalgamationByApplicationFormId
      {
         public string SPName = "SPSelectEstatePriceForAmalgamationByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertActionTransactionEntry
      public class SPInsertActionTransactionEntry
      {
         public string SPName = "SPInsertActionTransactionEntry";
         public int ActionId = 0;
         public int ApplicationFormId = 1;
         public int ApplicationId = 2;
         public int BackwardRemark = 3;
         public int createdBy = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateTransfer11082016
      public class SPUpdateTransfer11082016
      {
         public string SPName = "SPUpdateTransfer11082016";
         public int ApplicationFormId = 0;
         public int ApplicantName = 1;
         public int ApplicantAddress = 2;
         public int RegionId = 3;
         public int EstateId = 4;
         public int TypeOfPlotShed = 5;
         public int PlotShedNo = 6;
         public int PlotArea = 7;
         public int NameofIndividualTransferor = 8;
         public int CinTransferor = 9;
         public int AuthorisedPersonTransferor = 10;
         public int ContactNoTransferor = 11;
         public int EmailIdTransferor = 12;
         public int NameofIndividualTransferee = 13;
         public int CinTransferee = 14;
         public int AuthorisedPersonTransferee = 15;
         public int ContactNoTransferee = 16;
         public int EmailIdTransferee = 17;
         public int NameofAllottee = 18;
         public int AddressofAllottee = 19;
         public int DateofAllotment = 20;
         public int DateofAgreement = 21;
         public int DateofPossession = 22;
         public int DateofLeaseDeed = 23;
         public int DateofCorrigendum = 24;
         public int NameofTrasferee = 25;
         public int AddressofTrasferee = 26;
         public int NameofProduct = 27;
         public int NameofRawMaterials = 28;
         public int RequirementofRawMaterialsperMonth = 29;
         public int ProductioninMonth = 30;
         public int WaterRequirement1stYear = 31;
         public int WaterRequirement2ndYear = 32;
         public int WaterRequirement3rdYear = 33;
         public int WaterRequirement4thYear = 34;
         public int PowerRequirement1stYear = 35;
         public int PowerRequirement2ndYear = 36;
         public int PowerRequirement3rdYear = 37;
         public int PowerRequirement4thYear = 38;
         public int TotalInvestmentInyourProject = 39;
         public int NoofManPowerRequired = 40;
         public int FormalTrasferOrInFormalTrasfer = 41;
         public int ModifiedBy = 42;
         public int IsSubmitted = 43;
         public int DocumentXML = 44;
         public int tblTransferor = 45;
         public int tblTransferee = 46;
         public int ConstitutionTypeId = 47;
         public int DeathCaseTransfer = 48;
         public int DeathWillType = 49;
         public int DeathCaseTransferWill = 50;
         public int NOC2RPermissionTaken = 51;
         public int NOCAttachment = 52;
         public int TrasferGSFC = 53;
         public int TrasferCoOperative = 54;
         public int FTOName = 55;
         public int FTOFile = 56;
         public int ConstitutionTypeIdTransferee = 57;
         public int UndertakingTransfer = 58;
         public int UndertakingTransferee = 59;
         public int SectionId = 60;
         public int LeaseDeed = 61;
         public int LeaseDeedDocument = 62;
         public int NOC2RReferenceNo = 63;
         public int IsExistingAllottee = 64;
         public int tblUTransferor = 65;
         public int tblUTransferee = 66;
         public int IsIssuedCorrigendum = 67;
         public int CorrigendumArea = 68;
         public int CorrigendumFile = 69;
         public int LeaseDeedPlotArea = 70;
         public int ProductioninDate = 71;
         public int IsCarriedOutPlot = 72;
         public int PlanPassingDate = 73;
         public int PlanPassedFile = 74;
         public int ConcernedAuthority = 75;
         public int ConcernedAuthorityName = 76;
         public int ConstructionCarriedArea = 77;
         public int GroundCoveragePercentage = 78;
         public int IsTransferSubDivision = 79;
         public int IsAmalgamation = 80;
         public int IsFamilyMembers = 81;
         public int FamilyRelation = 82;
         public int FamilyRelationDocument = 83;
         public int TransferExitPolicy = 84;
         public int ExitPolicyBuildingPlanFile = 85;
         public int ExitPolicyGPDBFile = 86;
         public int ExitPolicyNotorizedFile = 87;
         public int IsChemical = 88;
         public int PossessionReceiptFile = 89;
         public int IsUtilized = 90;
         public int DateOfConveyanceDeed = 91;
         public int ConveyanceDeedPlotArea = 92;
         public int ConveyanceDeedDocument = 93;
         public int CorrigendumTypeArea = 94;
         public int CorrigendumTypeName = 95;
         public int DateofCorrigendumName = 96;
         public int CorrigendumValueName = 97;
         public int CorrigendumFileName = 98;
         public int CorrigendumTypeProperty = 99;
         public int DateofCorrigendumProperty = 100;
         public int CorrigendumValueProperty = 101;
         public int CorrigendumFileProperty = 102;
         public int PartyCode = 103;
         public int PeriodOfUtilization = 104;
         public int IsPropertyClosedAfterUtilization = 105;
         public int IsPropertyOpen = 106;
         public int ApplicationFor = 107;
         public int ManufacturingOf = 108;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectBuildingCompletionByUserId
      public class SPSelectBuildingCompletionByUserId
      {
         public string SPName = "SPSelectBuildingCompletionByUserId";
         public int UserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectIncompleteDocumentList01092016
      public class SPSelectIncompleteDocumentList01092016
      {
         public string SPName = "SPSelectIncompleteDocumentList01092016";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region spInsertUpdatePropertyIdentyfication
      public class spInsertUpdatePropertyIdentyfication
      {
         public string SPName = "spInsertUpdatePropertyIdentyfication";
         public int mode = 0;
         public int RegionId = 1;
         public int OraRegionId = 2;
         public int RegionName = 3;
         public int EstateId = 4;
         public int OraEstateId = 5;
         public int EstateName = 6;
         public int PartyName = 7;
         public int PlotShedNo = 8;
         public int PartyCode = 9;
         public int EmailId = 10;
         public int MobileNo = 11;
         public int CreatedBy = 12;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpInsertUpdateSublettingMdoduleAdmin
      public class SpInsertUpdateSublettingMdoduleAdmin
      {
         public string SPName = "SpInsertUpdateSublettingMdoduleAdmin";
         public int Mode = 0;
         public int ApplicationformId = 1;
         public int RoleId = 2;
         public int ActionId = 3;
         public int UserId = 4;
         public int AssignedRoleId = 5;
         public int AssignActionId = 6;
         public int Remarks = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTwoRApplicationList17032017
      public class SPSelectTwoRApplicationList17032017
      {
         public string SPName = "SPSelectTwoRApplicationList17032017";
         public int UserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDAForwardToAMLeaseApplication
      public class SPDAForwardToAMLeaseApplication
      {
         public string SPName = "SPDAForwardToAMLeaseApplication";
         public int ApplicationFormId = 0;
         public int AssignedRoleId = 1;
         public int ModifiedBy = 2;
         public int BackwardRemark = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDrainageInvoiceByHeader
      public class SPSelectDrainageInvoiceByHeader
      {
         public string SPName = "SPSelectDrainageInvoiceByHeader";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateOutwardApplication
      public class SPUpdateOutwardApplication
      {
         public string SPName = "SPUpdateOutwardApplication";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSubDivisionUpdateApplicationForNOC05012017
      public class SPSubDivisionUpdateApplicationForNOC05012017
      {
         public string SPName = "SPSubDivisionUpdateApplicationForNOC05012017";
         public int ApplicationFormId = 0;
         public int UserId = 1;
         public int NOCDocumentApplicant = 2;
         public int Remark = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransfereeDetailByApplicationFormId25092016
      public class SPSelectTransfereeDetailByApplicationFormId25092016
      {
         public string SPName = "SPSelectTransfereeDetailByApplicationFormId25092016";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateTwoRApplication01092016
      public class SPInsertUpdateTwoRApplication01092016
      {
         public string SPName = "SPInsertUpdateTwoRApplication01092016";
         public int ApplicationFormId = 0;
         public int ApplicationId = 1;
         public int ReferenceNo = 2;
         public int IsFullPayment = 3;
         public int LoanRequested = 4;
         public int AreaOfPlot = 5;
         public int PrevailingAllotmentPrice = 6;
         public int TotalAllotmentPrice = 7;
         public int TotalAllotmentFees = 8;
         public int IsPermissionRequired = 9;
         public int TimePeriodRequired = 10;
         public int NameOfBank = 11;
         public int IsPastOtherInstitutePermission = 12;
         public int PastBankName = 13;
         public int Date2RPermission = 14;
         public int PastBankNOC = 15;
         public int Has2RPermissionIssued = 16;
         public int IsPastRequestAmountSame = 17;
         public int ChangeOfAmount = 18;
         public int AdministrativeCharge = 19;
         public int FinancialInstitution1 = 20;
         public int FinancialInstitution2 = 21;
         public int FinancialInstitution3 = 22;
         public int FinancialInstitution4 = 23;
         public int ApplicantDocumentList = 24;
         public int IsPerFinInstiSame = 25;
         public int IsPerSameBank = 26;
         public int BankNameEarlier = 27;
         public int BankbranchEarlier = 28;
         public int CreatedBy = 29;
         public int IsActive = 30;
         public int Operation = 31;
         public int Name = 32;
         public int Address = 33;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUserAppSummary_Test
      public class SPUserAppSummary_Test
      {
         public string SPName = "SPUserAppSummary_Test";
         public int ApplicationId = 0;
         public int RegionId = 1;
         public int EstateId = 2;
         public int FromDate = 3;
         public int ToDate = 4;
         public int UserId = 5;
         public int RoleId = 6;
         public int ReportId = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectAmalgamationModuleByApplicationFormId
      public class SPSelectAmalgamationModuleByApplicationFormId
      {
         public string SPName = "SPSelectAmalgamationModuleByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDAForwardToAMLeaseDocument
      public class SPDAForwardToAMLeaseDocument
      {
         public string SPName = "SPDAForwardToAMLeaseDocument";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
         public int BackwardRemark = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDrainageApplicationInvoice
      public class SPSelectDrainageApplicationInvoice
      {
         public string SPName = "SPSelectDrainageApplicationInvoice";
         public int ApplicationFormId = 0;
         public int UserId = 1;
         public int TxId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPlinthCertificationApplication
      public class SPSelectPlinthCertificationApplication
      {
         public string SPName = "SPSelectPlinthCertificationApplication";
         public int AssignedRoleId = 0;
         public int SearchValue = 1;
         public int SearchId = 2;
         public int RegionId = 3;
         public int UserId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateInwardApplication
      public class SPUpdateInwardApplication
      {
         public string SPName = "SPUpdateInwardApplication";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSubDivisionPaymentVerification05012017
      public class SPSubDivisionPaymentVerification05012017
      {
         public string SPName = "SPSubDivisionPaymentVerification05012017";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int UserRoleId = 2;
         public int CurrentApplicationActionId = 3;
         public int AssignedRoleId = 4;
         public int AssignedActionId = 5;
         public int Remark = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpSelectROUModuleFee
      public class SpSelectROUModuleFee
      {
         public string SPName = "SpSelectROUModuleFee";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectBuildingCompletionInvoice
      public class SPSelectBuildingCompletionInvoice
      {
         public string SPName = "SPSelectBuildingCompletionInvoice";
         public int ApplicationFormId = 0;
         public int UserId = 1;
         public int TxId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDWGMappingByEmailId
      public class SPSelectDWGMappingByEmailId
      {
         public string SPName = "SPSelectDWGMappingByEmailId";
         public int EmailId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateTwoRApplicationTrancation
      public class SPInsertUpdateTwoRApplicationTrancation
      {
         public string SPName = "SPInsertUpdateTwoRApplicationTrancation";
         public int TwoRApplicationId = 0;
         public int ApplicationFormId = 1;
         public int AllotteeName = 2;
         public int EstateId = 3;
         public int RegionId = 4;
         public int PlotTypeId = 5;
         public int PlotNumber = 6;
         public int PlotArea = 7;
         public int AllotmentDate = 8;
         public int AgreementDate = 9;
         public int PossessionDate = 10;
         public int LeaseDeedDate = 11;
         public int CreatedBy = 12;
         public int Operation = 13;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferDetailByApplicationFormId25092016
      public class SPSelectTransferDetailByApplicationFormId25092016
      {
         public string SPName = "SPSelectTransferDetailByApplicationFormId25092016";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpViewSublettingDocumentForApplicant
      public class SpViewSublettingDocumentForApplicant
      {
         public string SPName = "SpViewSublettingDocumentForApplicant";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region spDocumentRepositorySearch
      public class spDocumentRepositorySearch
      {
         public string SPName = "spDocumentRepositorySearch";
         public int Mode = 0;
         public int EstateId = 1;
         public int RegionId = 2;
         public int PlotShedTypeId = 3;
         public int PlotNumber = 4;
         public int DocumentId = 5;
         public int startDate = 6;
         public int EndDate = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpInsertUpdateInspectionDetails
      public class SpInsertUpdateInspectionDetails
      {
         public string SPName = "SpInsertUpdateInspectionDetails";
         public int InspectionId = 0;
         public int ZoneId = 1;
         public int EstateId = 2;
         public int PropertyDetails = 3;
         public int PlotShedNoId = 4;
         public int TypeofIndustryId = 5;
         public int InspectionForApplicationId = 6;
         public int InspectorUserId = 7;
         public int InspectionDatetime = 8;
         public int StatusId = 9;
         public int CreatedBy = 10;
         public int ModifiedBy = 11;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTwoRDocumentTransactionMasterByApplicationId
      public class SPSelectTwoRDocumentTransactionMasterByApplicationId
      {
         public string SPName = "SPSelectTwoRDocumentTransactionMasterByApplicationId";
         public int ApplicationId = 0;
         public int UserId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateRegionMaster
      public class SPInsertUpdateRegionMaster
      {
         public string SPName = "SPInsertUpdateRegionMaster";
         public int RegionId = 0;
         public int Region = 1;
         public int DivisionId = 2;
         public int UserId = 3;
         public int IsActive = 4;
         public int Operation = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDAForwardToSurveyorLeaseApplication
      public class SPDAForwardToSurveyorLeaseApplication
      {
         public string SPName = "SPDAForwardToSurveyorLeaseApplication";
         public int ApplicationFormId = 0;
         public int AssignedRoleId = 1;
         public int ModifiedBy = 2;
         public int BackwardRemark = 3;
         public int Path = 4;
         public int DEEflag = 5;
         public int IsCostFixation = 6;
         public int IsShedPriceDiff = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectWaterSupplyApplicationInvoice
      public class SPSelectWaterSupplyApplicationInvoice
      {
         public string SPName = "SPSelectWaterSupplyApplicationInvoice";
         public int ApplicationFormId = 0;
         public int UserId = 1;
         public int TxId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPlinthCertificationByApplicationFormId
      public class SPSelectPlinthCertificationByApplicationFormId
      {
         public string SPName = "SPSelectPlinthCertificationByApplicationFormId";
         public int ApplicationFormId = 0;
         public int mode = 1;
         public int BuildingPlanUI = 2;
         public int BuildingPlanDeptUniqueId = 3;
         public int BuildingPlanEODBApplicationId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateTransferModuleDues
      public class SPUpdateTransferModuleDues
      {
         public string SPName = "SPUpdateTransferModuleDues";
         public int ApplicationFormId = 0;
         public int AccountDues = 1;
         public int WaterDues = 2;
         public int EngineeringDues = 3;
         public int DrainageDues = 4;
         public int NDCAccount = 5;
         public int NDCEngineering = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSubDivisionUpdateSubdivisionApplicationByDEEXEN05012017
      public class SPSubDivisionUpdateSubdivisionApplicationByDEEXEN05012017
      {
         public string SPName = "SPSubDivisionUpdateSubdivisionApplicationByDEEXEN05012017";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int UserRoleId = 2;
         public int CurrentApplicationActionId = 3;
         public int AssignedRoleId = 4;
         public int AssignedActionId = 5;
         public int IsPlotRegularShapeDEE = 6;
         public int IsTheirAnyMarginRelaxationDEE = 7;
         public int Islocated9MtrDEE = 8;
         public int IsPlotFacingGIDCRoad500sqrMtrDEE = 9;
         public int IsWidthDepthRatiomaintainedDEE = 10;
         public int IsCOPKeptMaintainedDEE = 11;
         public int IsWidthOfRoadMaintainedDEE = 12;
         public int IsCommonAreaDEE = 13;
         public int IsAnyAdditionalInfrastructureDEE = 14;
         public int IsAnyAdditionalEntryPointDEE = 15;
         public int IsMinimum50PerConstructionDEE = 16;
         public int IsCommonFacilityCpoDEE = 17;
         public int IsPreventingGDCRDEE = 18;
         public int IsPlotRegularShapeXEN = 19;
         public int IsTheirAnyMarginRelaxationXEN = 20;
         public int Islocated9MtrXEN = 21;
         public int IsPlotFacingGIDCRoad500sqrMtrXEN = 22;
         public int IsWidthDepthRatiomaintainedXEN = 23;
         public int IsCOPKeptMaintainedXEN = 24;
         public int IsWidthOfRoadMaintainedXEN = 25;
         public int IsCommonAreaXEN = 26;
         public int IsAnyAdditionalInfrastructureXEN = 27;
         public int IsAnyAdditionalEntryPointXEN = 28;
         public int IsMinimum50PerConstructionXEN = 29;
         public int IsCommonFacilityCpoXEN = 30;
         public int IsPreventingGDCRXEN = 31;
         public int Remark = 32;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateAmalgamationModuleforGenerateNOCOutwardNo
      public class SpUpdateAmalgamationModuleforGenerateNOCOutwardNo
      {
         public string SPName = "SpUpdateAmalgamationModuleforGenerateNOCOutwardNo";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectBuildingCompletionInvoiceByHeader
      public class SPSelectBuildingCompletionInvoiceByHeader
      {
         public string SPName = "SPSelectBuildingCompletionInvoiceByHeader";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateTransferModule08112016
      public class SPUpdateTransferModule08112016
      {
         public string SPName = "SPUpdateTransferModule08112016";
         public int ApplicationFormId = 0;
         public int ApplicantName = 1;
         public int ApplicantAddress = 2;
         public int RegionId = 3;
         public int EstateId = 4;
         public int TypeOfPlotShed = 5;
         public int PlotShedNo = 6;
         public int PlotArea = 7;
         public int DateofAllotment = 8;
         public int ConstitutionTypeId = 9;
         public int ConstitutionTypeIdTransferee = 10;
         public int DeathCaseTransfer = 11;
         public int DeathCaseTransferWill = 12;
         public int DeathWillType = 13;
         public int TrasferGSFC = 14;
         public int TrasferCoOperative = 15;
         public int NameofAllottee = 16;
         public int AddressofAllottee = 17;
         public int ModifiedBy = 18;
         public int ApplicantLandlineNo = 19;
         public int ApplicantMobileNo = 20;
         public int ApplicantEmailId = 21;
         public int ApplicantRelationUnit = 22;
         public int AdminCharges = 23;
         public int ApplicantIdentity = 24;
         public int IsChemical = 25;
         public int IsTransferSubDivision = 26;
         public int IsAmalgamation = 27;
         public int PartyCode = 28;
         public int ApplicationFor = 29;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpWaterSupplyApplicationRemarksHistoryForReportNew
      public class SpWaterSupplyApplicationRemarksHistoryForReportNew
      {
         public string SPName = "SpWaterSupplyApplicationRemarksHistoryForReportNew";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectInspectionList
      public class SPSelectInspectionList
      {
         public string SPName = "SPSelectInspectionList";
         public int UserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSurrenderApplicationDetailsReportFooterNew
      public class SPSurrenderApplicationDetailsReportFooterNew
      {
         public string SPName = "SPSurrenderApplicationDetailsReportFooterNew";
         public int ACTIONID = 0;
         public int ActionType = 1;
         public int BeforeAfter = 2;
         public int OldApplicationStatusId = 3;
         public int RescindmentIssue = 4;
         public int StatusId = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertTwoRDocumentTransactionMaster01092016
      public class SPInsertTwoRDocumentTransactionMaster01092016
      {
         public string SPName = "SPInsertTwoRDocumentTransactionMaster01092016";
         public int strfup3 = 0;
         public int strfup4 = 1;
         public int strfup5 = 2;
         public int strfup1 = 3;
         public int strfup2 = 4;
         public int strfup8 = 5;
         public int strfup9 = 6;
         public int AplicationFormId = 7;
         public int UserId = 8;
         public int strfup10 = 9;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDEEForwardToAMLeaseApplication
      public class SPDEEForwardToAMLeaseApplication
      {
         public string SPName = "SPDEEForwardToAMLeaseApplication";
         public int ApplicationFormId = 0;
         public int AssignedRoleId = 1;
         public int ModifiedBy = 2;
         public int BackwardRemark = 3;
         public int Path = 4;
         public int DEEDCC = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetPlinthCertificationPaymentTxtIdbyApplicationFormId
      public class SPGetPlinthCertificationPaymentTxtIdbyApplicationFormId
      {
         public string SPName = "SPGetPlinthCertificationPaymentTxtIdbyApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpInsertUpdateCheckListForSubdivision
      public class SpInsertUpdateCheckListForSubdivision
      {
         public string SPName = "SpInsertUpdateCheckListForSubdivision";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int RoleId = 2;
         public int CurrentApplicationActionId = 3;
         public int AssignedRoleId = 4;
         public int ActionId = 5;
         public int IsPlotRegularShape = 6;
         public int IsTheirAnyMarginRelaxation = 7;
         public int MarginSketch = 8;
         public int MarginAreaTable = 9;
         public int Islocated9Mtr = 10;
         public int IsPlotFacingGIDCRoad500sqrMtr = 11;
         public int IsWidthDepthRatiomaintained = 12;
         public int IsCOPKeptMaintained = 13;
         public int IsWidthOfRoadMaintained = 14;
         public int IsCommonArea = 15;
         public int IsAnyAdditionalInfrastructure = 16;
         public int IsAnyAdditionalEntryPoint = 17;
         public int IsMinimum50PerConstruction = 18;
         public int Udertakingof50Per = 19;
         public int IsCommonFacilityCpo = 20;
         public int IsPreventingGDCR = 21;
         public int UploadSketchAcceptance = 22;
         public int UploadSketchofGDCR = 23;
         public int DDPlanShowingLocation = 24;
         public int Remark = 25;
         public int IsAgree = 26;
         public int ChangeRemarks = 27;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSubdivisionSelectSubDivisionModuleByApplicationFormId
      public class SPSubdivisionSelectSubDivisionModuleByApplicationFormId
      {
         public string SPName = "SPSubdivisionSelectSubDivisionModuleByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpViewAmalgamationDocumentForApplicant
      public class SpViewAmalgamationDocumentForApplicant
      {
         public string SPName = "SpViewAmalgamationDocumentForApplicant";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateSubdivisionModuleforGeneratePSOOutwardNo
      public class SpUpdateSubdivisionModuleforGeneratePSOOutwardNo
      {
         public string SPName = "SpUpdateSubdivisionModuleforGeneratePSOOutwardNo";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertTransferModule08112016
      public class SPInsertTransferModule08112016
      {
         public string SPName = "SPInsertTransferModule08112016";
         public int ReferenceNo = 0;
         public int ApplicantName = 1;
         public int ApplicantAddress = 2;
         public int RegionId = 3;
         public int EstateId = 4;
         public int TypeOfPlotShed = 5;
         public int PlotShedNo = 6;
         public int PlotArea = 7;
         public int DateofAllotment = 8;
         public int ConstitutionTypeId = 9;
         public int ConstitutionTypeIdTransferee = 10;
         public int DeathCaseTransfer = 11;
         public int DeathCaseTransferWill = 12;
         public int DeathWillType = 13;
         public int TrasferGSFC = 14;
         public int TrasferCoOperative = 15;
         public int NameofAllottee = 16;
         public int AddressofAllottee = 17;
         public int CreatedBy = 18;
         public int ApplicantLandlineNo = 19;
         public int ApplicantMobileNo = 20;
         public int ApplicantEmailId = 21;
         public int ApplicantRelationUnit = 22;
         public int AdminCharges = 23;
         public int ApplicantIdentity = 24;
         public int IsChemical = 25;
         public int IsTransferSubDivision = 26;
         public int IsAmalgamation = 27;
         public int PartyCode = 28;
         public int ApplicationFor = 29;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpSelectSublettingFee
      public class SpSelectSublettingFee
      {
         public string SPName = "SpSelectSublettingFee";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectInspectionListByInspectorUserId
      public class SPSelectInspectionListByInspectorUserId
      {
         public string SPName = "SPSelectInspectionListByInspectorUserId";
         public int InspectorUserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTwoRApplicationList01092016
      public class SPSelectTwoRApplicationList01092016
      {
         public string SPName = "SPSelectTwoRApplicationList01092016";
         public int UserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpBuldingPlanApprovalReApplay
      public class SpBuldingPlanApprovalReApplay
      {
         public string SPName = "SpBuldingPlanApprovalReApplay";
         public int mode = 0;
         public int ApplicationFormId = 1;
         public int ApplicationFormDate = 2;
         public int ApplicationId = 3;
         public int ReferenceNo = 4;
         public int StatusId = 5;
         public int ActionId = 6;
         public int AssignedRoleId = 7;
         public int ApplicantFirstName = 8;
         public int ApplicantMiddleName = 9;
         public int ApplicantLastName = 10;
         public int ApplicantAddress = 11;
         public int ApplicantPincode = 12;
         public int ApplicantCityId = 13;
         public int ApplicantTalukaId = 14;
         public int ApplicantDistrictId = 15;
         public int ApplicantStateId = 16;
         public int ApplicantCountryId = 17;
         public int ApplicantContactNo = 18;
         public int ApplicantMobileNo = 19;
         public int ApplicantEmailId = 20;
         public int ApplicantCategoryId = 21;
         public int CompanyDetailSameAsApplicant = 22;
         public int CompanyName = 23;
         public int CompanyAddress = 24;
         public int CompanyCityId = 25;
         public int CompanyTalukaId = 26;
         public int CompanyDistrictId = 27;
         public int CompanyStateId = 28;
         public int CompanyCountryId = 29;
         public int CompanyPincode = 30;
         public int CompanyContactNo = 31;
         public int CompanyMobileNo = 32;
         public int CompanyEmailId = 33;
         public int CompanyWebsite = 34;
         public int ConsititutionTypeId = 35;
         public int AlloteeName = 36;
         public int EstateId = 37;
         public int RegionId = 38;
         public int PlotShedTypeId = 39;
         public int PlotShedNumber = 40;
         public int PlotArea = 41;
         public int PlotAllotmentDate = 42;
         public int PlotAllotmentOrderNo = 43;
         public int PlotAgreementDate = 44;
         public int PlotPhysicalPossessionDate = 45;
         public int PlotDeedId = 46;
         public int PlotDeedDate = 47;
         public int PlotContactNo = 48;
         public int PlotFaxNo = 49;
         public int PlotCategoryId = 50;
         public int CreatedBy = 51;
         public int CreatedOn = 52;
         public int IsActive = 53;
         public int PreviouslyTakenDeed = 54;
         public int IFP_PersonId = 55;
         public int IFP_IsFromIFP = 56;
         public int IFP_ProjectId = 57;
         public int IsNameDifference = 58;
         public int Relationwithunit = 59;
         public int ApplicantName = 60;
         public int OCALetterDoc = 61;
         public int LicenceAgreementDoc = 62;
         public int PossessionReceiptDoc = 63;
         public int CompletesetofDrawingDoc = 64;
         public int LatestTrasferOrderDoc = 65;
         public int CopyofTimeLimitExtensionLetterDoc = 66;
         public int CTENOCFromGPCB = 67;
         public int FieldBookSketch = 68;
         public int IndustryTypeId = 69;
         public int IsHighRisk = 70;
         public int RiskType = 71;
         public int DateofPossession = 72;
         public int ApplicantUploadDocument = 73;
         public int TypeOfApproval = 74;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPFillAMDocpath
      public class SPFillAMDocpath
      {
         public string SPName = "SPFillAMDocpath";
         public int ApplicationFormId = 0;
         public int AMDocCoverLatter = 1;
         public int AMDocDEE = 2;
         public int AMDocAO = 3;
         public int AMAnnexure = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubDivisionModuleByApplicationFormIdForMail
      public class SPSelectSubDivisionModuleByApplicationFormIdForMail
      {
         public string SPName = "SPSelectSubDivisionModuleByApplicationFormIdForMail";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectAmalgamationPaymentAdminCharge
      public class SPSelectAmalgamationPaymentAdminCharge
      {
         public string SPName = "SPSelectAmalgamationPaymentAdminCharge";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteDWGMAppingById
      public class SPDeleteDWGMAppingById
      {
         public string SPName = "SPDeleteDWGMAppingById";
         public int Id = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectUTransfereeDetailByApplicationFormId
      public class SPSelectUTransfereeDetailByApplicationFormId
      {
         public string SPName = "SPSelectUTransfereeDetailByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateSublettingFeeDetail
      public class SPUpdateSublettingFeeDetail
      {
         public string SPName = "SPUpdateSublettingFeeDetail";
         public int Mode = 0;
         public int ApplicationFormId = 1;
         public int AccountDues = 2;
         public int WaterDues = 3;
         public int OtherDues = 4;
         public int DrainageDues = 5;
         public int SL_OSINST_A = 6;
         public int SL_OSIDPPI_A = 7;
         public int SL_OSSC_A = 8;
         public int SL_OSSC_ST = 9;
         public int SL_OSSC_EC = 10;
         public int SL_OSSWCSC = 11;
         public int SL_OSSCKKC = 12;
         public int SL_OSNAA_A = 13;
         public int SL_OSNAA_ST = 14;
         public int SL_OSNAA_EC = 15;
         public int SL_OSSWCNAA = 16;
         public int SL_OSNAAKKC = 17;
         public int SL_OSLR_A = 18;
         public int SL_OSLR_ST = 19;
         public int SL_OSLR_EC = 20;
         public int SL_OSSWCLR = 21;
         public int SL_OSLRKKC = 22;
         public int SL_OSIR_A = 23;
         public int SL_OSIUF_A = 24;
         public int SL_OSIUF_ST = 25;
         public int SL_OSIUF_EC = 26;
         public int SL_OSFULLPAYMENT_A = 27;
         public int SL_LRCOSINST_A = 28;
         public int SL_LRCOSIDP_A = 29;
         public int SL_SC_OS_CGST = 30;
         public int SL_SC_OS_SGST = 31;
         public int SL_NAA_OS_CGST = 32;
         public int SL_NAA_OS_SGST = 33;
         public int SL_LR_OS_CGST = 34;
         public int SL_LR_OS_SGST = 35;
         public int SL_INTREV_OS_CGST = 36;
         public int SL_INTREV_OS_SGST = 37;
         public int SL_SC_BASE = 38;
         public int SL_SC_SGSTAmount = 39;
         public int SL_SC_CGSTAmount = 40;
         public int SL_SC_ACCHEAD_C = 41;
         public int SL_SC_ACC_M = 42;
         public int SL_SC_FROM_D = 43;
         public int SL_SC_TO_D = 44;
         public int SL_SC_ACC_NO = 45;
         public int SL_SC_SGST_A = 46;
         public int SL_SC_CGST_A = 47;
         public int SL_SC_ACC_N = 48;
         public int SL_NAA_BASE = 49;
         public int SL_NAA_SGSTAmount = 50;
         public int SL_NAA_CGSTAmount = 51;
         public int SL_NAA_ACCHEAD_C = 52;
         public int SL_NAA_ACC_M = 53;
         public int SL_NAA_FROM_D = 54;
         public int SL_NAA_TO_D = 55;
         public int SL_NAA_ACC_NO = 56;
         public int SL_NAA_SGST_A = 57;
         public int SL_NAA_CGST_A = 58;
         public int SL_NAA_ACC_N = 59;
         public int SL_LR_BASE = 60;
         public int SL_LR_SGSTAmount = 61;
         public int SL_LR_CGSTAmount = 62;
         public int SL_LR_ACCHEAD_C = 63;
         public int SL_LR_ACC_M = 64;
         public int SL_LR_FROM_D = 65;
         public int SL_LR_TO_D = 66;
         public int SL_LR_ACC_NO = 67;
         public int SL_LR_SGST_A = 68;
         public int SL_LR_CGST_A = 69;
         public int SL_LR_ACC_N = 70;
         public int SL_INT_BASE = 71;
         public int SL_INT_SGSTAmount = 72;
         public int SL_INT_CGSTAmount = 73;
         public int SL_INT_ACCHEAD_C = 74;
         public int SL_INT_ACC_M = 75;
         public int SL_INT_FROM_D = 76;
         public int SL_INT_TO_D = 77;
         public int SL_INT_ACC_NO = 78;
         public int SL_INT_SGST_A = 79;
         public int SL_INT_CGST_A = 80;
         public int SL_INT_ACC_N = 81;
         public int ModifiedBy = 82;
         public int POPaymentDocument = 83;
         public int Remarks = 84;
         public int GSTNumber = 85;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectInspectorDetailsByInspectionId
      public class SPSelectInspectorDetailsByInspectionId
      {
         public string SPName = "SPSelectInspectorDetailsByInspectionId";
         public int InspectionId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTwoRDocument01092016
      public class SPSelectTwoRDocument01092016
      {
         public string SPName = "SPSelectTwoRDocument01092016";
         public int AplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectRegionMasterByRegion
      public class SPSelectRegionMasterByRegion
      {
         public string SPName = "SPSelectRegionMasterByRegion";
         public int Region = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertCRDailyApplicationDetailsForSubletting
      public class SPInsertCRDailyApplicationDetailsForSubletting
      {
         public string SPName = "SPInsertCRDailyApplicationDetailsForSubletting";
         public int ApplicationId = 0;
         public int ApplicationFormId = 1;
         public int AppForwardDate = 2;
         public int AppActualForwardDate = 3;
         public int ActionId = 4;
         public int AssignRoleId = 5;
         public int EstateId = 6;
         public int Remark = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectIFPDistrictId
      public class SPSelectIFPDistrictId
      {
         public string SPName = "SPSelectIFPDistrictId";
         public int DistrcitId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteGeneralApplicationandLeaseApplicationFormByApplicationFormId
      public class SPDeleteGeneralApplicationandLeaseApplicationFormByApplicationFormId
      {
         public string SPName = "SPDeleteGeneralApplicationandLeaseApplicationFormByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertTransferModuleOtherQuery
      public class SPInsertTransferModuleOtherQuery
      {
         public string SPName = "SPInsertTransferModuleOtherQuery";
         public int ApplicationFormId = 0;
         public int ActionId = 1;
         public int AssignedRoleId = 2;
         public int Query = 3;
         public int QueryReply = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateSubDivisionModuleApplicationByApplicantQuery
      public class SpUpdateSubDivisionModuleApplicationByApplicantQuery
      {
         public string SPName = "SpUpdateSubDivisionModuleApplicationByApplicantQuery";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int CurrentApplicationActionId = 2;
         public int NewAssinedActionId = 3;
         public int ApplicantIdentity = 4;
         public int FamilyRelationDocument = 5;
         public int ExistingGIDCFamilyRelationDocument = 6;
         public int BuldingPlanDocument = 7;
         public int RevisedBuldingPlanDocument = 8;
         public int OriginalPlotSubDivisionDocument = 9;
         public int NOCDocument = 10;
         public int NOCPaidGIDCDocument = 11;
         public int IncorporatedDocument = 12;
         public int SketchOfSubDivisionDocument = 13;
         public int UndertakingFacilitiesAndAreaDocument = 14;
         public int UndertakingLessThan50GCPlotDocument = 15;
         public int UtilisationElectricityBillDocument = 16;
         public int UtilisationWaterSupplyBillDocument = 17;
         public int Remarks = 18;
         public int AdditionalDocumentName = 19;
         public int AdditionalDocument = 20;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertTransactionReferenceNoPaymentDetailsForBuildingCompletion
      public class SPInsertTransactionReferenceNoPaymentDetailsForBuildingCompletion
      {
         public string SPName = "SPInsertTransactionReferenceNoPaymentDetailsForBuildingCompletion";
         public int TxId = 0;
         public int ApplicationFormId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferModuleFormalReportForFTO
      public class SPSelectTransferModuleFormalReportForFTO
      {
         public string SPName = "SPSelectTransferModuleFormalReportForFTO";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPlinthCertificationInvoice
      public class SPSelectPlinthCertificationInvoice
      {
         public string SPName = "SPSelectPlinthCertificationInvoice";
         public int ApplicationFormId = 0;
         public int UserId = 1;
         public int TxId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectUTransferorDetailByApplicationFormId
      public class SPSelectUTransferorDetailByApplicationFormId
      {
         public string SPName = "SPSelectUTransferorDetailByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPBuildingPlanApprovalApplicationRemarksHistoryForReport
      public class SPBuildingPlanApprovalApplicationRemarksHistoryForReport
      {
         public string SPName = "SPBuildingPlanApprovalApplicationRemarksHistoryForReport";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectInspectionDetailsbyInspectionId
      public class SPSelectInspectionDetailsbyInspectionId
      {
         public string SPName = "SPSelectInspectionDetailsbyInspectionId";
         public int InspectionId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateSublettingModuleApplicationByDEE
      public class SpUpdateSublettingModuleApplicationByDEE
      {
         public string SPName = "SpUpdateSublettingModuleApplicationByDEE";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int CurrentApplicationActionId = 2;
         public int NewAssinedActionId = 3;
         public int ConstructionReport = 4;
         public int ConstructionReportRemarks = 5;
         public int CompletedConstructionReport = 6;
         public int tblDEEPhoto = 7;
         public int IsRelaxation = 8;
         public int IndustrTypeId = 9;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateTransferModuleBankDetails
      public class SPUpdateTransferModuleBankDetails
      {
         public string SPName = "SPUpdateTransferModuleBankDetails";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
         public int NDCEngineering = 2;
         public int NDCAccount = 3;
         public int PTOPaymentDocuments = 4;
         public int Remark = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectRegionMasterByRegionId
      public class SPSelectRegionMasterByRegionId
      {
         public string SPName = "SPSelectRegionMasterByRegionId";
         public int RegionId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelect2RApplicationPaymentDetailByTwoRPlotId
      public class SPSelect2RApplicationPaymentDetailByTwoRPlotId
      {
         public string SPName = "SPSelect2RApplicationPaymentDetailByTwoRPlotId";
         public int TwoRPlotId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteLeaseDDDetailsByLeaseAppDDId
      public class SPDeleteLeaseDDDetailsByLeaseAppDDId
      {
         public string SPName = "SPDeleteLeaseDDDetailsByLeaseAppDDId";
         public int LeaseAppDDId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferModuleOtherQuery
      public class SPSelectTransferModuleOtherQuery
      {
         public string SPName = "SPSelectTransferModuleOtherQuery";
         public int ApplicationFormId = 0;
         public int AssignedRoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateSubDivisionModuleApplicationByAdmin
      public class SpUpdateSubDivisionModuleApplicationByAdmin
      {
         public string SPName = "SpUpdateSubDivisionModuleApplicationByAdmin";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int CurrentApplicationActionId = 2;
         public int NewAssinedActionId = 3;
         public int ApplicantIdentityOKNOTOK = 4;
         public int ApplicantIdentityRemarks = 5;
         public int FamilyRelationDocumentOKNOTOK = 6;
         public int FamilyRelationDocumentRemarks = 7;
         public int ExistingGIDCFamilyRelationDocumentOKNOTOK = 8;
         public int ExistingGIDCFamilyRelationDocumentRemarks = 9;
         public int BuldingPlanDocumentOKNOTOK = 10;
         public int BuldingPlanDocumentRemarks = 11;
         public int RevisedBuldingPlanDocumentOKNOTOK = 12;
         public int RevisedBuldingPlanDocumentRemarks = 13;
         public int OriginalPlotSubDivisionDocumentOKNOTOK = 14;
         public int OriginalPlotSubDivisionDocumentRemarks = 15;
         public int NOCPaidGIDCDocumentOKNOTOK = 16;
         public int NOCPaidGIDCDocumentRemarks = 17;
         public int NOCDocumentOKNOTOK = 18;
         public int NOCDocumentRemarks = 19;
         public int IncorporatedDocumentOKNOTOK = 20;
         public int IncorporatedDocumentRemarks = 21;
         public int SketchOfSubDivisionDocumentOKNOTOK = 22;
         public int SketchOfSubDivisionDocumentRemarks = 23;
         public int UndertakingFacilitiesAndAreaDocumentOKNOTOK = 24;
         public int UndertakingFacilitiesAndAreaDocumentRemarks = 25;
         public int UndertakingLessThan50GCPlotDocumentOKNOTOK = 26;
         public int UndertakingLessThan50GCPlotDocumentRemarks = 27;
         public int UtilisationElectricityBillDocumentOKNOTOK = 28;
         public int UtilisationElectricityBillDocumentRemarks = 29;
         public int UtilisationWaterSupplyBillDocumentOKNOTOK = 30;
         public int UtilisationWaterSupplyBillDocumentRemarks = 31;
         public int Remarks = 32;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPlainthSelfCertificationByUserID
      public class SPSelectPlainthSelfCertificationByUserID
      {
         public string SPName = "SPSelectPlainthSelfCertificationByUserID";
         public int UserId = 0;
         public int mode = 1;
         public int BuildingPlanUI = 2;
         public int BuildingPlanDeptUniqueId = 3;
         public int BuildingPlanEODBApplicationId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPlinthCertificationInvoiceByHeader
      public class SPSelectPlinthCertificationInvoiceByHeader
      {
         public string SPName = "SPSelectPlinthCertificationInvoiceByHeader";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateActionApplication
      public class SPUpdateActionApplication
      {
         public string SPName = "SPUpdateActionApplication";
         public int ApplicationFormId = 0;
         public int ActionId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferApplicationListDetails22102016
      public class SPSelectTransferApplicationListDetails22102016
      {
         public string SPName = "SPSelectTransferApplicationListDetails22102016";
         public int AssignedRoleId = 0;
         public int SearchValue = 1;
         public int SearchId = 2;
         public int RegionId = 3;
         public int UserId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferApplicationListDetailsWithPTOPayment
      public class SPSelectTransferApplicationListDetailsWithPTOPayment
      {
         public string SPName = "SPSelectTransferApplicationListDetailsWithPTOPayment";
         public int RegionId = 0;
         public int UserId = 1;
         public int SearchValue = 2;
         public int SearchId = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDMBackwardToRMCorrigendum
      public class SPDMBackwardToRMCorrigendum
      {
         public string SPName = "SPDMBackwardToRMCorrigendum";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
         public int BackwardRemark = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateTransferModuleOtherQuery
      public class SPUpdateTransferModuleOtherQuery
      {
         public string SPName = "SPUpdateTransferModuleOtherQuery";
         public int TransferModuleOtherQueryId = 0;
         public int QueryReply = 1;
         public int Documents = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region GetSundaysbyyearandmonth
      public class GetSundaysbyyearandmonth
      {
         public string SPName = "GetSundaysbyyearandmonth";
         public int year = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSubDivisionApplicationRemarksHistory
      public class SPSubDivisionApplicationRemarksHistory
      {
         public string SPName = "SPSubDivisionApplicationRemarksHistory";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectBuildingCompletionApplicationPaymentDetailByApplicationFormId
      public class SPSelectBuildingCompletionApplicationPaymentDetailByApplicationFormId
      {
         public string SPName = "SPSelectBuildingCompletionApplicationPaymentDetailByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetBuildingCompletionID
      public class SPGetBuildingCompletionID
      {
         public string SPName = "SPGetBuildingCompletionID";
         public int IFP_Projectid = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateApplicantUserMaster
      public class SPInsertUpdateApplicantUserMaster
      {
         public string SPName = "SPInsertUpdateApplicantUserMaster";
         public int UserId = 0;
         public int FirstName = 1;
         public int MiddleName = 2;
         public int LastName = 3;
         public int ContactNo = 4;
         public int MobileNo = 5;
         public int EmailId = 6;
         public int Password = 7;
         public int IsActive = 8;
         public int Operation = 9;
         public int IFP_PersonId = 10;
         public int IFP_IsFromIFP = 11;
         public int Prefix = 12;
         public int UserId1 = 13;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateTrasferModuleApplicationByDEE
      public class SpUpdateTrasferModuleApplicationByDEE
      {
         public string SPName = "SpUpdateTrasferModuleApplicationByDEE";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int CurrentApplicationActionId = 2;
         public int NewAssinedActionId = 3;
         public int ConstructionReport = 4;
         public int ConstructionReportRemarks = 5;
         public int CompletedConstructionReport = 6;
         public int tblDEEPhoto = 7;
         public int DSSYearOfConstruction = 8;
         public int DSSYear20PercentOfConstruction = 9;
         public int CurrentPercentConstruction = 10;
         public int BuildingInsidePlot = 11;
         public int ViolativeConstruction = 12;
         public int AgreeDetailsDSS = 13;
         public int FeedbackDSS = 14;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpAmalgamationApplicationRemarksHistory
      public class SpAmalgamationApplicationRemarksHistory
      {
         public string SPName = "SpAmalgamationApplicationRemarksHistory";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateSubdivisionPaymentPSO
      public class SPUpdateSubdivisionPaymentPSO
      {
         public string SPName = "SPUpdateSubdivisionPaymentPSO";
         public int ApplicationFormid = 0;
         public int ModifiedBy = 1;
         public int PSOPaymentDocument = 2;
         public int Remarks = 3;
         public int NDCAccount = 4;
         public int NDCEngineering = 5;
         public int FSOOutwardNo = 6;
         public int FSODate = 7;
         public int FSODocument = 8;
         public int PSOOutwardNo = 9;
         public int PSODate = 10;
         public int PSODocument = 11;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPROUApplicationDetailsReportTemp
      public class SPROUApplicationDetailsReportTemp
      {
         public string SPName = "SPROUApplicationDetailsReportTemp";
         public int REGIONID = 0;
         public int ACTIONID = 1;
         public int ActionType = 2;
         public int BeforeAfter = 3;
         public int OldApplicationStatusId = 4;
         public int PTOIssueCMD = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectOfficeUserMasterForChangePassword
      public class SPSelectOfficeUserMasterForChangePassword
      {
         public string SPName = "SPSelectOfficeUserMasterForChangePassword";
         public int EmailId = 0;
         public int Password = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateTwoRApplicationByAdmin
      public class SpUpdateTwoRApplicationByAdmin
      {
         public string SPName = "SpUpdateTwoRApplicationByAdmin";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int CurrentApplicationActionId = 2;
         public int NewAssinedActionId = 3;
         public int DocumentXML = 4;
         public int Remarks = 5;
         public int IsCollatral = 6;
         public int SurveyNo = 7;
         public int Manufacturing = 8;
         public int FinancialInstitutionsXML = 9;
         public int letterNo = 10;
         public int LetterDate = 11;
         public int CityName = 12;
         public int TalukaName = 13;
         public int DistrictName = 14;
         public int WardNos = 15;
         public int IsLoanTakenFromMultipleBank = 16;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateAmalgamationSATP
      public class SPUpdateAmalgamationSATP
      {
         public string SPName = "SPUpdateAmalgamationSATP";
         public int Mode = 0;
         public int ApplicationFormId = 1;
         public int UserId = 2;
         public int AssignRoleId = 3;
         public int AssignActionId = 4;
         public int IsIncorporateDDPlan = 5;
         public int DateofIncorporate = 6;
         public int DDPlanSATP = 7;
         public int Remarks = 8;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDMBackwardToRMDocumentChecking
      public class SPDMBackwardToRMDocumentChecking
      {
         public string SPName = "SPDMBackwardToRMDocumentChecking";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
         public int BackwardRemark = 2;
         public int StatusId = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubDivisionByUserId
      public class SPSelectSubDivisionByUserId
      {
         public string SPName = "SPSelectSubDivisionByUserId";
         public int UserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPlinthCertificateByApplicationFormIdForView
      public class SPSelectPlinthCertificateByApplicationFormIdForView
      {
         public string SPName = "SPSelectPlinthCertificateByApplicationFormIdForView";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region GetBuildingPlanApprovalApplicationDatabyEODBApplicationFormId
      public class GetBuildingPlanApprovalApplicationDatabyEODBApplicationFormId
      {
         public string SPName = "GetBuildingPlanApprovalApplicationDatabyEODBApplicationFormId";
         public int EODBApplicationId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateLeaseDeedApplication
      public class SPInsertUpdateLeaseDeedApplication
      {
         public string SPName = "SPInsertUpdateLeaseDeedApplication";
         public int ApplicationFormId = 0;
         public int ReferenceNo = 1;
         public int IndustryTypeId = 2;
         public int ApplicationId = 3;
         public int LeaseTypeId = 4;
         public int FinalPlotArea = 5;
         public int ApplicantDocumentList = 6;
         public int CreatedBy = 7;
         public int IsActive = 8;
         public int Operation = 9;
         public int IsPlotUtilize = 10;
         public int AdminCharges = 11;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateTrasferModuleApplicationByAdmin22102016
      public class SpUpdateTrasferModuleApplicationByAdmin22102016
      {
         public string SPName = "SpUpdateTrasferModuleApplicationByAdmin22102016";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int CurrentApplicationActionId = 2;
         public int NewAssinedActionId = 3;
         public int DocumentXML = 4;
         public int Remarks = 5;
         public int StrDocument = 6;
         public int StrDocument1 = 7;
         public int FormalTrasferOrInFormalTrasfer = 8;
         public int FormalTrasferOrInFormalTrasferCal = 9;
         public int ApplicantIdentityOkNotOk = 10;
         public int ApplicantIdentityOkNotOkRemarks = 11;
         public int FTOFileOkNotOk = 12;
         public int FTOFileOkNotOkRemarks = 13;
         public int PossessionReceiptFileOkNotOk = 14;
         public int PossessionReceiptFileOkNotOkRemarks = 15;
         public int CorrigendumFileOkNotOk = 16;
         public int CorrigendumFileOkNotOkRemarks = 17;
         public int LeaseDeedDocumentOkNotOk = 18;
         public int LeaseDeedDocumentOkNotOkRemarks = 19;
         public int NOCAttachmentOkNotOk = 20;
         public int NOCAttachmentOkNotOkRemarks = 21;
         public int PlanPassedFileOkNotOk = 22;
         public int PlanPassedFileOkNotOkRemarks = 23;
         public int FamilyRelationDocumentOkNotOk = 24;
         public int FamilyRelationDocumentOkNotOkRemarks = 25;
         public int AMApplicantIdentityOkNotOk = 26;
         public int AMApplicantIdentityOkNotOkRemarks = 27;
         public int AMFTOFileOkNotOk = 28;
         public int AMFTOFileOkNotOkRemarks = 29;
         public int AMPossessionReceiptFileOkNotOk = 30;
         public int AMPossessionReceiptFileOkNotOkRemarks = 31;
         public int AMCorrigendumFileOkNotOk = 32;
         public int AMCorrigendumFileOkNotOkRemarks = 33;
         public int AMLeaseDeedDocumentOkNotOk = 34;
         public int AMLeaseDeedDocumentOkNotOkRemarks = 35;
         public int AMNOCAttachmentOkNotOk = 36;
         public int AMNOCAttachmentOkNotOkRemarks = 37;
         public int AMPlanPassedFileOkNotOk = 38;
         public int AMPlanPassedFileOkNotOkRemarks = 39;
         public int AMFamilyRelationDocumentOkNotOk = 40;
         public int AMFamilyRelationDocumentOkNotOkRemarks = 41;
         public int RMApplicantIdentityOkNotOk = 42;
         public int RMApplicantIdentityOkNotOkRemarks = 43;
         public int RMFTOFileOkNotOk = 44;
         public int RMFTOFileOkNotOkRemarks = 45;
         public int RMPossessionReceiptFileOkNotOk = 46;
         public int RMPossessionReceiptFileOkNotOkRemarks = 47;
         public int RMCorrigendumFileOkNotOk = 48;
         public int RMCorrigendumFileOkNotOkRemarks = 49;
         public int RMLeaseDeedDocumentOkNotOk = 50;
         public int RMLeaseDeedDocumentOkNotOkRemarks = 51;
         public int RMNOCAttachmentOkNotOk = 52;
         public int RMNOCAttachmentOkNotOkRemarks = 53;
         public int RMPlanPassedFileOkNotOk = 54;
         public int RMPlanPassedFileOkNotOkRemarks = 55;
         public int RMFamilyRelationDocumentOkNotOk = 56;
         public int RMFamilyRelationDocumentOkNotOkRemarks = 57;
         public int TypeofTransferRemarksAM = 58;
         public int TypeofTransferRemarksRM = 59;
         public int IsAggredTransferMode = 60;
         public int ConveyanceDeedDocumentOkNotOk = 61;
         public int ConveyanceDeedDocumentOkNotOkRemarks = 62;
         public int AMConveyanceDeedDocumentOkNotOk = 63;
         public int AMConveyanceDeedDocumentOkNotOkRemarks = 64;
         public int RMConveyanceDeedDocumentOkNotOk = 65;
         public int RMConveyanceDeedDocumentOkNotOkRemarks = 66;
         public int DACorrigendumFileNameDocumentOkNotOk = 67;
         public int DACorrigendumFileNameDocumentOkNotOkRemarks = 68;
         public int AMCorrigendumFileNameDocumentOkNotOk = 69;
         public int AMCorrigendumFileNameDocumentOkNotOkRemarks = 70;
         public int RMCorrigendumFileNameDocumentOkNotOk = 71;
         public int RMCorrigendumFileNameDocumentOkNotOkRemarks = 72;
         public int DACorrigendumFilePropertyDocumentOkNotOk = 73;
         public int DACorrigendumFilePropertyDocumentOkNotOkRemarks = 74;
         public int AMCorrigendumFilePropertyDocumentOkNotOk = 75;
         public int AMCorrigendumFilePropertyDocumentOkNotOkRemarks = 76;
         public int RMCorrigendumFilePropertyDocumentOkNotOk = 77;
         public int RMCorrigendumFilePropertyDocumentOkNotOkRemarks = 78;
         public int DAUndertakingDocumentOkNotOk = 79;
         public int DAUndertakingDocumentOkNotOkRemarks = 80;
         public int AMUndertakingDocumentOkNotOk = 81;
         public int AMUndertakingDocumentOkNotOkRemarks = 82;
         public int RMUndertakingDocumentOkNotOk = 83;
         public int RMUndertakingDocumentOkNotOkRemarks = 84;
         public int DMApplicantIdentityOkNotOk = 85;
         public int DMApplicantIdentityOkNotOkRemarks = 86;
         public int DMFTOFileOkNotOk = 87;
         public int DMFTOFileOkNotOkRemarks = 88;
         public int DMPossessionReceiptFileOkNotOk = 89;
         public int DMPossessionReceiptFileOkNotOkRemarks = 90;
         public int DMCorrigendumFileOkNotOk = 91;
         public int DMCorrigendumFileOkNotOkRemarks = 92;
         public int DMCorrigendumFileNameDocumentOkNotOk = 93;
         public int DMCorrigendumFileNameDocumentOkNotOkRemarks = 94;
         public int DMCorrigendumFilePropertyDocumentOkNotOk = 95;
         public int DMCorrigendumFilePropertyDocumentOkNotOkRemarks = 96;
         public int DMLeaseDeedDocumentOkNotOk = 97;
         public int DMLeaseDeedDocumentOkNotOkRemarks = 98;
         public int DMNOCAttachmentOkNotOk = 99;
         public int DMNOCAttachmentOkNotOkRemarks = 100;
         public int DMPlanPassedFileOkNotOk = 101;
         public int DMPlanPassedFileOkNotOkRemarks = 102;
         public int DMFamilyRelationDocumentOkNotOk = 103;
         public int DMFamilyRelationDocumentOkNotOkRemarks = 104;
         public int DMConveyanceDeedDocumentOkNotOk = 105;
         public int DMConveyanceDeedDocumentOkNotOkRemarks = 106;
         public int DMUndertakingDocumentOkNotOk = 107;
         public int DMUndertakingDocumentOkNotOkRemarks = 108;
         public int DSPublicKey = 109;
         public int DSHash = 110;
         public int DScrtString = 111;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpSelectEstateMasterByZoneId
      public class SpSelectEstateMasterByZoneId
      {
         public string SPName = "SpSelectEstateMasterByZoneId";
         public int ZoneID = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateTwoRDocumentTransactionMaster01092016
      public class SPUpdateTwoRDocumentTransactionMaster01092016
      {
         public string SPName = "SPUpdateTwoRDocumentTransactionMaster01092016";
         public int strfup1 = 0;
         public int strfup2 = 1;
         public int strfup3 = 2;
         public int strfup4 = 3;
         public int strfup5 = 4;
         public int strfup6 = 5;
         public int strfup7 = 6;
         public int strfup8 = 7;
         public int strfup9 = 8;
         public int AplicationFormId = 9;
         public int UserId = 10;
         public int QueryAttachment = 11;
         public int Remark = 12;
         public int ActionId = 13;
         public int strfup10 = 14;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSublettingModuleHOFlowAllBranch
      public class SPSelectSublettingModuleHOFlowAllBranch
      {
         public string SPName = "SPSelectSublettingModuleHOFlowAllBranch";
         public int BranchId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectApplicantDetailsByUserIdForMobileApp17032017
      public class SPSelectApplicantDetailsByUserIdForMobileApp17032017
      {
         public string SPName = "SPSelectApplicantDetailsByUserIdForMobileApp17032017";
         public int UserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertEmailSendDetails
      public class SPInsertEmailSendDetails
      {
         public string SPName = "SPInsertEmailSendDetails";
         public int ApplicationFormId = 0;
         public int ReferenceNo = 1;
         public int ActionId = 2;
         public int EmailFrom = 3;
         public int EmailTo = 4;
         public int Emailcc = 5;
         public int EmailBcc = 6;
         public int EmailBody = 7;
         public int IsMailSend = 8;
         public int CreatedBy = 9;
         public int IsActive = 10;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSubLettingSelectFillDetailByPropertyIdentificationNo
      public class SPSubLettingSelectFillDetailByPropertyIdentificationNo
      {
         public string SPName = "SPSubLettingSelectFillDetailByPropertyIdentificationNo";
         public int PropertyIdentiNo = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpRejectReleaseConnectionWaterSupplyApplication
      public class SpRejectReleaseConnectionWaterSupplyApplication
      {
         public string SPName = "SpRejectReleaseConnectionWaterSupplyApplication";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int UserRoleId = 2;
         public int CurrentApplicationActionId = 3;
         public int CurrentApplicationStatusId = 4;
         public int AssignedRoleId = 5;
         public int AssignedActionId = 6;
         public int Remarks = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDMBackwardToRMLeaseDocument
      public class SPDMBackwardToRMLeaseDocument
      {
         public string SPName = "SPDMBackwardToRMLeaseDocument";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
         public int BackwardRemark = 2;
         public int StatusId = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPCheckUniqueReferenceNoForSubDivisionModule
      public class SPCheckUniqueReferenceNoForSubDivisionModule
      {
         public string SPName = "SPCheckUniqueReferenceNoForSubDivisionModule";
         public int ReferenceNo = 0;
         public int EstateId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectBuildingCompletionApplicationPaymentDetailByTxId
      public class SPSelectBuildingCompletionApplicationPaymentDetailByTxId
      {
         public string SPName = "SPSelectBuildingCompletionApplicationPaymentDetailByTxId";
         public int TxId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateSubdivisionModuleFSOConditionsByFSOId
      public class SPUpdateSubdivisionModuleFSOConditionsByFSOId
      {
         public string SPName = "SPUpdateSubdivisionModuleFSOConditionsByFSOId";
         public int FSOConditionId = 0;
         public int ModifiedBy = 1;
         public int mode = 2;
         public int FSOCondition = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectAmalgamationPlotDetailsDisplay
      public class SPSelectAmalgamationPlotDetailsDisplay
      {
         public string SPName = "SPSelectAmalgamationPlotDetailsDisplay";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectCheckedDocumentByHelpdesk
      public class SPSelectCheckedDocumentByHelpdesk
      {
         public string SPName = "SPSelectCheckedDocumentByHelpdesk";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateTransferApplicationQueryDocuments
      public class SPUpdateTransferApplicationQueryDocuments
      {
         public string SPName = "SPUpdateTransferApplicationQueryDocuments";
         public int ApplicationFormId = 0;
         public int ActionId = 1;
         public int QueryDocumentsXML = 2;
         public int Remarks = 3;
         public int UserId = 4;
         public int QueryDocumentsReply = 5;
         public int ApplicantIdentity = 6;
         public int FTOFile = 7;
         public int PossessionReceiptFile = 8;
         public int CorrigendumFile = 9;
         public int LeaseDeedDocument = 10;
         public int NOCAttachment = 11;
         public int PlanPassedFile = 12;
         public int FamilyRelationDocument = 13;
         public int ConveyanceDeedDocument = 14;
         public int CorrigendumFileName = 15;
         public int CorrigendumFileProperty = 16;
         public int UndertakingTransfer = 17;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpSurrenderApplicationRemarksHistoryForReport
      public class SpSurrenderApplicationRemarksHistoryForReport
      {
         public string SPName = "SpSurrenderApplicationRemarksHistoryForReport";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectAdminInspectionListByInspectorUserId
      public class SPSelectAdminInspectionListByInspectorUserId
      {
         public string SPName = "SPSelectAdminInspectionListByInspectorUserId";
         public int AssignedRoleId = 0;
         public int SearchValue = 1;
         public int SearchId = 2;
         public int RegionId = 3;
         public int UserId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region GetPlotShedNo_Pager_test
      public class GetPlotShedNo_Pager_test
      {
         public string SPName = "GetPlotShedNo_Pager_test";
         public int PageIndex = 0;
         public int PageSize = 1;
         public int RecordCount = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetPendingDayAtGIDCendForrROU
      public class SPGetPendingDayAtGIDCendForrROU
      {
         public string SPName = "SPGetPendingDayAtGIDCendForrROU";
         public int ApplicationFormId = 0;
         public int Days = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSublettingDEEPhotoDetailByApplicationFormId
      public class SPSelectSublettingDEEPhotoDetailByApplicationFormId
      {
         public string SPName = "SPSelectSublettingDEEPhotoDetailByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region sp_DMSSelect
      public class sp_DMSSelect
      {
         public string SPName = "sp_DMSSelect";
         public int Mode = 0;
         public int OfficeId = 1;
         public int DevisionId = 2;
         public int RegionId = 3;
         public int GroupId = 4;
         public int BranchId = 5;
         public int EstateId = 6;
         public int PlottypeId = 7;
         public int PlotNumber = 8;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPCheckUniqueGrievanceReferenceNo
      public class SPCheckUniqueGrievanceReferenceNo
      {
         public string SPName = "SPCheckUniqueGrievanceReferenceNo";
         public int ReferenceNo = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpRejectReleaseConnectionDrainageApplication
      public class SpRejectReleaseConnectionDrainageApplication
      {
         public string SPName = "SpRejectReleaseConnectionDrainageApplication";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int UserRoleId = 2;
         public int CurrentApplicationActionId = 3;
         public int CurrentApplicationStatusId = 4;
         public int AssignedRoleId = 5;
         public int AssignedActionId = 6;
         public int Remarks = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateROUModuleApplicationByAdmin
      public class SpUpdateROUModuleApplicationByAdmin
      {
         public string SPName = "SpUpdateROUModuleApplicationByAdmin";
         public int Mode = 0;
         public int UserId = 1;
         public int NewAssignedActionId = 2;
         public int ApplicationFormId = 3;
         public int DARoutePlanOkorNotOk = 4;
         public int DARoutePlanRemarks = 5;
         public int DAApprovalLetterOkorNotOk = 6;
         public int DAApprovalLetterRemarks = 7;
         public int ActionId = 8;
         public int ConcludingRemarks = 9;
         public int AssignedRoleId = 10;
         public int Query = 11;
         public int DepthbyAdmin = 12;
         public int LenghtbyAdmin = 13;
         public int TotalROUbyAdmin = 14;
         public int RoadCuttingCharge = 15;
         public int MaintenanceDepositCharge = 16;
         public int OtherCharges = 17;
         public int TotalCharges = 18;
         public int IsProposalViable = 19;
         public int LayingLine = 20;
         public int AMRoutePlanOkorNotOk = 21;
         public int AMRoutePlanRemarks = 22;
         public int AMApprovalLetterOkorNotOk = 23;
         public int AMApprovalLetterRemarks = 24;
         public int RMRoutePlanOkorNotOk = 25;
         public int RMRoutePlanRemarks = 26;
         public int RMApprovalLetterOkorNotOk = 27;
         public int RMApprovalLetterRemarks = 28;
         public int DMRoutePlanOkorNotOk = 29;
         public int DMRoutePlanRemarks = 30;
         public int DMApprovalLetterOkorNotOk = 31;
         public int DMApprovalLetterRemarks = 32;
         public int RouChargeforLineType = 33;
         public int IsApproved = 34;
         public int RejectReason = 35;
         public int ROUChargesFees = 36;
         public int ROUChargesfeesSGST = 37;
         public int ROUChargesfeesCGST = 38;
         public int TotalRouCharges = 39;
         public int OtherChargesFees = 40;
         public int RoadCuttingSGST = 41;
         public int RoadCuttingCGST = 42;
         public int TotalOtherCharges = 43;
         public int TotalPaybleAmount = 44;
         public int ROUCharge_ACCHEAD_C = 45;
         public int ROUCharge_ACC_M = 46;
         public int ROUCharge_FROM_D = 47;
         public int ROUCharge_TO_D = 48;
         public int ROUCharge_ACC_NO = 49;
         public int ROUCharge_SGST_A = 50;
         public int ROUCharge_CGST_A = 51;
         public int ROUCharge_ACC_N = 52;
         public int RoadCutting_ACCHEAD_C = 53;
         public int RoadCutting_ACC_M = 54;
         public int RoadCutting_FROM_D = 55;
         public int RoadCutting_TO_D = 56;
         public int RoadCutting_SGST_A = 57;
         public int RoadCutting_CGST_A = 58;
         public int ROUArea = 59;
         public int WaterSupplyLineDeposit = 60;
         public int DrainageLineDeposit = 61;
         public int TreePlantationDeposit = 62;
         public int StormWaterDrainageLineDeposit = 63;
         public int DocProvisionalOrder = 64;
         public int IsAgreeWithROUCharges = 65;
         public int PercentageForROUCharges = 66;
         public int YearForROUCharges = 67;
         public int ReasonforChangeROUCharge = 68;
         public int RoadCuttingDeposit = 69;
         public int IndustrialPrice = 70;
         public int Route = 71;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDMBackwardToRMLeaseDocumentWithRemarks
      public class SPDMBackwardToRMLeaseDocumentWithRemarks
      {
         public string SPName = "SPDMBackwardToRMLeaseDocumentWithRemarks";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
         public int BackwardRemark = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubDivisionModuleForReferenceNo
      public class SPSelectSubDivisionModuleForReferenceNo
      {
         public string SPName = "SPSelectSubDivisionModuleForReferenceNo";
         public int EstateId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPCheckGSTIsTakenORNot
      public class SPCheckGSTIsTakenORNot
      {
         public string SPName = "SPCheckGSTIsTakenORNot";
         public int Applicationformid = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetTransferModulePendingWithApplicant
      public class SPGetTransferModulePendingWithApplicant
      {
         public string SPName = "SPGetTransferModulePendingWithApplicant";
         public int RegionId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDEEPhotoDetailByApplicationFormId
      public class SPSelectDEEPhotoDetailByApplicationFormId
      {
         public string SPName = "SPSelectDEEPhotoDetailByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPTransferModuleInsertDDPTOPayment
      public class SPTransferModuleInsertDDPTOPayment
      {
         public string SPName = "SPTransferModuleInsertDDPTOPayment";
         public int ApplicationFormId = 0;
         public int BankName = 1;
         public int BranchName = 2;
         public int AmountPaid = 3;
         public int DDReceiptNo = 4;
         public int DDReceiptDate = 5;
         public int DDReceiptDoc = 6;
         public int CreatedBy = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateInspectionStatusByInspectionId
      public class SPUpdateInspectionStatusByInspectionId
      {
         public string SPName = "SPUpdateInspectionStatusByInspectionId";
         public int InspectionId = 0;
         public int StatusId = 1;
         public int Remarks = 2;
         public int UserId = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpTwoRApplicationRemarksHistory
      public class SpTwoRApplicationRemarksHistory
      {
         public string SPName = "SpTwoRApplicationRemarksHistory";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertCRDailyApplicationDetailsForROU
      public class SPInsertCRDailyApplicationDetailsForROU
      {
         public string SPName = "SPInsertCRDailyApplicationDetailsForROU";
         public int ApplicationId = 0;
         public int ApplicationFormId = 1;
         public int AppForwardDate = 2;
         public int AppActualForwardDate = 3;
         public int ActionId = 4;
         public int AssignRoleId = 5;
         public int EstateId = 6;
         public int Remark = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectEstatePriceForSublettingByApplicationFormId
      public class SPSelectEstatePriceForSublettingByApplicationFormId
      {
         public string SPName = "SPSelectEstatePriceForSublettingByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDMForwardToHelpdeskQueryApplication
      public class SPDMForwardToHelpdeskQueryApplication
      {
         public string SPName = "SPDMForwardToHelpdeskQueryApplication";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
         public int BackwardRemark = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateForwardDate
      public class SPUpdateForwardDate
      {
         public string SPName = "SPUpdateForwardDate";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
         public int flag = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetTransferModuleRejected
      public class SPGetTransferModuleRejected
      {
         public string SPName = "SPGetTransferModuleRejected";
         public int RegionId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectUTransferoreeDetailByApplicationFormId
      public class SPSelectUTransferoreeDetailByApplicationFormId
      {
         public string SPName = "SPSelectUTransferoreeDetailByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPTransferModuleUpdateDDPTOPayment
      public class SPTransferModuleUpdateDDPTOPayment
      {
         public string SPName = "SPTransferModuleUpdateDDPTOPayment";
         public int DDPaymentId = 0;
         public int BankName = 1;
         public int BranchName = 2;
         public int AmountPaid = 3;
         public int DDReceiptNo = 4;
         public int DDReceiptDate = 5;
         public int DDReceiptDoc = 6;
         public int ModifiedBy = 7;
         public int mode = 8;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTwoRApplicationListDetails
      public class SPSelectTwoRApplicationListDetails
      {
         public string SPName = "SPSelectTwoRApplicationListDetails";
         public int AssignedRoleId = 0;
         public int SearchValue = 1;
         public int SearchId = 2;
         public int RegionId = 3;
         public int UserId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertGrievanceApplication
      public class SPInsertGrievanceApplication
      {
         public string SPName = "SPInsertGrievanceApplication";
         public int GrievanceNumber = 0;
         public int GrievanceStatusId = 1;
         public int AssignedRoleId = 2;
         public int GrievanceLanguage = 3;
         public int CommunicationAddress = 4;
         public int GrievanceSubjectId = 5;
         public int GrievanceDiscription = 6;
         public int GrievanceDocPath = 7;
         public int IsParticularEstate = 8;
         public int EstateId = 9;
         public int PropertyTypeId = 10;
         public int PlotShedNo = 11;
         public int CreatedBy = 12;
         public int IsActive = 13;
         public int GrievanceApplicantName = 14;
         public int ApplicantContactNo = 15;
         public int ApplicantMobileNo = 16;
         public int ApplicantEmailId = 17;
         public int ApplicantPincode = 18;
         public int LandMark = 19;
         public int City = 20;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectWaterDrainagePlanApprovalApplicationForSiteInvestigation
      public class SPSelectWaterDrainagePlanApprovalApplicationForSiteInvestigation
      {
         public string SPName = "SPSelectWaterDrainagePlanApprovalApplicationForSiteInvestigation";
         public int AssignedRoleId = 0;
         public int SearchValue = 1;
         public int SearchId = 2;
         public int RegionId = 3;
         public int UserId = 4;
         public int ApplicationType = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpFindRollByuseridforSubdivision
      public class SpFindRollByuseridforSubdivision
      {
         public string SPName = "SpFindRollByuseridforSubdivision";
         public int ApplicationTypeId = 0;
         public int Branchid = 1;
         public int UserId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDMOnHoldApplication
      public class SPDMOnHoldApplication
      {
         public string SPName = "SPDMOnHoldApplication";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
         public int BackwardRemark = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateAmalgamationPlotDues
      public class SPUpdateAmalgamationPlotDues
      {
         public string SPName = "SPUpdateAmalgamationPlotDues";
         public int Id = 0;
         public int ApplicationFormId = 1;
         public int OSINST_A = 2;
         public int OSIDPPI_A = 3;
         public int OSSC_A = 4;
         public int OSSC_ST = 5;
         public int OSSC_EC = 6;
         public int OSSWCSC = 7;
         public int OSSCKKC = 8;
         public int OSNAA_A = 9;
         public int OSNAA_ST = 10;
         public int OSNAA_EC = 11;
         public int OSSWCNAA = 12;
         public int OSNAAKKC = 13;
         public int OSLR_A = 14;
         public int OSLR_ST = 15;
         public int OSLR_EC = 16;
         public int OSSWCLR = 17;
         public int OSLRKKC = 18;
         public int OSIR_A = 19;
         public int OSIUF_A = 20;
         public int OSIUF_ST = 21;
         public int OSIUF_EC = 22;
         public int OSFULLPAYMENT_A = 23;
         public int LRCOSINST_A = 24;
         public int LRCOSIDP_A = 25;
         public int ACC_DUES = 26;
         public int WATER_DUES = 27;
         public int DRAINAGE_DUES = 28;
         public int Other_DUES = 29;
         public int AccountNDC = 30;
         public int EngineeringNDC = 31;
         public int AC_ACCHEAD_C = 32;
         public int AC_ACC_M = 33;
         public int AC_FROM_D = 34;
         public int AC_TO_D = 35;
         public int AC_ACC_NO = 36;
         public int AC_SGST_A = 37;
         public int AC_CGST_A = 38;
         public int AC_ACC_N = 39;
         public int AC_SGSTAmount = 40;
         public int AC_CGSTAmount = 41;
         public int EN_ACCHEAD_C = 42;
         public int EN_ACC_M = 43;
         public int EN_FROM_D = 44;
         public int EN_TO_D = 45;
         public int EN_ACC_NO = 46;
         public int EN_SGST_A = 47;
         public int EN_CGST_A = 48;
         public int EN_ACC_N = 49;
         public int EN_SGSTAmount = 50;
         public int EN_CGSTAmount = 51;
         public int SC_ACCHEAD_C = 52;
         public int SC_ACC_M = 53;
         public int SC_FROM_D = 54;
         public int SC_TO_D = 55;
         public int SC_ACC_NO = 56;
         public int SC_SGST_A = 57;
         public int SC_CGST_A = 58;
         public int SC_ACC_N = 59;
         public int SC_SGSTAmount = 60;
         public int SC_CGSTAmount = 61;
         public int SC_BaseAmount = 62;
         public int NAA_ACCHEAD_C = 63;
         public int NAA_ACC_M = 64;
         public int NAA_FROM_D = 65;
         public int NAA_TO_D = 66;
         public int NAA_ACC_NO = 67;
         public int NAA_SGST_A = 68;
         public int NAA_CGST_A = 69;
         public int NAA_ACC_N = 70;
         public int NAA_SGSTAmount = 71;
         public int NAA_CGSTAmount = 72;
         public int NAA_BaseAmount = 73;
         public int LR_ACCHEAD_C = 74;
         public int LR_ACC_M = 75;
         public int LR_FROM_D = 76;
         public int LR_TO_D = 77;
         public int LR_ACC_NO = 78;
         public int LR_SGST_A = 79;
         public int LR_CGST_A = 80;
         public int LR_ACC_N = 81;
         public int LR_SGSTAmount = 82;
         public int LR_CGSTAmount = 83;
         public int LR_BaseAmount = 84;
         public int INT_ACCHEAD_C = 85;
         public int INT_ACC_M = 86;
         public int INT_FROM_D = 87;
         public int INT_TO_D = 88;
         public int INT_ACC_NO = 89;
         public int INT_SGST_A = 90;
         public int INT_CGST_A = 91;
         public int INT_ACC_N = 92;
         public int INT_SGSTAmount = 93;
         public int INT_CGSTAmount = 94;
         public int INT_BaseAmount = 95;
         public int SC_OS_CGST = 96;
         public int SC_OS_SGST = 97;
         public int NAA_OS_CGST = 98;
         public int NAA_OS_SGST = 99;
         public int LR_OS_CGST = 100;
         public int LR_OS_SGST = 101;
         public int INTREV_OS_CGST = 102;
         public int INTREV_OS_SGST = 103;
         public int REVINT_CSGST_OS = 104;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPAMForwardToRMTwoRApplication
      public class SPAMForwardToRMTwoRApplication
      {
         public string SPName = "SPAMForwardToRMTwoRApplication";
         public int ApplicationFormId = 0;
         public int AssignedRoleId = 1;
         public int ModifiedBy = 2;
         public int BackwardRemark = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferModuleByApplicationFormId08112016
      public class SPSelectTransferModuleByApplicationFormId08112016
      {
         public string SPName = "SPSelectTransferModuleByApplicationFormId08112016";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferModuleDDPaymentForPTOByApplicationFormId
      public class SPSelectTransferModuleDDPaymentForPTOByApplicationFormId
      {
         public string SPName = "SPSelectTransferModuleDDPaymentForPTOByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateConstitutionTypeMaster
      public class SPInsertUpdateConstitutionTypeMaster
      {
         public string SPName = "SPInsertUpdateConstitutionTypeMaster";
         public int ConstitutionTypeId = 0;
         public int ConstitutionType = 1;
         public int UserId = 2;
         public int IsActive = 3;
         public int Operation = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPRMForwardToXENGrievanceApplication
      public class SPRMForwardToXENGrievanceApplication
      {
         public string SPName = "SPRMForwardToXENGrievanceApplication";
         public int GrievanceApplicationId = 0;
         public int Remarks = 1;
         public int ModifiedBy = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDistrictMasterByDistrict
      public class SPSelectDistrictMasterByDistrict
      {
         public string SPName = "SPSelectDistrictMasterByDistrict";
         public int District = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpInspectorUploadDrainageSiteInspectionReport
      public class SpInspectorUploadDrainageSiteInspectionReport
      {
         public string SPName = "SpInspectorUploadDrainageSiteInspectionReport";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int SiteInspectionReportAttachment = 2;
         public int InspectionRemarks = 3;
         public int SitePhotographAttachment = 4;
         public int InspectorAttachments = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPFillAMDocpathLease
      public class SPFillAMDocpathLease
      {
         public string SPName = "SPFillAMDocpathLease";
         public int ApplicationFormId = 0;
         public int AMDocCoverLatter = 1;
         public int AODocPath = 2;
         public int DEEDocPath = 3;
         public int AMAnnexure = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferModuleQueryDocuments
      public class SPSelectTransferModuleQueryDocuments
      {
         public string SPName = "SPSelectTransferModuleQueryDocuments";
         public int AplicationFormId = 0;
         public int AssignedRoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertTransactionReferenceNoPaymentDetailsSublettingPO
      public class SPInsertTransactionReferenceNoPaymentDetailsSublettingPO
      {
         public string SPName = "SPInsertTransactionReferenceNoPaymentDetailsSublettingPO";
         public int TxId = 0;
         public int ApplicationFormId = 1;
         public int POPayment = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateSubdivisionModuleApplicationInManagerHOLoop
      public class SpUpdateSubdivisionModuleApplicationInManagerHOLoop
      {
         public string SPName = "SpUpdateSubdivisionModuleApplicationInManagerHOLoop";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int NewAssinedActionId = 2;
         public int AssignedRoleId = 3;
         public int DepartmentId = 4;
         public int Remarks = 5;
         public int HOAdditionalDocs = 6;
         public int BranchUserId = 7;
         public int CurrentBranchId = 8;
         public int IsIncorporateDDPlan = 9;
         public int DateofIncorporate = 10;
         public int DDPlanSATP = 11;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteConstitutionTypeMasterByConstitutionTypeId
      public class SPDeleteConstitutionTypeMasterByConstitutionTypeId
      {
         public string SPName = "SPDeleteConstitutionTypeMasterByConstitutionTypeId";
         public int ConstitutionTypeId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectApplicantTwoRApplicationDocumentList01092016
      public class SPSelectApplicantTwoRApplicationDocumentList01092016
      {
         public string SPName = "SPSelectApplicantTwoRApplicationDocumentList01092016";
         public int DocumentList = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectGrievanceApplicationCountForDepartment
      public class SPSelectGrievanceApplicationCountForDepartment
      {
         public string SPName = "SPSelectGrievanceApplicationCountForDepartment";
         public int FromDate = 0;
         public int ToDate = 1;
         public int DeptName = 2;
         public int SubjectId = 3;
         public int Day = 4;
         public int RegionId = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSurrenderDocumentTransactionByApplicationId
      public class SPSelectSurrenderDocumentTransactionByApplicationId
      {
         public string SPName = "SPSelectSurrenderDocumentTransactionByApplicationId";
         public int AplicationFormId = 0;
         public int ConstituteTypeTransferor = 1;
         public int ActionID = 2;
         public int IsTwoRPermissionTaken = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDistrictMasterByDistrictId
      public class SPSelectDistrictMasterByDistrictId
      {
         public string SPName = "SPSelectDistrictMasterByDistrictId";
         public int DistrictId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpInspectorUploadWaterSupplySiteInspectionReport
      public class SpInspectorUploadWaterSupplySiteInspectionReport
      {
         public string SPName = "SpInspectorUploadWaterSupplySiteInspectionReport";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int SiteInspectionReportAttachment = 2;
         public int InspectionRemarks = 3;
         public int SitePhotographAttachment = 4;
         public int InspectorAttachments = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTWoRPlotDetailsForPayment
      public class SPSelectTWoRPlotDetailsForPayment
      {
         public string SPName = "SPSelectTWoRPlotDetailsForPayment";
         public int ApplicationFormId = 0;
         public int EstateId = 1;
         public int PlotTypeId = 2;
         public int PlotShedNumber = 3;
         public int RegionId = 4;
         public int PartyCode = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectAmalgamationModuleHOFlowUserByBranchAndRole
      public class SPSelectAmalgamationModuleHOFlowUserByBranchAndRole
      {
         public string SPName = "SPSelectAmalgamationModuleHOFlowUserByBranchAndRole";
         public int BranchId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetDocPathForMailAttachments
      public class SPGetDocPathForMailAttachments
      {
         public string SPName = "SPGetDocPathForMailAttachments";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSubdivisionModuleInsertFSOCondition
      public class SPSubdivisionModuleInsertFSOCondition
      {
         public string SPName = "SPSubdivisionModuleInsertFSOCondition";
         public int ApplicationFormId = 0;
         public int FSOCondition = 1;
         public int CreatedBy = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpViewAmalgamatedPlotDuesDetails
      public class SpViewAmalgamatedPlotDuesDetails
      {
         public string SPName = "SpViewAmalgamatedPlotDuesDetails";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateRemarksTwoRApplication
      public class SPUpdateRemarksTwoRApplication
      {
         public string SPName = "SPUpdateRemarksTwoRApplication";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
         public int Remarks = 2;
         public int ModifiedBy = 3;
         public int ApplicationId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateTrasferModuleApplicationByAdmin24102016
      public class SpUpdateTrasferModuleApplicationByAdmin24102016
      {
         public string SPName = "SpUpdateTrasferModuleApplicationByAdmin24102016";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int CurrentApplicationActionId = 2;
         public int NewAssinedActionId = 3;
         public int DocumentXML = 4;
         public int Remarks = 5;
         public int StrDocument = 6;
         public int StrDocument1 = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateSublettingPaymentPO
      public class SPUpdateSublettingPaymentPO
      {
         public string SPName = "SPUpdateSublettingPaymentPO";
         public int ApplicationFormid = 0;
         public int ModifiedBy = 1;
         public int PSOPaymentDocument = 2;
         public int Remarks = 3;
         public int NDCAccount = 4;
         public int NDCEngineering = 5;
         public int FSOOutwardNo = 6;
         public int FSODate = 7;
         public int FSODocument = 8;
         public int PSOOutwardNo = 9;
         public int PSODate = 10;
         public int PSODocument = 11;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpROUModuleConcludingRemarksHistoryForReport
      public class SpROUModuleConcludingRemarksHistoryForReport
      {
         public string SPName = "SpROUModuleConcludingRemarksHistoryForReport";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPROUApplicationDetailsReportFooterTemp
      public class SPROUApplicationDetailsReportFooterTemp
      {
         public string SPName = "SPROUApplicationDetailsReportFooterTemp";
         public int ACTIONID = 0;
         public int ActionType = 1;
         public int BeforeAfter = 2;
         public int OldApplicationStatusId = 3;
         public int PTOIssueCMD = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectOfficeUserMasterForForgetPassword
      public class SPSelectOfficeUserMasterForForgetPassword
      {
         public string SPName = "SPSelectOfficeUserMasterForForgetPassword";
         public int EmailId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateTwoRApplicationOutwardByAdmin
      public class SpUpdateTwoRApplicationOutwardByAdmin
      {
         public string SPName = "SpUpdateTwoRApplicationOutwardByAdmin";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int CurrentApplicationActionId = 2;
         public int Remarks = 3;
         public int SurveyNo = 4;
         public int Manufacturing = 5;
         public int PermissionletterNumber = 6;
         public int PermissionletterDate = 7;
         public int PermissionAmount = 8;
         public int PermissionFinancialInstitutions = 9;
         public int FinancialInstitutionsXML = 10;
         public int letterNo = 11;
         public int LetterDate = 12;
         public int NewActionId = 13;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectGrievanceApplicationByGrievanceApplicationId
      public class SPSelectGrievanceApplicationByGrievanceApplicationId
      {
         public string SPName = "SPSelectGrievanceApplicationByGrievanceApplicationId";
         public int GrievanceApplicationId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPCheckUniqueReferenceNoForSurrender
      public class SPCheckUniqueReferenceNoForSurrender
      {
         public string SPName = "SPCheckUniqueReferenceNoForSurrender";
         public int ReferenceNo = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateAmalgamationModuleApplicationInManagerHOLoop
      public class SpUpdateAmalgamationModuleApplicationInManagerHOLoop
      {
         public string SPName = "SpUpdateAmalgamationModuleApplicationInManagerHOLoop";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int NewAssinedActionId = 2;
         public int AssignedRoleId = 3;
         public int DepartmentId = 4;
         public int Remarks = 5;
         public int HOAdditionalDocs = 6;
         public int BranchUserId = 7;
         public int CurrentBranchId = 8;
         public int IsIncorporateDDPlan = 9;
         public int DateofIncorporate = 10;
         public int DDPlanSATP = 11;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPHelpdeskForwardToAMLeaseApplicationQuery
      public class SPHelpdeskForwardToAMLeaseApplicationQuery
      {
         public string SPName = "SPHelpdeskForwardToAMLeaseApplicationQuery";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
         public int BackwardRemark = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetPendingDayFromLastActionAtGIDCendFor2R07062017
      public class SPGetPendingDayFromLastActionAtGIDCendFor2R07062017
      {
         public string SPName = "SPGetPendingDayFromLastActionAtGIDCendFor2R07062017";
         public int ApplicationFormId = 0;
         public int Days = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertOraclePartyCode
      public class SPInsertOraclePartyCode
      {
         public string SPName = "SPInsertOraclePartyCode";
         public int OraPlotShedNo = 0;
         public int OraPlotType = 1;
         public int OraPlotCode = 2;
         public int OraPlotArea = 3;
         public int OraEsateName = 4;
         public int OraEstateCode = 5;
         public int OraPartyName = 6;
         public int OraRegionName = 7;
         public int OraRegionCode = 8;
         public int OraPartyCode = 9;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubdivisionModuleFSOConditionsByApplicationFormId
      public class SPSelectSubdivisionModuleFSOConditionsByApplicationFormId
      {
         public string SPName = "SPSelectSubdivisionModuleFSOConditionsByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPlotShedByPlotShedNoamalgmation
      public class SPSelectPlotShedByPlotShedNoamalgmation
      {
         public string SPName = "SPSelectPlotShedByPlotShedNoamalgmation";
         public int PlotShedNo = 0;
         public int EstateId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateTransfer22102016
      public class SPUpdateTransfer22102016
      {
         public string SPName = "SPUpdateTransfer22102016";
         public int ApplicationFormId = 0;
         public int ApplicantName = 1;
         public int ApplicantAddress = 2;
         public int RegionId = 3;
         public int EstateId = 4;
         public int TypeOfPlotShed = 5;
         public int PlotShedNo = 6;
         public int PlotArea = 7;
         public int NameofIndividualTransferor = 8;
         public int CinTransferor = 9;
         public int AuthorisedPersonTransferor = 10;
         public int ContactNoTransferor = 11;
         public int EmailIdTransferor = 12;
         public int NameofIndividualTransferee = 13;
         public int CinTransferee = 14;
         public int AuthorisedPersonTransferee = 15;
         public int ContactNoTransferee = 16;
         public int EmailIdTransferee = 17;
         public int NameofAllottee = 18;
         public int AddressofAllottee = 19;
         public int DateofAllotment = 20;
         public int DateofAgreement = 21;
         public int DateofPossession = 22;
         public int DateofLeaseDeed = 23;
         public int DateofCorrigendum = 24;
         public int NameofTrasferee = 25;
         public int AddressofTrasferee = 26;
         public int NameofProduct = 27;
         public int NameofRawMaterials = 28;
         public int RequirementofRawMaterialsperMonth = 29;
         public int ProductioninMonth = 30;
         public int WaterRequirement1stYear = 31;
         public int WaterRequirement2ndYear = 32;
         public int WaterRequirement3rdYear = 33;
         public int WaterRequirement4thYear = 34;
         public int PowerRequirement1stYear = 35;
         public int PowerRequirement2ndYear = 36;
         public int PowerRequirement3rdYear = 37;
         public int PowerRequirement4thYear = 38;
         public int TotalInvestmentInyourProject = 39;
         public int NoofManPowerRequired = 40;
         public int FormalTrasferOrInFormalTrasfer = 41;
         public int ModifiedBy = 42;
         public int IsSubmitted = 43;
         public int DocumentXML = 44;
         public int tblTransferor = 45;
         public int tblTransferee = 46;
         public int ConstitutionTypeId = 47;
         public int DeathCaseTransfer = 48;
         public int DeathWillType = 49;
         public int DeathCaseTransferWill = 50;
         public int NOC2RPermissionTaken = 51;
         public int NOCAttachment = 52;
         public int TrasferGSFC = 53;
         public int TrasferCoOperative = 54;
         public int FTOName = 55;
         public int FTOFile = 56;
         public int ConstitutionTypeIdTransferee = 57;
         public int UndertakingTransfer = 58;
         public int UndertakingTransferee = 59;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertGrievanceAdminDocument
      public class SPInsertGrievanceAdminDocument
      {
         public string SPName = "SPInsertGrievanceAdminDocument";
         public int GrievanceApplicationId = 0;
         public int DocumentDiscription = 1;
         public int DocumentPath = 2;
         public int UserId = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteTwoRTransactionForSameUnitByApplicationFormId01092016
      public class SPDeleteTwoRTransactionForSameUnitByApplicationFormId01092016
      {
         public string SPName = "SPDeleteTwoRTransactionForSameUnitByApplicationFormId01092016";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectGrievanceApplicationListByUserId
      public class SPSelectGrievanceApplicationListByUserId
      {
         public string SPName = "SPSelectGrievanceApplicationListByUserId";
         public int UserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPHelpDeskForwardToDALeaseApplication
      public class SPHelpDeskForwardToDALeaseApplication
      {
         public string SPName = "SPHelpDeskForwardToDALeaseApplication";
         public int ApplicationFormId = 0;
         public int AssignedRoleId = 1;
         public int ModifiedBy = 2;
         public int StatusId = 3;
         public int BackwardRemark = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPTWORAPPLICATIONDETAILSREPORTFOOTER07062017
      public class SPTWORAPPLICATIONDETAILSREPORTFOOTER07062017
      {
         public string SPName = "SPTWORAPPLICATIONDETAILSREPORTFOOTER07062017";
         public int ACTIONID = 0;
         public int ActionType = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateBuildingPlanGSTAmountForOldApplication
      public class SPUpdateBuildingPlanGSTAmountForOldApplication
      {
         public string SPName = "SPUpdateBuildingPlanGSTAmountForOldApplication";
         public int ApplicationFormId = 0;
         public int SCRUTINYFEE = 1;
         public int PENALTYFORNONVIOLATIVE = 2;
         public int PENALTYFORVIOLATIVE = 3;
         public int LABOURCESS = 4;
         public int TREEPLANTATION = 5;
         public int PLANAPPROVALFEE = 6;
         public int SERVICETAX = 7;
         public int SWATCHBHARATCESS = 8;
         public int KRISHIKALYANCESS = 9;
         public int IMPACTFEE = 10;
         public int FSIVIOLATION = 11;
         public int DRAINAGECESS = 12;
         public int PARKINGDEFICITPENALTY = 13;
         public int SANITATIONDEFICITPENALTY = 14;
         public int SERVICEAMENITIES = 15;
         public int SCRUTINYFEE_SGST = 16;
         public int SCRUTINYFEE_CGST = 17;
         public int SCRUTINYFEE_ACCHEAD_C = 18;
         public int SCRUTINYFEE_ACC_M = 19;
         public int SCRUTINYFEE_FROM_D = 20;
         public int SCRUTINYFEE_TO_D = 21;
         public int SCRUTINYFEE_SGST_A = 22;
         public int SCRUTINYFEE_CGST_A = 23;
         public int PENALTYFORNONVIOLATIVE_SGST = 24;
         public int PENALTYFORNONVIOLATIVE_CGST = 25;
         public int PENALTYFORNONVIOLATIVE_ACCHEAD_C = 26;
         public int PENALTYFORNONVIOLATIVE_ACC_M = 27;
         public int PENALTYFORNONVIOLATIVE_FROM_D = 28;
         public int PENALTYFORNONVIOLATIVE_TO_D = 29;
         public int PENALTYFORNONVIOLATIVE_SGST_A = 30;
         public int PENALTYFORNONVIOLATIVE_CGST_A = 31;
         public int PENALTYFORVIOLATIVE_SGST = 32;
         public int PENALTYFORVIOLATIVE_CGST = 33;
         public int PENALTYFORVIOLATIVE_ACCHEAD_C = 34;
         public int PENALTYFORVIOLATIVE_ACC_M = 35;
         public int PENALTYFORVIOLATIVE_FROM_D = 36;
         public int PENALTYFORVIOLATIVE_TO_D = 37;
         public int PENALTYFORVIOLATIVE_SGST_A = 38;
         public int PENALTYFORVIOLATIVE_CGST_A = 39;
         public int LABOURCESS_SGST = 40;
         public int LABOURCESS_CGST = 41;
         public int LABOURCESS_ACCHEAD_C = 42;
         public int LABOURCESS_ACC_M = 43;
         public int LABOURCESS_FROM_D = 44;
         public int LABOURCESS_TO_D = 45;
         public int LABOURCESS_SGST_A = 46;
         public int LABOURCESS_CGST_A = 47;
         public int TREEPLANTATION_SGST = 48;
         public int TREEPLANTATION_CGST = 49;
         public int TREEPLANTATION_ACCHEAD_C = 50;
         public int TREEPLANTATION_ACC_M = 51;
         public int TREEPLANTATION_FROM_D = 52;
         public int TREEPLANTATION_TO_D = 53;
         public int TREEPLANTATION_SGST_A = 54;
         public int TREEPLANTATION_CGST_A = 55;
         public int PLANAPPROVALFEE_SGST = 56;
         public int PLANAPPROVALFEE_CGST = 57;
         public int PLANAPPROVALFEE_ACCHEAD_C = 58;
         public int PLANAPPROVALFEE_ACC_M = 59;
         public int PLANAPPROVALFEE_FROM_D = 60;
         public int PLANAPPROVALFEE_TO_D = 61;
         public int PLANAPPROVALFEE_SGST_A = 62;
         public int PLANAPPROVALFEE_CGST_A = 63;
         public int IMPACTFEE_SGST = 64;
         public int IMPACTFEE_CGST = 65;
         public int IMPACTFEE_ACCHEAD_C = 66;
         public int IMPACTFEE_ACC_M = 67;
         public int IMPACTFEE_FROM_D = 68;
         public int IMPACTFEE_TO_D = 69;
         public int IMPACTFEE_SGST_A = 70;
         public int IMPACTFEE_CGST_A = 71;
         public int FSIVIOLATION_SGST = 72;
         public int FSIVIOLATION_CGST = 73;
         public int FSIVIOLATION_ACCHEAD_C = 74;
         public int FSIVIOLATION_ACC_M = 75;
         public int FSIVIOLATION_FROM_D = 76;
         public int FSIVIOLATION_TO_D = 77;
         public int FSIVIOLATION_SGST_A = 78;
         public int FSIVIOLATION_CGST_A = 79;
         public int DRAINAGECESS_SGST = 80;
         public int DRAINAGECESS_CGST = 81;
         public int DRAINAGECESS_ACCHEAD_C = 82;
         public int DRAINAGECESS_ACC_M = 83;
         public int DRAINAGECESS_FROM_D = 84;
         public int DRAINAGECESS_TO_D = 85;
         public int DRAINAGECESS_SGST_A = 86;
         public int DRAINAGECESS_CGST_A = 87;
         public int SANITATIONDEFICITPENALTY_SGST = 88;
         public int SANITATIONDEFICITPENALTY_CGST = 89;
         public int SANITATIONDEFICITPENALTY_ACCHEAD_C = 90;
         public int SANITATIONDEFICITPENALTY_ACC_M = 91;
         public int SANITATIONDEFICITPENALTY_FROM_D = 92;
         public int SANITATIONDEFICITPENALTY_TO_D = 93;
         public int SANITATIONDEFICITPENALTY_SGST_A = 94;
         public int SANITATIONDEFICITPENALTY_CGST_A = 95;
         public int PARKINGDEFICITPENALTY_SGST = 96;
         public int PARKINGDEFICITPENALTY_CGST = 97;
         public int PARKINGDEFICITPENALTY_ACCHEAD_C = 98;
         public int PARKINGDEFICITPENALTY_ACC_M = 99;
         public int PARKINGDEFICITPENALTY_FROM_D = 100;
         public int PARKINGDEFICITPENALTY_TO_D = 101;
         public int PARKINGDEFICITPENALTY_SGST_A = 102;
         public int PARKINGDEFICITPENALTY_CGST_A = 103;
         public int SERVICEAMENITIES_SGST = 104;
         public int SERVICEAMENITIES_CGST = 105;
         public int SERVICEAMENITIES_ACCHEAD_C = 106;
         public int SERVICEAMENITIES_ACC_M = 107;
         public int SERVICEAMENITIES_FROM_D = 108;
         public int SERVICEAMENITIES_TO_D = 109;
         public int SERVICEAMENITIES_SGST_A = 110;
         public int SERVICEAMENITIES_CGST_A = 111;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubLettingModuleApplicationListDetails
      public class SPSelectSubLettingModuleApplicationListDetails
      {
         public string SPName = "SPSelectSubLettingModuleApplicationListDetails";
         public int AssignedRoleId = 0;
         public int SearchValue = 1;
         public int SearchId = 2;
         public int RegionId = 3;
         public int UserId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectAmalgamatedPlotDuesRecieptDetails
      public class SPSelectAmalgamatedPlotDuesRecieptDetails
      {
         public string SPName = "SPSelectAmalgamatedPlotDuesRecieptDetails";
         public int ApplicationFormId = 0;
         public int AmalgamatedPlotId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertTransferModule25092016
      public class SPInsertTransferModule25092016
      {
         public string SPName = "SPInsertTransferModule25092016";
         public int ReferenceNo = 0;
         public int ApplicantName = 1;
         public int ApplicantAddress = 2;
         public int RegionId = 3;
         public int EstateId = 4;
         public int TypeOfPlotShed = 5;
         public int PlotShedNo = 6;
         public int PlotArea = 7;
         public int NameofIndividualTransferor = 8;
         public int CinTransferor = 9;
         public int AuthorisedPersonTransferor = 10;
         public int ContactNoTransferor = 11;
         public int EmailIdTransferor = 12;
         public int NameofIndividualTransferee = 13;
         public int CinTransferee = 14;
         public int AuthorisedPersonTransferee = 15;
         public int ContactNoTransferee = 16;
         public int EmailIdTransferee = 17;
         public int NameofAllottee = 18;
         public int AddressofAllottee = 19;
         public int DateofAllotment = 20;
         public int DateofAgreement = 21;
         public int DateofPossession = 22;
         public int DateofLeaseDeed = 23;
         public int DateofCorrigendum = 24;
         public int NameofTrasferee = 25;
         public int AddressofTrasferee = 26;
         public int NameofProduct = 27;
         public int NameofRawMaterials = 28;
         public int RequirementofRawMaterialsperMonth = 29;
         public int ProductioninMonth = 30;
         public int WaterRequirement1stYear = 31;
         public int WaterRequirement2ndYear = 32;
         public int WaterRequirement3rdYear = 33;
         public int WaterRequirement4thYear = 34;
         public int PowerRequirement1stYear = 35;
         public int PowerRequirement2ndYear = 36;
         public int PowerRequirement3rdYear = 37;
         public int PowerRequirement4thYear = 38;
         public int TotalInvestmentInyourProject = 39;
         public int NoofManPowerRequired = 40;
         public int FormalTrasferOrInFormalTrasfer = 41;
         public int CreatedBy = 42;
         public int IsSubmitted = 43;
         public int DocumentXML = 44;
         public int tblTransferor = 45;
         public int tblTransferee = 46;
         public int ConstitutionTypeId = 47;
         public int DeathCaseTransfer = 48;
         public int DeathWillType = 49;
         public int DeathCaseTransferWill = 50;
         public int NOC2RPermissionTaken = 51;
         public int NOCAttachment = 52;
         public int TrasferGSFC = 53;
         public int TrasferCoOperative = 54;
         public int FTOName = 55;
         public int FTOFile = 56;
         public int ConstitutionTypeIdTransferee = 57;
         public int UndertakingTransfer = 58;
         public int UndertakingTransferee = 59;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPaymentDetailsSublettingForTxId
      public class SPSelectPaymentDetailsSublettingForTxId
      {
         public string SPName = "SPSelectPaymentDetailsSublettingForTxId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateTransferModuleApplicantApplicationFileName
      public class SPUpdateTransferModuleApplicantApplicationFileName
      {
         public string SPName = "SPUpdateTransferModuleApplicantApplicationFileName";
         public int ApplicationFormId = 0;
         public int ApplicantApplicationFileName = 1;
         public int IsAppliedForESign = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectApplicantWiseGrievanceSummary
      public class SPSelectApplicantWiseGrievanceSummary
      {
         public string SPName = "SPSelectApplicantWiseGrievanceSummary";
         public int RoleId = 0;
         public int FromDate = 1;
         public int ToDate = 2;
         public int Name = 3;
         public int Mobile = 4;
         public int EmailId = 5;
         public int RegionId = 6;
         public int UserId = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertTwoRTransactionForPast
      public class SPInsertTwoRTransactionForPast
      {
         public string SPName = "SPInsertTwoRTransactionForPast";
         public int TwoRApplicationId = 0;
         public int ApplicationFormId = 1;
         public int BankName = 2;
         public int BranchName = 3;
         public int LoanAmount = 4;
         public int Dateof2RPermission = 5;
         public int NOCLetter = 6;
         public int UserId = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSuperHOForwardToDepartment
      public class SPSuperHOForwardToDepartment
      {
         public string SPName = "SPSuperHOForwardToDepartment";
         public int GrievanceApplicationId = 0;
         public int Remarks = 1;
         public int ModifiedBy = 2;
         public int AssignedRoleId = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPHelpdeskForwardToDALeaseDocument
      public class SPHelpdeskForwardToDALeaseDocument
      {
         public string SPName = "SPHelpdeskForwardToDALeaseDocument";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
         public int BackwardRemark = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpApproveWaterSupplyApplicationDemandDraftByDEE
      public class SpApproveWaterSupplyApplicationDemandDraftByDEE
      {
         public string SPName = "SpApproveWaterSupplyApplicationDemandDraftByDEE";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int UserRoleId = 2;
         public int CurrentApplicationActionId = 3;
         public int CurrentApplicationStatusId = 4;
         public int AssignedRoleId = 5;
         public int AssignedActionId = 6;
         public int PaymentRemarks = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectApplicantTwoRApplicationDocumentList
      public class SPSelectApplicantTwoRApplicationDocumentList
      {
         public string SPName = "SPSelectApplicantTwoRApplicationDocumentList";
         public int DocumentList = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateTwoRApplicationDocumentTransaction
      public class SPInsertUpdateTwoRApplicationDocumentTransaction
      {
         public string SPName = "SPInsertUpdateTwoRApplicationDocumentTransaction";
         public int TwoRApplicationDocumentTransactionId = 0;
         public int ApplicationFormId = 1;
         public int RoleId = 2;
         public int DocumentId = 3;
         public int CreatedBy = 4;
         public int Action = 5;
         public int Operation = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferModuleDocumentTransactionByApplicationId18102016
      public class SPSelectTransferModuleDocumentTransactionByApplicationId18102016
      {
         public string SPName = "SPSelectTransferModuleDocumentTransactionByApplicationId18102016";
         public int ApplicationId = 0;
         public int UserId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region GetROUAdditionalDocumenttoQueryUser
      public class GetROUAdditionalDocumenttoQueryUser
      {
         public string SPName = "GetROUAdditionalDocumenttoQueryUser";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectGrievanceAdminDocumentByGrievanceApplicationId
      public class SPSelectGrievanceAdminDocumentByGrievanceApplicationId
      {
         public string SPName = "SPSelectGrievanceAdminDocumentByGrievanceApplicationId";
         public int GrievanceApplicationId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteTwoRTransactionForPastByApplicationFormId01092016
      public class SPDeleteTwoRTransactionForPastByApplicationFormId01092016
      {
         public string SPName = "SPDeleteTwoRTransactionForPastByApplicationFormId01092016";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateRemarksGrievanceByHOD
      public class SPUpdateRemarksGrievanceByHOD
      {
         public string SPName = "SPUpdateRemarksGrievanceByHOD";
         public int GrievanceApplicationId = 0;
         public int RoleId = 1;
         public int Remarks = 2;
         public int ModifiedBy = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateSurrenderApplication
      public class SPInsertUpdateSurrenderApplication
      {
         public string SPName = "SPInsertUpdateSurrenderApplication";
         public int ApplicationFormId = 0;
         public int ReferenceNo = 1;
         public int ActionId = 2;
         public int AssignedRoleId = 3;
         public int ApplicationId = 4;
         public int ApplicationFormDate = 5;
         public int Name = 6;
         public int MobileNo = 7;
         public int EstateId = 8;
         public int RegionId = 9;
         public int PlotShedType = 10;
         public int PlotShedNo = 11;
         public int PlotShedArea = 12;
         public int AllotmentDate = 13;
         public int NatureofCompany = 14;
         public int ApplicantName = 15;
         public int ConstituteType = 16;
         public int AgreementDate = 17;
         public int PossessionDate = 18;
         public int ReasonForSurrender = 19;
         public int OraEstateId = 20;
         public int OraRegionId = 21;
         public int OraPlotTypeId = 22;
         public int PartyCode = 23;
         public int FinalPaymentStatus = 24;
         public int EmailId = 25;
         public int IsSubmitted = 26;
         public int SubmissionDate = 27;
         public int IsActive = 28;
         public int CreatedBy = 29;
         public int CreationOn = 30;
         public int ModifiedBy = 31;
         public int ModifiedOn = 32;
         public int Mode = 33;
         public int DocumentXML = 34;
         public int SGSTAmount = 35;
         public int CGSTAmount = 36;
         public int BaseAmount = 37;
         public int ACCHEAD_C = 38;
         public int ACC_M = 39;
         public int FROM_D = 40;
         public int TO_D = 41;
         public int ACC_NO = 42;
         public int SGST_A = 43;
         public int CGST_A = 44;
         public int ACC_N = 45;
         public int TotalAdministrativeCharges = 46;
         public int IsLeaseDeed = 47;
         public int LeaseDeedDate = 48;
         public int CommAddress = 49;
         public int OfferCumAllotmentLetterDate = 50;
         public int OfferCumAlltmentLetterNo = 51;
         public int IsPhysicalPossessionTaken = 52;
         public int TwoRReferenceNo = 53;
         public int TwoRLatestDate = 54;
         public int TwoRBankname = 55;
         public int IsTwoRPermission = 56;
         public int AlloteeGSTNo = 57;
         public int SEZ = 58;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteDistrictMasterByDistrictId
      public class SPDeleteDistrictMasterByDistrictId
      {
         public string SPName = "SPDeleteDistrictMasterByDistrictId";
         public int DistrictId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateTwoRApplicationByAdmin17032017
      public class SpUpdateTwoRApplicationByAdmin17032017
      {
         public string SPName = "SpUpdateTwoRApplicationByAdmin17032017";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int CurrentApplicationActionId = 2;
         public int NewAssinedActionId = 3;
         public int DocumentXML = 4;
         public int Remarks = 5;
         public int IsCollatral = 6;
         public int SurveyNo = 7;
         public int Manufacturing = 8;
         public int FinancialInstitutionsXML = 9;
         public int letterNo = 10;
         public int LetterDate = 11;
         public int CityName = 12;
         public int TalukaName = 13;
         public int DistrictName = 14;
         public int WardNos = 15;
         public int IsLoanTakenFromMultipleBank = 16;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPHelpdeskForwardToDMQueryApplication
      public class SPHelpdeskForwardToDMQueryApplication
      {
         public string SPName = "SPHelpdeskForwardToDMQueryApplication";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
         public int BackwardRemark = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteGeneralApplicationandWaterSupplyApplicationFormByApplicationFormId
      public class SPDeleteGeneralApplicationandWaterSupplyApplicationFormByApplicationFormId
      {
         public string SPName = "SPDeleteGeneralApplicationandWaterSupplyApplicationFormByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubLettingModuleInvoiceByHeader_Old
      public class SPSelectSubLettingModuleInvoiceByHeader_Old
      {
         public string SPName = "SPSelectSubLettingModuleInvoiceByHeader_Old";
         public int ApplicationFormId = 0;
         public int TxId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTwoRApplicationModuleFinancialDetails
      public class SPSelectTwoRApplicationModuleFinancialDetails
      {
         public string SPName = "SPSelectTwoRApplicationModuleFinancialDetails";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdatePaymentDetailsBuildingCompletion
      public class SPUpdatePaymentDetailsBuildingCompletion
      {
         public string SPName = "SPUpdatePaymentDetailsBuildingCompletion";
         public int ApplicationFormId = 0;
         public int TxId = 1;
         public int TxRefNo = 2;
         public int TxStatus = 3;
         public int TxAmount = 4;
         public int TxMsg = 5;
         public int pgTxnNo = 6;
         public int issuerRefNo = 7;
         public int authIdCode = 8;
         public int firstName = 9;
         public int lastName = 10;
         public int pgRespCode = 11;
         public int addressZip = 12;
         public int signature = 13;
         public int Head = 14;
         public int paymentMode = 15;
         public int TxGateway = 16;
         public int cardType = 17;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferModuleDocumentTransactionByApplicationIdPublic05102016_OLD
      public class SPSelectTransferModuleDocumentTransactionByApplicationIdPublic05102016_OLD
      {
         public string SPName = "SPSelectTransferModuleDocumentTransactionByApplicationIdPublic05102016_OLD";
         public int AplicationFormId = 0;
         public int ConstituteType = 1;
         public int DeathWIllType = 2;
         public int TrasferType = 3;
         public int DeathCase = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateSublettingModuleOutwardByApplicationFormId
      public class SPUpdateSublettingModuleOutwardByApplicationFormId
      {
         public string SPName = "SPUpdateSublettingModuleOutwardByApplicationFormId";
         public int ApplicationFormId = 0;
         public int OutwardDocumentName = 1;
         public int isPTO = 2;
         public int IsAggredTransferMode = 3;
         public int FormalTrasferOrInFormalTrasfer = 4;
         public int ModifiedBy = 5;
         public int Remarks = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDMSExcelUploadData
      public class SPDMSExcelUploadData
      {
         public string SPName = "SPDMSExcelUploadData";
         public int Mode = 0;
         public int Region = 1;
         public int Estate = 2;
         public int PlotType = 3;
         public int PlotNo = 4;
         public int Barcode = 5;
         public int FolderName = 6;
         public int FileName = 7;
         public int DocumentDate = 8;
         public int DocumentShorcode = 9;
         public int PartyName = 10;
         public int PartyCode = 11;
         public int Branch = 12;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectGrievanceApplicationListSearchByUserId
      public class SPSelectGrievanceApplicationListSearchByUserId
      {
         public string SPName = "SPSelectGrievanceApplicationListSearchByUserId";
         public int UserId = 0;
         public int FromDate = 1;
         public int ToDate = 2;
         public int OfficeUserId = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectAmmalgmationApplicationPaymentDetailByApplicationFormId
      public class SPSelectAmmalgmationApplicationPaymentDetailByApplicationFormId
      {
         public string SPName = "SPSelectAmmalgmationApplicationPaymentDetailByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertTwoRTransactionForSameUnit
      public class SPInsertTwoRTransactionForSameUnit
      {
         public string SPName = "SPInsertTwoRTransactionForSameUnit";
         public int ApplicationFormId = 0;
         public int BankName = 1;
         public int BranchName = 2;
         public int PermissionLetterNo = 3;
         public int LoanAmount = 4;
         public int Dateof2RPermission = 5;
         public int NOCLetter = 6;
         public int UserId = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateDistrictMaster
      public class SPInsertUpdateDistrictMaster
      {
         public string SPName = "SPInsertUpdateDistrictMaster";
         public int DistrictId = 0;
         public int District = 1;
         public int StateId = 2;
         public int UserId = 3;
         public int IsActive = 4;
         public int Operation = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTwoRApplicationByApplicationFormId17032017
      public class SPSelectTwoRApplicationByApplicationFormId17032017
      {
         public string SPName = "SPSelectTwoRApplicationByApplicationFormId17032017";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPHelpdeskForwardToRMQueryApplication
      public class SPHelpdeskForwardToRMQueryApplication
      {
         public string SPName = "SPHelpdeskForwardToRMQueryApplication";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
         public int BackwardRemark = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateWaterSupplyApplication
      public class SPInsertUpdateWaterSupplyApplication
      {
         public string SPName = "SPInsertUpdateWaterSupplyApplication";
         public int ApplicationFormId = 0;
         public int ApplicationId = 1;
         public int ReferenceNo = 2;
         public int CreatedBy = 3;
         public int IsActive = 4;
         public int Operation = 5;
         public int SEZ = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateTwoRApplicationModuleFinancialDetails
      public class SPInsertUpdateTwoRApplicationModuleFinancialDetails
      {
         public string SPName = "SPInsertUpdateTwoRApplicationModuleFinancialDetails";
         public int ApplicationFormId = 0;
         public int BankName = 1;
         public int BankEmailId = 2;
         public int Particulars = 3;
         public int LetterNo = 4;
         public int LetterDate = 5;
         public int CreatedBy = 6;
         public int BranchName = 7;
         public int BranchAddress = 8;
         public int LeadBank = 9;
         public int Total = 10;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPaymentRecieptDetailsBuildingCompletion
      public class SPSelectPaymentRecieptDetailsBuildingCompletion
      {
         public string SPName = "SPSelectPaymentRecieptDetailsBuildingCompletion";
         public int txnId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPlotShedNoAndPartyNameByEstateId
      public class SPSelectPlotShedNoAndPartyNameByEstateId
      {
         public string SPName = "SPSelectPlotShedNoAndPartyNameByEstateId";
         public int EstateId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPAMBackwardToHelpdeskTwoRApplication
      public class SPAMBackwardToHelpdeskTwoRApplication
      {
         public string SPName = "SPAMBackwardToHelpdeskTwoRApplication";
         public int ApplicationFormId = 0;
         public int AssignedRoleId = 1;
         public int ModifiedBy = 2;
         public int BackwardRemark = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferModuleForReferenceNo25092016
      public class SPSelectTransferModuleForReferenceNo25092016
      {
         public string SPName = "SPSelectTransferModuleForReferenceNo25092016";
         public int EstateId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTwoRApplicationByApplicationFormId01092016
      public class SPSelectTwoRApplicationByApplicationFormId01092016
      {
         public string SPName = "SPSelectTwoRApplicationByApplicationFormId01092016";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateGrievanceApplicantUserMaster
      public class SPInsertUpdateGrievanceApplicantUserMaster
      {
         public string SPName = "SPInsertUpdateGrievanceApplicantUserMaster";
         public int FirstName = 0;
         public int MiddleName = 1;
         public int LastName = 2;
         public int ContactNo = 3;
         public int MobileNo = 4;
         public int EmailId = 5;
         public int Password = 6;
         public int IsActive = 7;
         public int Address = 8;
         public int LandMark = 9;
         public int City = 10;
         public int Pincode = 11;
         public int Prefix = 12;
         public int UserId = 13;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPTest
      public class SPTest
      {
         public string SPName = "SPTest";
         public int ApplicationFormId = 0;
         public int DocumentXML = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectAllotmentPriceForTransferByApplicationFormId
      public class SPSelectAllotmentPriceForTransferByApplicationFormId
      {
         public string SPName = "SPSelectAllotmentPriceForTransferByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPHelpdeskOutwardLeaseDocument
      public class SPHelpdeskOutwardLeaseDocument
      {
         public string SPName = "SPHelpdeskOutwardLeaseDocument";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
         public int BackwardRemark = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region Get_SPHaseValue
      public class Get_SPHaseValue
      {
         public string SPName = "Get_SPHaseValue";
         public int SpName = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpSaveWaterSupplyReleaseConnectionDetails
      public class SpSaveWaterSupplyReleaseConnectionDetails
      {
         public string SPName = "SpSaveWaterSupplyReleaseConnectionDetails";
         public int ApplicationFormId = 0;
         public int InspectionDatetime = 1;
         public int ReleaseConnectionDocList = 2;
         public int OnlineFeesSubmissionReceiptAthmt = 3;
         public int SignedAgreementDocumentAthmt = 4;
         public int OtherDocumentsAthmt = 5;
         public int ApplicantReleaseRemarks = 6;
         public int UserId = 7;
         public int ActionId = 8;
         public int MeterNo = 9;
         public int MeterMake = 10;
         public int InitialReading = 11;
         public int TestReportAttached = 12;
         public int GreaterThan4000Flag = 13;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTwoRApplicationModuleFinancialDetailsForReport
      public class SPSelectTwoRApplicationModuleFinancialDetailsForReport
      {
         public string SPName = "SPSelectTwoRApplicationModuleFinancialDetailsForReport";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateSubdivisionModuleforGenerateFSOOutwardNo
      public class SpUpdateSubdivisionModuleforGenerateFSOOutwardNo
      {
         public string SPName = "SpUpdateSubdivisionModuleforGenerateFSOOutwardNo";
         public int ApplicationFormId = 0;
         public int LeaseDeedDate = 1;
         public int IsDeedAssignment = 2;
         public int DateOfAssignment = 3;
         public int IsDeedDeclaration = 4;
         public int DateOfDeclaration = 5;
         public int IsDeedRectification = 6;
         public int DateOfRectification = 7;
         public int DateOfSupplementaryAgreement = 8;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateTransferModuleOutwardByApplicationFormId
      public class SPUpdateTransferModuleOutwardByApplicationFormId
      {
         public string SPName = "SPUpdateTransferModuleOutwardByApplicationFormId";
         public int ApplicationFormId = 0;
         public int OutwardDocumentName = 1;
         public int isPTO = 2;
         public int IsAggredTransferMode = 3;
         public int FormalTrasferOrInFormalTrasfer = 4;
         public int ModifiedBy = 5;
         public int Remarks = 6;
         public int IsSigned = 7;
         public int DSPublickey = 8;
         public int DSHash = 9;
         public int DScrtString = 10;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPCheckedBackwardTwoRApplication
      public class SPCheckedBackwardTwoRApplication
      {
         public string SPName = "SPCheckedBackwardTwoRApplication";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateTrasferModuleApplicationByAdmin25092016
      public class SpUpdateTrasferModuleApplicationByAdmin25092016
      {
         public string SPName = "SpUpdateTrasferModuleApplicationByAdmin25092016";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int CurrentApplicationActionId = 2;
         public int NewAssinedActionId = 3;
         public int DocumentXML = 4;
         public int Remarks = 5;
         public int StrDocument = 6;
         public int StrDocument1 = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSublettingPaymentVerification
      public class SPSublettingPaymentVerification
      {
         public string SPName = "SPSublettingPaymentVerification";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int UserRoleId = 2;
         public int CurrentApplicationActionId = 3;
         public int AssignedRoleId = 4;
         public int AssignedActionId = 5;
         public int Remark = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectOracleRegionEstateIdByDivisionId
      public class SPSelectOracleRegionEstateIdByDivisionId
      {
         public string SPName = "SPSelectOracleRegionEstateIdByDivisionId";
         public int DivisionId = 0;
         public int EstateId = 1;
         public int PlotTypeId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectGrievanceApplicantUserMasterByEmailId
      public class SPSelectGrievanceApplicantUserMasterByEmailId
      {
         public string SPName = "SPSelectGrievanceApplicantUserMasterByEmailId";
         public int EmailId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSurrenderApplicationForView
      public class SPSelectSurrenderApplicationForView
      {
         public string SPName = "SPSelectSurrenderApplicationForView";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateLeaseApplicationDemandDraft
      public class SPInsertUpdateLeaseApplicationDemandDraft
      {
         public string SPName = "SPInsertUpdateLeaseApplicationDemandDraft";
         public int LeaseApplicationDemandDraftId = 0;
         public int ApplicationFormId = 1;
         public int ReferenceNo = 2;
         public int ApplicationId = 3;
         public int DDNo = 4;
         public int BankName = 5;
         public int BranchName = 6;
         public int Amount = 7;
         public int CreatedBy = 8;
         public int IsActive = 9;
         public int DDDate = 10;
         public int DDAgainst = 11;
         public int Operation = 12;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectWaterSupplyApplication
      public class SPSelectWaterSupplyApplication
      {
         public string SPName = "SPSelectWaterSupplyApplication";
         public int AssignedRoleId = 0;
         public int SearchValue = 1;
         public int SearchId = 2;
         public int RegionId = 3;
         public int UserId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateTrasferModuleApplicationByAdmin22102016_old
      public class SpUpdateTrasferModuleApplicationByAdmin22102016_old
      {
         public string SPName = "SpUpdateTrasferModuleApplicationByAdmin22102016_old";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int CurrentApplicationActionId = 2;
         public int NewAssinedActionId = 3;
         public int DocumentXML = 4;
         public int Remarks = 5;
         public int StrDocument = 6;
         public int StrDocument1 = 7;
         public int FormalTrasferOrInFormalTrasfer = 8;
         public int FormalTrasferOrInFormalTrasferCal = 9;
         public int ApplicantIdentityOkNotOk = 10;
         public int ApplicantIdentityOkNotOkRemarks = 11;
         public int FTOFileOkNotOk = 12;
         public int FTOFileOkNotOkRemarks = 13;
         public int PossessionReceiptFileOkNotOk = 14;
         public int PossessionReceiptFileOkNotOkRemarks = 15;
         public int CorrigendumFileOkNotOk = 16;
         public int CorrigendumFileOkNotOkRemarks = 17;
         public int LeaseDeedDocumentOkNotOk = 18;
         public int LeaseDeedDocumentOkNotOkRemarks = 19;
         public int NOCAttachmentOkNotOk = 20;
         public int NOCAttachmentOkNotOkRemarks = 21;
         public int PlanPassedFileOkNotOk = 22;
         public int PlanPassedFileOkNotOkRemarks = 23;
         public int FamilyRelationDocumentOkNotOk = 24;
         public int FamilyRelationDocumentOkNotOkRemarks = 25;
         public int AMApplicantIdentityOkNotOk = 26;
         public int AMApplicantIdentityOkNotOkRemarks = 27;
         public int AMFTOFileOkNotOk = 28;
         public int AMFTOFileOkNotOkRemarks = 29;
         public int AMPossessionReceiptFileOkNotOk = 30;
         public int AMPossessionReceiptFileOkNotOkRemarks = 31;
         public int AMCorrigendumFileOkNotOk = 32;
         public int AMCorrigendumFileOkNotOkRemarks = 33;
         public int AMLeaseDeedDocumentOkNotOk = 34;
         public int AMLeaseDeedDocumentOkNotOkRemarks = 35;
         public int AMNOCAttachmentOkNotOk = 36;
         public int AMNOCAttachmentOkNotOkRemarks = 37;
         public int AMPlanPassedFileOkNotOk = 38;
         public int AMPlanPassedFileOkNotOkRemarks = 39;
         public int AMFamilyRelationDocumentOkNotOk = 40;
         public int AMFamilyRelationDocumentOkNotOkRemarks = 41;
         public int RMApplicantIdentityOkNotOk = 42;
         public int RMApplicantIdentityOkNotOkRemarks = 43;
         public int RMFTOFileOkNotOk = 44;
         public int RMFTOFileOkNotOkRemarks = 45;
         public int RMPossessionReceiptFileOkNotOk = 46;
         public int RMPossessionReceiptFileOkNotOkRemarks = 47;
         public int RMCorrigendumFileOkNotOk = 48;
         public int RMCorrigendumFileOkNotOkRemarks = 49;
         public int RMLeaseDeedDocumentOkNotOk = 50;
         public int RMLeaseDeedDocumentOkNotOkRemarks = 51;
         public int RMNOCAttachmentOkNotOk = 52;
         public int RMNOCAttachmentOkNotOkRemarks = 53;
         public int RMPlanPassedFileOkNotOk = 54;
         public int RMPlanPassedFileOkNotOkRemarks = 55;
         public int RMFamilyRelationDocumentOkNotOk = 56;
         public int RMFamilyRelationDocumentOkNotOkRemarks = 57;
         public int TypeofTransferRemarksAM = 58;
         public int TypeofTransferRemarksRM = 59;
         public int IsAggredTransferMode = 60;
         public int ConveyanceDeedDocumentOkNotOk = 61;
         public int ConveyanceDeedDocumentOkNotOkRemarks = 62;
         public int AMConveyanceDeedDocumentOkNotOk = 63;
         public int AMConveyanceDeedDocumentOkNotOkRemarks = 64;
         public int RMConveyanceDeedDocumentOkNotOk = 65;
         public int RMConveyanceDeedDocumentOkNotOkRemarks = 66;
         public int DACorrigendumFileNameDocumentOkNotOk = 67;
         public int DACorrigendumFileNameDocumentOkNotOkRemarks = 68;
         public int AMCorrigendumFileNameDocumentOkNotOk = 69;
         public int AMCorrigendumFileNameDocumentOkNotOkRemarks = 70;
         public int RMCorrigendumFileNameDocumentOkNotOk = 71;
         public int RMCorrigendumFileNameDocumentOkNotOkRemarks = 72;
         public int DACorrigendumFilePropertyDocumentOkNotOk = 73;
         public int DACorrigendumFilePropertyDocumentOkNotOkRemarks = 74;
         public int AMCorrigendumFilePropertyDocumentOkNotOk = 75;
         public int AMCorrigendumFilePropertyDocumentOkNotOkRemarks = 76;
         public int RMCorrigendumFilePropertyDocumentOkNotOk = 77;
         public int RMCorrigendumFilePropertyDocumentOkNotOkRemarks = 78;
         public int DAUndertakingDocumentOkNotOk = 79;
         public int DAUndertakingDocumentOkNotOkRemarks = 80;
         public int AMUndertakingDocumentOkNotOk = 81;
         public int AMUndertakingDocumentOkNotOkRemarks = 82;
         public int RMUndertakingDocumentOkNotOk = 83;
         public int RMUndertakingDocumentOkNotOkRemarks = 84;
         public int DMApplicantIdentityOkNotOk = 85;
         public int DMApplicantIdentityOkNotOkRemarks = 86;
         public int DMFTOFileOkNotOk = 87;
         public int DMFTOFileOkNotOkRemarks = 88;
         public int DMPossessionReceiptFileOkNotOk = 89;
         public int DMPossessionReceiptFileOkNotOkRemarks = 90;
         public int DMCorrigendumFileOkNotOk = 91;
         public int DMCorrigendumFileOkNotOkRemarks = 92;
         public int DMCorrigendumFileNameDocumentOkNotOk = 93;
         public int DMCorrigendumFileNameDocumentOkNotOkRemarks = 94;
         public int DMCorrigendumFilePropertyDocumentOkNotOk = 95;
         public int DMCorrigendumFilePropertyDocumentOkNotOkRemarks = 96;
         public int DMLeaseDeedDocumentOkNotOk = 97;
         public int DMLeaseDeedDocumentOkNotOkRemarks = 98;
         public int DMNOCAttachmentOkNotOk = 99;
         public int DMNOCAttachmentOkNotOkRemarks = 100;
         public int DMPlanPassedFileOkNotOk = 101;
         public int DMPlanPassedFileOkNotOkRemarks = 102;
         public int DMFamilyRelationDocumentOkNotOk = 103;
         public int DMFamilyRelationDocumentOkNotOkRemarks = 104;
         public int DMConveyanceDeedDocumentOkNotOk = 105;
         public int DMConveyanceDeedDocumentOkNotOkRemarks = 106;
         public int DMUndertakingDocumentOkNotOk = 107;
         public int DMUndertakingDocumentOkNotOkRemarks = 108;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteTwoRApplicationModuleFinancialDetails
      public class SPDeleteTwoRApplicationModuleFinancialDetails
      {
         public string SPName = "SPDeleteTwoRApplicationModuleFinancialDetails";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPAmalgamationUpdateApplicationForNOC
      public class SPAmalgamationUpdateApplicationForNOC
      {
         public string SPName = "SPAmalgamationUpdateApplicationForNOC";
         public int ApplicationFormId = 0;
         public int UserId = 1;
         public int NOCDocumentApplicant = 2;
         public int Remark = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTwoRApplicationList
      public class SPSelectTwoRApplicationList
      {
         public string SPName = "SPSelectTwoRApplicationList";
         public int UserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferApplicationListDetails25092016
      public class SPSelectTransferApplicationListDetails25092016
      {
         public string SPName = "SPSelectTransferApplicationListDetails25092016";
         public int AssignedRoleId = 0;
         public int SearchValue = 1;
         public int SearchId = 2;
         public int RegionId = 3;
         public int UserId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectGrievanceApplicantUserMasterForChangePassword
      public class SPSelectGrievanceApplicantUserMasterForChangePassword
      {
         public string SPName = "SPSelectGrievanceApplicantUserMasterForChangePassword";
         public int EmailId = 0;
         public int Password = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSurrenderApplicationPaymentDetailByApplicationFormId
      public class SPSelectSurrenderApplicationPaymentDetailByApplicationFormId
      {
         public string SPName = "SPSelectSurrenderApplicationPaymentDetailByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPrintPaymentRecieptDetails
      public class SPSelectPrintPaymentRecieptDetails
      {
         public string SPName = "SPSelectPrintPaymentRecieptDetails";
         public int IFP_PersonId = 0;
         public int IFP_ApplicationId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectWaterSupplyApplicationByApplicationFormId
      public class SPSelectWaterSupplyApplicationByApplicationFormId
      {
         public string SPName = "SPSelectWaterSupplyApplicationByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateTrasferModuleforGeneratePTOOutwardNo
      public class SpUpdateTrasferModuleforGeneratePTOOutwardNo
      {
         public string SPName = "SpUpdateTrasferModuleforGeneratePTOOutwardNo";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferApplicationOfficeUserDetailsByRoleIdForEmail
      public class SPSelectTransferApplicationOfficeUserDetailsByRoleIdForEmail
      {
         public string SPName = "SPSelectTransferApplicationOfficeUserDetailsByRoleIdForEmail";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTwoRApplicationByApplicationFormId
      public class SPSelectTwoRApplicationByApplicationFormId
      {
         public string SPName = "SPSelectTwoRApplicationByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateTrasferModuleOutWardApplicationByAdmin25092016
      public class SpUpdateTrasferModuleOutWardApplicationByAdmin25092016
      {
         public string SPName = "SpUpdateTrasferModuleOutWardApplicationByAdmin25092016";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int CurrentApplicationActionId = 2;
         public int NewAssinedActionId = 3;
         public int OutwardNo = 4;
         public int OutwardDate = 5;
         public int Remarks = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateGrievanceApplicantUserMasterForChangePassword
      public class SPUpdateGrievanceApplicantUserMasterForChangePassword
      {
         public string SPName = "SPUpdateGrievanceApplicantUserMasterForChangePassword";
         public int EmailId = 0;
         public int Password = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPaymentRecieptDetailsForSurrenderApplication
      public class SPSelectPaymentRecieptDetailsForSurrenderApplication
      {
         public string SPName = "SPSelectPaymentRecieptDetailsForSurrenderApplication";
         public int txnId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSurrenderDocumentTransactionByApplicationIdOfficeSide
      public class SPSelectSurrenderDocumentTransactionByApplicationIdOfficeSide
      {
         public string SPName = "SPSelectSurrenderDocumentTransactionByApplicationIdOfficeSide";
         public int AplicationFormId = 0;
         public int ConstituteTypeTransferor = 1;
         public int ActionID = 2;
         public int IsTwoRPermissionTaken = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteTalukaMasterByTalukaId
      public class SPDeleteTalukaMasterByTalukaId
      {
         public string SPName = "SPDeleteTalukaMasterByTalukaId";
         public int TalukaId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpSurrenderApplicationRemarksHistory
      public class SpSurrenderApplicationRemarksHistory
      {
         public string SPName = "SpSurrenderApplicationRemarksHistory";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPRMBackwardToAMLeaseDocument
      public class SPRMBackwardToAMLeaseDocument
      {
         public string SPName = "SPRMBackwardToAMLeaseDocument";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
         public int BackwardRemark = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectWaterSupplyApplicationByIFPApplicationId
      public class SPSelectWaterSupplyApplicationByIFPApplicationId
      {
         public string SPName = "SPSelectWaterSupplyApplicationByIFPApplicationId";
         public int IFPApplicationId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectActionOfApplicationQuery
      public class SPSelectActionOfApplicationQuery
      {
         public string SPName = "SPSelectActionOfApplicationQuery";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SP_SelectDocumentMasterDataForAmalgamation
      public class SP_SelectDocumentMasterDataForAmalgamation
      {
         public string SPName = "SP_SelectDocumentMasterDataForAmalgamation";
         public int ApplicationFormId = 0;
         public int mode = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertTransactionReferenceNoPaymentDetailsForPlinthCertification
      public class SPInsertTransactionReferenceNoPaymentDetailsForPlinthCertification
      {
         public string SPName = "SPInsertTransactionReferenceNoPaymentDetailsForPlinthCertification";
         public int TxId = 0;
         public int ApplicationFormId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferModuleDocumentTransactionByApplicationIdPublic25092016
      public class SPSelectTransferModuleDocumentTransactionByApplicationIdPublic25092016
      {
         public string SPName = "SPSelectTransferModuleDocumentTransactionByApplicationIdPublic25092016";
         public int AplicationFormId = 0;
         public int DocumentType = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectGrievanceSubjectMaster
      public class SPSelectGrievanceSubjectMaster
      {
         public string SPName = "SPSelectGrievanceSubjectMaster";
         public int IsReletedEstate = 0;
         public int EstateId = 1;
         public int Department = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSurrenderApplicationPaymentDetailByTxId
      public class SPSelectSurrenderApplicationPaymentDetailByTxId
      {
         public string SPName = "SPSelectSurrenderApplicationPaymentDetailByTxId";
         public int TxId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateTalukaMaster
      public class SPInsertUpdateTalukaMaster
      {
         public string SPName = "SPInsertUpdateTalukaMaster";
         public int TalukaId = 0;
         public int Taluka = 1;
         public int DistrictId = 2;
         public int UserId = 3;
         public int IsActive = 4;
         public int Operation = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTwoRApplicationOfficeUserDetailsByRoleIdForEmail17032017
      public class SPSelectTwoRApplicationOfficeUserDetailsByRoleIdForEmail17032017
      {
         public string SPName = "SPSelectTwoRApplicationOfficeUserDetailsByRoleIdForEmail17032017";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPRMForwardToAM
      public class SPRMForwardToAM
      {
         public string SPName = "SPRMForwardToAM";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
         public int BackwardRemark = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpViewSurrenderDocumentForApplicant
      public class SpViewSurrenderDocumentForApplicant
      {
         public string SPName = "SpViewSurrenderDocumentForApplicant";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPCheckUniqueTransactionReferenceNoForPlinthCertification
      public class SPCheckUniqueTransactionReferenceNoForPlinthCertification
      {
         public string SPName = "SPCheckUniqueTransactionReferenceNoForPlinthCertification";
         public int TxId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferModuleByApplicationFormId25092016
      public class SPSelectTransferModuleByApplicationFormId25092016
      {
         public string SPName = "SPSelectTransferModuleByApplicationFormId25092016";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateReceivedFileTrackingForTwoR
      public class SPUpdateReceivedFileTrackingForTwoR
      {
         public string SPName = "SPUpdateReceivedFileTrackingForTwoR";
         public int ApplicationId = 0;
         public int ApplicationFormId = 1;
         public int BarcodeNo = 2;
         public int Remarks = 3;
         public int ModifiedBy = 4;
         public int RoleId = 5;
         public int IsBarcodeFacility = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpSelectEstateMasterByCircleId
      public class SpSelectEstateMasterByCircleId
      {
         public string SPName = "SpSelectEstateMasterByCircleId";
         public int CircleId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDeedMasterByDeedTypeId
      public class SPSelectDeedMasterByDeedTypeId
      {
         public string SPName = "SPSelectDeedMasterByDeedTypeId";
         public int DeedTypeId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectHODBySubjectId
      public class SPSelectHODBySubjectId
      {
         public string SPName = "SPSelectHODBySubjectId";
         public int SubjectId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpInsertUpdateWaterDrainagePlanApprovalMailSend
      public class SpInsertUpdateWaterDrainagePlanApprovalMailSend
      {
         public string SPName = "SpInsertUpdateWaterDrainagePlanApprovalMailSend";
         public int ApplicationId = 0;
         public int TransactionId = 1;
         public int ApplicationFormId = 2;
         public int IsMailSendToApplicant = 3;
         public int MailBody = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPRMForwardToAMApproveApplication
      public class SPRMForwardToAMApproveApplication
      {
         public string SPName = "SPRMForwardToAMApproveApplication";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
         public int BackwardRemark = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectWaterSupplyApplicationIFPDetials03112017
      public class SPSelectWaterSupplyApplicationIFPDetials03112017
      {
         public string SPName = "SPSelectWaterSupplyApplicationIFPDetials03112017";
         public int ReferenceNo = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPlinthCertificationPaymentDetailByApplicationFormId
      public class SPSelectPlinthCertificationPaymentDetailByApplicationFormId
      {
         public string SPName = "SPSelectPlinthCertificationPaymentDetailByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPCheckUniqueReferenceNoForTransferModule25092016
      public class SPCheckUniqueReferenceNoForTransferModule25092016
      {
         public string SPName = "SPCheckUniqueReferenceNoForTransferModule25092016";
         public int ReferenceNo = 0;
         public int EstateId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDeedMasterByDeedType
      public class SPSelectDeedMasterByDeedType
      {
         public string SPName = "SPSelectDeedMasterByDeedType";
         public int DeedType = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPrevailingAllotmentPriceFor2R01092016
      public class SPSelectPrevailingAllotmentPriceFor2R01092016
      {
         public string SPName = "SPSelectPrevailingAllotmentPriceFor2R01092016";
         public int EstateId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectUserEmailIdByEstate
      public class SPSelectUserEmailIdByEstate
      {
         public string SPName = "SPSelectUserEmailIdByEstate";
         public int EstateId = 0;
         public int SubjectId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdatePaymentDetailsSurrender
      public class SPUpdatePaymentDetailsSurrender
      {
         public string SPName = "SPUpdatePaymentDetailsSurrender";
         public int ApplicationFormId = 0;
         public int TxId = 1;
         public int TxRefNo = 2;
         public int TxStatus = 3;
         public int TxAmount = 4;
         public int TxMsg = 5;
         public int pgTxnNo = 6;
         public int issuerRefNo = 7;
         public int authIdCode = 8;
         public int firstName = 9;
         public int lastName = 10;
         public int pgRespCode = 11;
         public int addressZip = 12;
         public int signature = 13;
         public int Head = 14;
         public int paymentMode = 15;
         public int TxGateway = 16;
         public int cardType = 17;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTalukaMasterByTaluka
      public class SPSelectTalukaMasterByTaluka
      {
         public string SPName = "SPSelectTalukaMasterByTaluka";
         public int Taluka = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPEstateListRegionPlotTypeWiseMatrix
      public class SPEstateListRegionPlotTypeWiseMatrix
      {
         public string SPName = "SPEstateListRegionPlotTypeWiseMatrix";
         public int RegionId = 0;
         public int PlotType = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPRMForwardToAMCheckedCorrigendum
      public class SPRMForwardToAMCheckedCorrigendum
      {
         public string SPName = "SPRMForwardToAMCheckedCorrigendum";
         public int ApplicationFormId = 0;
         public int AssignedRoleId = 1;
         public int ModifiedBy = 2;
         public int BackwardRemark = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectWaterSupplyApplicationList
      public class SPSelectWaterSupplyApplicationList
      {
         public string SPName = "SPSelectWaterSupplyApplicationList";
         public int UserId = 0;
         public int ProjectId = 1;
         public int SearchText = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSubdivisionSATP
      public class SPSubdivisionSATP
      {
         public string SPName = "SPSubdivisionSATP";
         public int Mode = 0;
         public int ApplicationFormId = 1;
         public int AssignRoleId = 2;
         public int AssignActionId = 3;
         public int UserId = 4;
         public int IsIncorporateDDPlan = 5;
         public int DateOfIncorporate = 6;
         public int DDPlanSATP = 7;
         public int Remarks = 8;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteHolidayMasterById
      public class SPDeleteHolidayMasterById
      {
         public string SPName = "SPDeleteHolidayMasterById";
         public int id = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPaymentRecieptDetailsPlinthCertification
      public class SPSelectPaymentRecieptDetailsPlinthCertification
      {
         public string SPName = "SPSelectPaymentRecieptDetailsPlinthCertification";
         public int txnId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPChangeBuildingPlanAction
      public class SPChangeBuildingPlanAction
      {
         public string SPName = "SPChangeBuildingPlanAction";
         public int Referenceno = 0;
         public int TypeOfAction = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPaymentRecieptDetailsForUpdateIFP
      public class SPSelectPaymentRecieptDetailsForUpdateIFP
      {
         public string SPName = "SPSelectPaymentRecieptDetailsForUpdateIFP";
         public int txnId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPCheckUniqueTransactionReferenceNoForAmmalgamation
      public class SPCheckUniqueTransactionReferenceNoForAmmalgamation
      {
         public string SPName = "SPCheckUniqueTransactionReferenceNoForAmmalgamation";
         public int TxId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferModuleDocumentTransactionByApplicationId25092016
      public class SPSelectTransferModuleDocumentTransactionByApplicationId25092016
      {
         public string SPName = "SPSelectTransferModuleDocumentTransactionByApplicationId25092016";
         public int AplicationFormId = 0;
         public int DocumentType = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateCRDatesOnReceiveForTwoR
      public class SPUpdateCRDatesOnReceiveForTwoR
      {
         public string SPName = "SPUpdateCRDatesOnReceiveForTwoR";
         public int ApplicationId = 0;
         public int ApplicationFormId = 1;
         public int ReceivedDate = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteDeedMasterByDeedTypeId
      public class SPDeleteDeedMasterByDeedTypeId
      {
         public string SPName = "SPDeleteDeedMasterByDeedTypeId";
         public int DeedTypeId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region M_SPInsertTransferModule
      public class M_SPInsertTransferModule
      {
         public string SPName = "M_SPInsertTransferModule";
         public int RegionId = 0;
         public int EstateId = 1;
         public int PlotShedTypeId = 2;
         public int PlotShedNo = 3;
         public int PlotArea = 4;
         public int DateofAllotment = 5;
         public int TransferorConsititutionTypeId = 6;
         public int TransfereeConsititutionTypeId = 7;
         public int AlloteeName = 8;
         public int CreatedBy = 9;
         public int IsChemical = 10;
         public int ApplicantName = 11;
         public int ApplicantLandlineNo = 12;
         public int ApplicantMobileNo = 13;
         public int ApplicantEmailId = 14;
         public int ApplicantRelationUnit = 15;
         public int ApplicantIdentity = 16;
         public int IsTransferSubDivision = 17;
         public int IsAmalgamation = 18;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertGrievanceSupportDocuments
      public class SPInsertGrievanceSupportDocuments
      {
         public string SPName = "SPInsertGrievanceSupportDocuments";
         public int DocumentPath = 0;
         public int CreatedBy = 1;
         public int GrievanceApplicationId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTalukaMasterByTalukaId
      public class SPSelectTalukaMasterByTalukaId
      {
         public string SPName = "SPSelectTalukaMasterByTalukaId";
         public int TalukaId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPRMForwardToAMRejectApplication
      public class SPRMForwardToAMRejectApplication
      {
         public string SPName = "SPRMForwardToAMRejectApplication";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
         public int BackwardRemark = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectWaterSupplyInspectionListByInspectorUserId
      public class SPSelectWaterSupplyInspectionListByInspectorUserId
      {
         public string SPName = "SPSelectWaterSupplyInspectionListByInspectorUserId";
         public int InspectorUserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTwoRApplicationTrancationByApplicationFormId
      public class SPSelectTwoRApplicationTrancationByApplicationFormId
      {
         public string SPName = "SPSelectTwoRApplicationTrancationByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferApplicationList25092016
      public class SPSelectTransferApplicationList25092016
      {
         public string SPName = "SPSelectTransferApplicationList25092016";
         public int UserId = 0;
         public int SearchText = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPPlotEsateDetailsSearch
      public class SPPlotEsateDetailsSearch
      {
         public string SPName = "SPPlotEsateDetailsSearch";
         public int RegionId = 0;
         public int EstateId = 1;
         public int IsPlotAlloted = 2;
         public int PlotType = 3;
         public int IsUtilized = 4;
         public int PlotArea = 5;
         public int ReginName = 6;
         public int EstateName = 7;
         public int RdblAllot = 8;
         public int RdblUtlilizes = 9;
         public int Area = 10;
         public int TypeOfPlotShed = 11;
         public int ProdClose = 12;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateDeedMaster
      public class SPInsertUpdateDeedMaster
      {
         public string SPName = "SPInsertUpdateDeedMaster";
         public int DeedTypeId = 0;
         public int DeedType = 1;
         public int UserId = 2;
         public int IsActive = 3;
         public int Operation = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateGeneralApplication01092016
      public class SPUpdateGeneralApplication01092016
      {
         public string SPName = "SPUpdateGeneralApplication01092016";
         public int FTOName = 0;
         public int FTOFile = 1;
         public int ApplicationFormId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDocument17032017For2R
      public class SPSelectDocument17032017For2R
      {
         public string SPName = "SPSelectDocument17032017For2R";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectGrievanceApplicationSupportDocumentByGrievanceApplicationId
      public class SPSelectGrievanceApplicationSupportDocumentByGrievanceApplicationId
      {
         public string SPName = "SPSelectGrievanceApplicationSupportDocumentByGrievanceApplicationId";
         public int GrievanceApplicationId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPCheckUniqueTransactionReferenceNoForSurrender
      public class SPCheckUniqueTransactionReferenceNoForSurrender
      {
         public string SPName = "SPCheckUniqueTransactionReferenceNoForSurrender";
         public int TxId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPRMForwardToAOCheckedCorrigendum
      public class SPRMForwardToAOCheckedCorrigendum
      {
         public string SPName = "SPRMForwardToAOCheckedCorrigendum";
         public int ApplicationFormId = 0;
         public int AssignedRoleId = 1;
         public int ModifiedBy = 2;
         public int BackwardRemark = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectWaterSupplyMailIdByRoleId
      public class SPSelectWaterSupplyMailIdByRoleId
      {
         public string SPName = "SPSelectWaterSupplyMailIdByRoleId";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectHolidayById
      public class SPSelectHolidayById
      {
         public string SPName = "SPSelectHolidayById";
         public int Id = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region spSelectApplicationDatebyApplicationFormId
      public class spSelectApplicationDatebyApplicationFormId
      {
         public string SPName = "spSelectApplicationDatebyApplicationFormId";
         public int ApplicationFormid = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPTransferLetter25092016
      public class SPTransferLetter25092016
      {
         public string SPName = "SPTransferLetter25092016";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTwoRApplication
      public class SPSelectTwoRApplication
      {
         public string SPName = "SPSelectTwoRApplication";
         public int AssignedRoleId = 0;
         public int SearchValue = 1;
         public int SearchId = 2;
         public int RegionId = 3;
         public int UserId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectEmailIdByEstateRegionRoleid
      public class SPSelectEmailIdByEstateRegionRoleid
      {
         public string SPName = "SPSelectEmailIdByEstateRegionRoleid";
         public int EstateId = 0;
         public int RegionId = 1;
         public int RoleId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertTransactionReferenceNoPaymentDetailsSurrender
      public class SPInsertTransactionReferenceNoPaymentDetailsSurrender
      {
         public string SPName = "SPInsertTransactionReferenceNoPaymentDetailsSurrender";
         public int TxId = 0;
         public int ApplicationFormId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPRMForwardToDMCorrigendum
      public class SPRMForwardToDMCorrigendum
      {
         public string SPName = "SPRMForwardToDMCorrigendum";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
         public int BackwardRemark = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectWaterSupplyReleaseConnectionDetailsByApplicationFormId
      public class SPSelectWaterSupplyReleaseConnectionDetailsByApplicationFormId
      {
         public string SPName = "SPSelectWaterSupplyReleaseConnectionDetailsByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateHolidayMaster
      public class SPInsertUpdateHolidayMaster
      {
         public string SPName = "SPInsertUpdateHolidayMaster";
         public int Id = 0;
         public int HolidayName = 1;
         public int HolidayDate = 2;
         public int year = 3;
         public int Operation = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpWaterSupplyApplicationPrintQuery
      public class SpWaterSupplyApplicationPrintQuery
      {
         public string SPName = "SpWaterSupplyApplicationPrintQuery";
         public int Applicationformid = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPTwoRApplicationAccepted
      public class SPTwoRApplicationAccepted
      {
         public string SPName = "SPTwoRApplicationAccepted";
         public int ApplicationFormId = 0;
         public int AssignedRoleId = 1;
         public int ModifiedBy = 2;
         public int BackwardRemark = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPTransfereeDetails25092016
      public class SPTransfereeDetails25092016
      {
         public string SPName = "SPTransfereeDetails25092016";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpTransferApplicationRemarksHistoryForApplicant
      public class SpTransferApplicationRemarksHistoryForApplicant
      {
         public string SPName = "SpTransferApplicationRemarksHistoryForApplicant";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectGrievanceApplicationRemarksByGrievanceApplicationId
      public class SPSelectGrievanceApplicationRemarksByGrievanceApplicationId
      {
         public string SPName = "SPSelectGrievanceApplicationRemarksByGrievanceApplicationId";
         public int GrievanceApplicationId = 0;
         public int ApplicationId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPRMForwardToDMDocumentChecking
      public class SPRMForwardToDMDocumentChecking
      {
         public string SPName = "SPRMForwardToDMDocumentChecking";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
         public int BackwardRemark = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region Sp_InsertSubdivisionDocumentTransactionMaster
      public class Sp_InsertSubdivisionDocumentTransactionMaster
      {
         public string SPName = "Sp_InsertSubdivisionDocumentTransactionMaster";
         public int AplicationFormId = 0;
         public int strfupRelation = 1;
         public int strfupSoftCopy11 = 2;
         public int strfupPlanPassed = 3;
         public int strfupPlanPassed2 = 4;
         public int strfupSoftcopy16 = 5;
         public int strfupSoftCopy17 = 6;
         public int strfupReceipt18 = 7;
         public int strfupSoftCopy19 = 8;
         public int strfupSketch = 9;
         public int strfupUndertakingFacilitiesAndAreaDocument = 10;
         public int strfupUndertakingLessThan50GCPlotDocument = 11;
         public int strfupElecBills = 12;
         public int strfupWaterBills = 13;
         public int strfupUndertaking = 14;
         public int UserId = 15;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateWaterSupplyApplicationByAdmin
      public class SpUpdateWaterSupplyApplicationByAdmin
      {
         public string SPName = "SpUpdateWaterSupplyApplicationByAdmin";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int UserRoleId = 2;
         public int CurrentApplicationActionId = 3;
         public int CurrentApplicationStatusId = 4;
         public int AssignedRoleId = 5;
         public int AssignedActionId = 6;
         public int AssignedStatusId = 7;
         public int SignedApplicationFormDEE = 8;
         public int CCAfromGpcbDEE = 9;
         public int SelfDeclarationNonPollutingIndustryDEE = 10;
         public int BuildingPlanDEE = 11;
         public int LicenseAgreementDEE = 12;
         public int SignedAgreementDEE = 13;
         public int RectificationDetailDEE = 14;
         public int PowerOfAttorneyDEE = 15;
         public int SignedApplicationFormXEN = 16;
         public int CCAfromGpcbXEN = 17;
         public int SelfDeclarationNonPollutingIndustryXEN = 18;
         public int BuildingPlanXEN = 19;
         public int LicenseAgreementXEN = 20;
         public int SignedAgreementXEN = 21;
         public int RectificationDetailXEN = 22;
         public int PowerOfAttorneyXEN = 23;
         public int SignedApplicationFormSE = 24;
         public int CCAfromGpcbSE = 25;
         public int SelfDeclarationNonPollutingIndustrySE = 26;
         public int BuildingPlanSE = 27;
         public int LicenseAgreementSE = 28;
         public int SignedAgreementSE = 29;
         public int RectificationDetailSE = 30;
         public int PowerOfAttorneySE = 31;
         public int CalculatingPipeDiaRequirementDEE = 32;
         public int CalculatingPipeDiaRequirementXEN = 33;
         public int CalculatingPipeDiaRequirementSE = 34;
         public int QueryLineDEE1 = 35;
         public int QueryLineDEE2 = 36;
         public int QueryLineDEE3 = 37;
         public int QueryLineDEE4 = 38;
         public int QueryLineDEE5 = 39;
         public int QueryLineXEN1 = 40;
         public int QueryLineXEN2 = 41;
         public int QueryLineXEN3 = 42;
         public int QueryLineXEN4 = 43;
         public int QueryLineXEN5 = 44;
         public int QueryLineSE1 = 45;
         public int QueryLineSE2 = 46;
         public int QueryLineSE3 = 47;
         public int QueryLineSE4 = 48;
         public int QueryLineSE5 = 49;
         public int AdminAttachmentXML = 50;
         public int Remarks = 51;
         public int QueryDocumentXML = 52;
         public int PossessionReceiptDEE = 53;
         public int OCAletterDEE = 54;
         public int PossessionReceiptXEN = 55;
         public int OCAletterXEN = 56;
         public int PossessionReceiptSE = 57;
         public int OCAletterSE = 58;
         public int PlotutilisationDEE = 59;
         public int PlotutilisationXEN = 60;
         public int PlotutilisationSE = 61;
         public int FinaltransferDEE = 62;
         public int FinaltransferXEN = 63;
         public int FinaltransferSE = 64;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSurrenderDocumentTransactionByApplicationId_TEST
      public class SPSelectSurrenderDocumentTransactionByApplicationId_TEST
      {
         public string SPName = "SPSelectSurrenderDocumentTransactionByApplicationId_TEST";
         public int AplicationFormId = 0;
         public int ConstituteTypeTransferor = 1;
         public int ActionID = 2;
         public int IsTwoRPermissionTaken = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPTwoRApplicationRejected
      public class SPTwoRApplicationRejected
      {
         public string SPName = "SPTwoRApplicationRejected";
         public int ApplicationFormId = 0;
         public int AssignedRoleId = 1;
         public int ModifiedBy = 2;
         public int BackwardRemark = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPTransferorDetails25092016
      public class SPTransferorDetails25092016
      {
         public string SPName = "SPTransferorDetails25092016";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPaymentReceiptFor2RPrint17032017
      public class SPSelectPaymentReceiptFor2RPrint17032017
      {
         public string SPName = "SPSelectPaymentReceiptFor2RPrint17032017";
         public int ApplicationFormId = 0;
         public int TwoRPlotId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertActionTransactionEntryGrievance
      public class SPInsertActionTransactionEntryGrievance
      {
         public string SPName = "SPInsertActionTransactionEntryGrievance";
         public int ActionId = 0;
         public int ApplicationFormId = 1;
         public int ApplicationId = 2;
         public int Remark = 3;
         public int createdBy = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertTransactionNo
      public class SPInsertTransactionNo
      {
         public string SPName = "SPInsertTransactionNo";
         public int TxId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPRMForwardToDMLeaseDocument
      public class SPRMForwardToDMLeaseDocument
      {
         public string SPName = "SPRMForwardToDMLeaseDocument";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
         public int BackwardRemark = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateWaterSupplyApplicationDemandDraftByApplicant
      public class SPUpdateWaterSupplyApplicationDemandDraftByApplicant
      {
         public string SPName = "SPUpdateWaterSupplyApplicationDemandDraftByApplicant";
         public int ApplicationFormId = 0;
         public int AssignedActionId = 1;
         public int NEFTorRTGSDocument = 2;
         public int UserId = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPlinthCertificationPaymentDetailByTxId
      public class SPSelectPlinthCertificationPaymentDetailByTxId
      {
         public string SPName = "SPSelectPlinthCertificationPaymentDetailByTxId";
         public int TxId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPShowDataForPriceAllotment
      public class SPShowDataForPriceAllotment
      {
         public string SPName = "SPShowDataForPriceAllotment";
         public int RegionId = 0;
         public int PlotTypeId = 1;
         public int FinancialYear = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPRMBackwardToHelpdeskTwoRApplication
      public class SPRMBackwardToHelpdeskTwoRApplication
      {
         public string SPName = "SPRMBackwardToHelpdeskTwoRApplication";
         public int ApplicationFormId = 0;
         public int AssignedRoleId = 1;
         public int ModifiedBy = 2;
         public int RMIncompleteCount = 3;
         public int BackwardRemark = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPMISTransfer25092016
      public class SPMISTransfer25092016
      {
         public string SPName = "SPMISTransfer25092016";
         public int RegionID = 0;
         public int EstateID = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteApplicationMasterByApplicationId
      public class SPDeleteApplicationMasterByApplicationId
      {
         public string SPName = "SPDeleteApplicationMasterByApplicationId";
         public int ApplicationId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPCheckUniqueTransactionNo
      public class SPCheckUniqueTransactionNo
      {
         public string SPName = "SPCheckUniqueTransactionNo";
         public int TxId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpFindRollByuseridforAmalgamation
      public class SpFindRollByuseridforAmalgamation
      {
         public string SPName = "SpFindRollByuseridforAmalgamation";
         public int ApplicationTypeId = 0;
         public int Branchid = 1;
         public int UserId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPRMForwardToHelpdeskQueryApplication
      public class SPRMForwardToHelpdeskQueryApplication
      {
         public string SPName = "SPRMForwardToHelpdeskQueryApplication";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
         public int BackwardRemark = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateWaterSupplyApplicationForm
      public class SPUpdateWaterSupplyApplicationForm
      {
         public string SPName = "SPUpdateWaterSupplyApplicationForm";
         public int Operation = 0;
         public int ApplicationFormId = 1;
         public int ApplicantName = 2;
         public int DescriptionofPremises = 3;
         public int MinimumMaximumQuantityofWater = 4;
         public int WaterQuantityGPCBOrderNoNOC = 5;
         public int ConsentToEstablishDoc = 6;
         public int WaterQuantityGPCBDate = 7;
         public int WaterQuantityM3Day = 8;
         public int IndustrialPurposeWaterQuantityM3day = 9;
         public int DomesticPurposeWaterQuantityM3day = 10;
         public int OthersWaterQuantityM3day = 11;
         public int DateofPossessionField = 12;
         public int SignedApplicationFormDoc = 13;
         public int CCAfromGpcbDoc = 14;
         public int SelfDeclarationNonPollutingIndustryDoc = 15;
         public int BuildingPlanDoc = 16;
         public int LicenseAgreementDoc = 17;
         public int PossessionReceiptDoc = 18;
         public int OCAletterDoc = 19;
         public int RectificationDetailDoc = 20;
         public int PowerOfAttorneyDoc = 21;
         public int SignedAgreementDoc = 22;
         public int IfUnitPolluted = 23;
         public int ApplicantDocumentList = 24;
         public int ModifiedBy = 25;
         public int FinaltransferOrder = 26;
         public int Plotutilisation = 27;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region UpdateROUModulebyApplicationFormId
      public class UpdateROUModulebyApplicationFormId
      {
         public string SPName = "UpdateROUModulebyApplicationFormId";
         public int Mode = 0;
         public int ApplicationFormId = 1;
         public int IsBankSecurityCopyUploaded = 2;
         public int DocBankSecurityCopy = 3;
         public int PaymentType = 4;
         public int ActionId = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteTwoRTranscByApplicationFormId
      public class SPDeleteTwoRTranscByApplicationFormId
      {
         public string SPName = "SPDeleteTwoRTranscByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpTransferApplicationRemarksHistory25092016
      public class SpTransferApplicationRemarksHistory25092016
      {
         public string SPName = "SpTransferApplicationRemarksHistory25092016";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTwoRQueryDocument01092016
      public class SPSelectTwoRQueryDocument01092016
      {
         public string SPName = "SPSelectTwoRQueryDocument01092016";
         public int AplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpViewTransferDocumentForApplicant
      public class SpViewTransferDocumentForApplicant
      {
         public string SPName = "SpViewTransferDocumentForApplicant";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateApplicationMaster
      public class SPInsertUpdateApplicationMaster
      {
         public string SPName = "SPInsertUpdateApplicationMaster";
         public int ApplicationId = 0;
         public int Application = 1;
         public int UserId = 2;
         public int IsActive = 3;
         public int Operation = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectAmalgamationModuleHOFlowUserRoleCount
      public class SPSelectAmalgamationModuleHOFlowUserRoleCount
      {
         public string SPName = "SPSelectAmalgamationModuleHOFlowUserRoleCount";
         public int BranchId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPRMOnHoldApplication
      public class SPRMOnHoldApplication
      {
         public string SPName = "SPRMOnHoldApplication";
         public int ApplicationFormId = 0;
         public int ModifiedBy = 1;
         public int BackwardRemark = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetPendingDayAtGIDCendForTransfer03062017
      public class SPGetPendingDayAtGIDCendForTransfer03062017
      {
         public string SPName = "SPGetPendingDayAtGIDCendForTransfer03062017";
         public int ApplicationFormId = 0;
         public int Days = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateWaterSupplyApplicationFormApplicantQuery
      public class SPUpdateWaterSupplyApplicationFormApplicantQuery
      {
         public string SPName = "SPUpdateWaterSupplyApplicationFormApplicantQuery";
         public int Operation = 0;
         public int ApplicationFormId = 1;
         public int QueryAnswerApplicantLine1 = 2;
         public int QueryAnswerApplicantLine2 = 3;
         public int QueryAnswerApplicantLine3 = 4;
         public int QueryAnswerApplicantLine4 = 5;
         public int QueryAnswerApplicantLine5 = 6;
         public int SignedApplicationFormDoc = 7;
         public int CCAfromGpcbDoc = 8;
         public int SelfDeclarationNonPollutingIndustryDoc = 9;
         public int BuildingPlanDoc = 10;
         public int LicenseAgreementDoc = 11;
         public int PossessionReceiptDoc = 12;
         public int OCAletterDoc = 13;
         public int RectificationDetailDoc = 14;
         public int PowerOfAttorneyDoc = 15;
         public int SignedAgreementDoc = 16;
         public int IfUnitPolluted = 17;
         public int ActionId = 18;
         public int ApplicantDocumentList = 19;
         public int ModifiedBy = 20;
         public int QueryDocumentXML = 21;
         public int Plotutilisation = 22;
         public int FinaltransferOrder = 23;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferPaymentAdminCharge
      public class SPSelectTransferPaymentAdminCharge
      {
         public string SPName = "SPSelectTransferPaymentAdminCharge";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectGrievanceApplicationCount
      public class SPSelectGrievanceApplicationCount
      {
         public string SPName = "SPSelectGrievanceApplicationCount";
         public int FromDate = 0;
         public int ToDate = 1;
         public int RegionId = 2;
         public int EstateId = 3;
         public int SubjectId = 4;
         public int Day = 5;
         public int RoleId = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPCheckUniqueTransactionReferenceNoforSubletting
      public class SPCheckUniqueTransactionReferenceNoforSubletting
      {
         public string SPName = "SPCheckUniqueTransactionReferenceNoforSubletting";
         public int TxId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectActionOfLeaseApplication
      public class SPSelectActionOfLeaseApplication
      {
         public string SPName = "SPSelectActionOfLeaseApplication";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferApplicationOtherDocuments
      public class SPSelectTransferApplicationOtherDocuments
      {
         public string SPName = "SPSelectTransferApplicationOtherDocuments";
         public int ApplicationFormId = 0;
         public int AssignedRoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateWaterSupplyApplicationForwardToApplicantForPayment
      public class SpUpdateWaterSupplyApplicationForwardToApplicantForPayment
      {
         public string SPName = "SpUpdateWaterSupplyApplicationForwardToApplicantForPayment";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int UserRoleId = 2;
         public int CurrentApplicationActionId = 3;
         public int CurrentApplicationStatusId = 4;
         public int AssignedRoleId = 5;
         public int AssignedActionId = 6;
         public int DemandNoteDocumentDEE = 7;
         public int AmountPayable = 8;
         public int PaymentRemarks = 9;
         public int ContributationCharges = 10;
         public int ThreeMonthsDeposit = 11;
         public int ConnectionCharges = 12;
         public int FormFees = 13;
         public int RoadCrossingCharges = 14;
         public int WATER_ACCHEAD_C = 15;
         public int WATER_ACC_M = 16;
         public int WATER_FROM_D = 17;
         public int WATER_TO_D = 18;
         public int WATER_ACC_NO = 19;
         public int WATER_SGST_A = 20;
         public int WATER_CGST_A = 21;
         public int WATER_ACC_N = 22;
         public int WATER_SGSTAmount = 23;
         public int WATER_CGSTAmount = 24;
         public int WATER_BaseAmount = 25;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectGeneralApplicationByReferenceno
      public class SPSelectGeneralApplicationByReferenceno
      {
         public string SPName = "SPSelectGeneralApplicationByReferenceno";
         public int ReferenceNo = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectBuildingCompletionApplicationByUserId
      public class SPSelectBuildingCompletionApplicationByUserId
      {
         public string SPName = "SPSelectBuildingCompletionApplicationByUserId";
         public int UserId = 0;
         public int mode = 1;
         public int BuildingPlanUI = 2;
         public int BuildingPlanDeptUniqueId = 3;
         public int BuildingPlanEODBApplicationId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectGrievanceApplicationListForReport
      public class SPSelectGrievanceApplicationListForReport
      {
         public string SPName = "SPSelectGrievanceApplicationListForReport";
         public int FromDate = 0;
         public int ToDate = 1;
         public int RegionId = 2;
         public int EstateId = 3;
         public int SubjectId = 4;
         public int StatusId = 5;
         public int Day = 6;
         public int RoleId = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SP_Invoice_08082017
      public class SP_Invoice_08082017
      {
         public string SPName = "SP_Invoice_08082017";
         public int ApplicationId = 0;
         public int FromDate = 1;
         public int ToDate = 2;
         public int InvoiceType = 3;
         public int UserId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectApplicationMasterByApplication
      public class SPSelectApplicationMasterByApplication
      {
         public string SPName = "SPSelectApplicationMasterByApplication";
         public int Application = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateReceivedFileTrackingForTransfer
      public class SPUpdateReceivedFileTrackingForTransfer
      {
         public string SPName = "SPUpdateReceivedFileTrackingForTransfer";
         public int ApplicationId = 0;
         public int ApplicationFormId = 1;
         public int BarcodeNo = 2;
         public int Remarks = 3;
         public int ModifiedBy = 4;
         public int RoleId = 5;
         public int IsBarcodeFacility = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectApplicantEmailByApplicationFormId
      public class SPSelectApplicantEmailByApplicationFormId
      {
         public string SPName = "SPSelectApplicantEmailByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertCRDailyApplicationDetails_old
      public class SPInsertCRDailyApplicationDetails_old
      {
         public string SPName = "SPInsertCRDailyApplicationDetails_old";
         public int ApplicationId = 0;
         public int ApplicationFormId = 1;
         public int AppForwardDate = 2;
         public int AppActualForwardDate = 3;
         public int ActionId = 4;
         public int AssignRoleId = 5;
         public int EstateId = 6;
         public int Remark = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetPendingDayFromLastActionAtGIDCendForTransferModule05062017
      public class SPGetPendingDayFromLastActionAtGIDCendForTransferModule05062017
      {
         public string SPName = "SPGetPendingDayFromLastActionAtGIDCendForTransferModule05062017";
         public int ApplicationFormId = 0;
         public int Days = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateWaterSupplyApplicationReleaseConnection
      public class SpUpdateWaterSupplyApplicationReleaseConnection
      {
         public string SPName = "SpUpdateWaterSupplyApplicationReleaseConnection";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int UserRoleId = 2;
         public int CurrentApplicationActionId = 3;
         public int CurrentApplicationStatusId = 4;
         public int AssignedRoleId = 5;
         public int AssignedActionId = 6;
         public int OnlineFeesSubmissionReceipt = 7;
         public int SignedAgreementDocument = 8;
         public int Otherdocuments = 9;
         public int Remarks = 10;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdatePaymentDetailsPlinthCertification
      public class SPUpdatePaymentDetailsPlinthCertification
      {
         public string SPName = "SPUpdatePaymentDetailsPlinthCertification";
         public int ApplicationFormId = 0;
         public int TxId = 1;
         public int TxRefNo = 2;
         public int TxStatus = 3;
         public int TxAmount = 4;
         public int TxMsg = 5;
         public int pgTxnNo = 6;
         public int issuerRefNo = 7;
         public int authIdCode = 8;
         public int firstName = 9;
         public int lastName = 10;
         public int pgRespCode = 11;
         public int addressZip = 12;
         public int signature = 13;
         public int Head = 14;
         public int paymentMode = 15;
         public int TxGateway = 16;
         public int cardType = 17;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpInsertupdateNotingMaster
      public class SpInsertupdateNotingMaster
      {
         public string SPName = "SpInsertupdateNotingMaster";
         public int Mode = 0;
         public int ApplicationId = 1;
         public int ApplicationFormId = 2;
         public int ReferenceNo = 3;
         public int RoleId = 4;
         public int UserId = 5;
         public int Note = 6;
         public int Id = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectAmalgamationModuleDocumentTransactionByApplicationFormId
      public class SPSelectAmalgamationModuleDocumentTransactionByApplicationFormId
      {
         public string SPName = "SPSelectAmalgamationModuleDocumentTransactionByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertClockMaster
      public class SPInsertClockMaster
      {
         public string SPName = "SPInsertClockMaster";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
         public int ClockStart = 2;
         public int ClockPause = 3;
         public int ClockStop = 4;
         public int CreatedBy = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPTransferLetterByUserId25092016
      public class SPTransferLetterByUserId25092016
      {
         public string SPName = "SPTransferLetterByUserId25092016";
         public int UserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPlotShedByPlotShedNoDetails
      public class SPSelectPlotShedByPlotShedNoDetails
      {
         public string SPName = "SPSelectPlotShedByPlotShedNoDetails";
         public int PlotShedNo = 0;
         public int EstateId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectGrievanceApplicationListForReportForDepartment
      public class SPSelectGrievanceApplicationListForReportForDepartment
      {
         public string SPName = "SPSelectGrievanceApplicationListForReportForDepartment";
         public int FromDate = 0;
         public int ToDate = 1;
         public int DeptName = 2;
         public int SubjectId = 3;
         public int StatusId = 4;
         public int Day = 5;
         public int RegionId = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectApplicationMasterByApplicationId
      public class SPSelectApplicationMasterByApplicationId
      {
         public string SPName = "SPSelectApplicationMasterByApplicationId";
         public int ApplicationId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferDAByTransferDAId
      public class SPSelectTransferDAByTransferDAId
      {
         public string SPName = "SPSelectTransferDAByTransferDAId";
         public int TransferDAId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpWaterSupplyApplicationRemarksHistory
      public class SpWaterSupplyApplicationRemarksHistory
      {
         public string SPName = "SpWaterSupplyApplicationRemarksHistory";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateAmalgamationPlotDetailsById
      public class SPUpdateAmalgamationPlotDetailsById
      {
         public string SPName = "SPUpdateAmalgamationPlotDetailsById";
         public int Id = 0;
         public int ApplicationFormid = 1;
         public int modifiedBy = 2;
         public int LicenseAgreementDate = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSurrenderDEEPhotoDetailByApplicationFormId
      public class SPSelectSurrenderDEEPhotoDetailByApplicationFormId
      {
         public string SPName = "SPSelectSurrenderDEEPhotoDetailByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectApplicantLeaseDeedDocumentList
      public class SPSelectApplicantLeaseDeedDocumentList
      {
         public string SPName = "SPSelectApplicantLeaseDeedDocumentList";
         public int DocumentList = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferDAByApplicationFormId
      public class SPSelectTransferDAByApplicationFormId
      {
         public string SPName = "SPSelectTransferDAByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateStateFinancePricebyId
      public class SPUpdateStateFinancePricebyId
      {
         public string SPName = "SPUpdateStateFinancePricebyId";
         public int id = 0;
         public int Price = 1;
         public int CreatedBy = 2;
         public int CreatedOn = 3;
         public int ModifiedBy = 4;
         public int ModifiedOn = 5;
         public int IsActive = 6;
         public int param = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPAmalgamationApplicationSummaryReportNew
      public class SPAmalgamationApplicationSummaryReportNew
      {
         public string SPName = "SPAmalgamationApplicationSummaryReportNew";
         public int BeforeAfter = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdatePaymentTable
      public class SPUpdatePaymentTable
      {
         public string SPName = "SPUpdatePaymentTable";
         public int MerchantId = 0;
         public int TxId = 1;
         public int TxRefNo = 2;
         public int BankRefNo = 3;
         public int TxAmount = 4;
         public int BankID = 5;
         public int CardBin = 6;
         public int TxnType = 7;
         public int CurrencyName = 8;
         public int ItemcOde = 9;
         public int securityType = 10;
         public int securityId = 11;
         public int surchargeAmount = 12;
         public int TxnDate = 13;
         public int TxStatus = 14;
         public int SettlementType = 15;
         public int ShortCode = 16;
         public int Additionalinfo2 = 17;
         public int Additionalinfo3 = 18;
         public int Additionalinfo4 = 19;
         public int Additionalinfo5 = 20;
         public int Additionalinfo6 = 21;
         public int Additionalinfo7 = 22;
         public int ErrorStatus = 23;
         public int ErrorDescription = 24;
         public int CheckSum = 25;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferDAIdByApplicationFormId
      public class SPSelectTransferDAIdByApplicationFormId
      {
         public string SPName = "SPSelectTransferDAIdByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetPendingDayFromLastActionAtGIDCendForAmalgamationModule
      public class SPGetPendingDayFromLastActionAtGIDCendForAmalgamationModule
      {
         public string SPName = "SPGetPendingDayFromLastActionAtGIDCendForAmalgamationModule";
         public int ApplicationFormId = 0;
         public int Days = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectROUApplicationPaymentDetailByApplicationFormId
      public class SPSelectROUApplicationPaymentDetailByApplicationFormId
      {
         public string SPName = "SPSelectROUApplicationPaymentDetailByApplicationFormId";
         public int ApplicationFormId = 0;
         public int PaymentFor = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectROUModuleOtherQuery
      public class SPSelectROUModuleOtherQuery
      {
         public string SPName = "SPSelectROUModuleOtherQuery";
         public int ApplicationFormId = 0;
         public int AssignedRoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertCRDailyApplicationDetailsForTransfer17022018
      public class SPInsertCRDailyApplicationDetailsForTransfer17022018
      {
         public string SPName = "SPInsertCRDailyApplicationDetailsForTransfer17022018";
         public int ApplicationId = 0;
         public int ApplicationFormId = 1;
         public int AppForwardDate = 2;
         public int AppActualForwardDate = 3;
         public int ActionId = 4;
         public int AssignRoleId = 5;
         public int EstateId = 6;
         public int Remark = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTrasferorDetailsByApplicationFormId
      public class SPSelectTrasferorDetailsByApplicationFormId
      {
         public string SPName = "SPSelectTrasferorDetailsByApplicationFormId";
         public int ApplicationFormId = 0;
         public int TransferorName = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPROUPaymentVerification
      public class SPROUPaymentVerification
      {
         public string SPName = "SPROUPaymentVerification";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int UserRoleId = 2;
         public int CurrentApplicationActionId = 3;
         public int AssignedRoleId = 4;
         public int AssignedActionId = 5;
         public int ConcludingRemarks = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectCollateralPriceFor2RFORTransferByApplicationFormId
      public class SPSelectCollateralPriceFor2RFORTransferByApplicationFormId
      {
         public string SPName = "SPSelectCollateralPriceFor2RFORTransferByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateGSTNoforBuildingPlanApprovalApplication
      public class SPUpdateGSTNoforBuildingPlanApprovalApplication
      {
         public string SPName = "SPUpdateGSTNoforBuildingPlanApprovalApplication";
         public int ApplicationFormId = 0;
         public int AlloteeGSTNo = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateSublettingModuleforGenerateFO_OutwardNo
      public class SpUpdateSublettingModuleforGenerateFO_OutwardNo
      {
         public string SPName = "SpUpdateSublettingModuleforGenerateFO_OutwardNo";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectRouApplicationPaymentDetailByTxId
      public class SPSelectRouApplicationPaymentDetailByTxId
      {
         public string SPName = "SPSelectRouApplicationPaymentDetailByTxId";
         public int TxId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPTransferModuleInsertFTOCondition
      public class SPTransferModuleInsertFTOCondition
      {
         public string SPName = "SPTransferModuleInsertFTOCondition";
         public int ApplicationFormId = 0;
         public int FTOCondition = 1;
         public int CreatedBy = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteDocumentMasterByDocumentId
      public class SPDeleteDocumentMasterByDocumentId
      {
         public string SPName = "SPDeleteDocumentMasterByDocumentId";
         public int DocumentId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectIncompleteTwoRApplicationDocumentRpt
      public class SPSelectIncompleteTwoRApplicationDocumentRpt
      {
         public string SPName = "SPSelectIncompleteTwoRApplicationDocumentRpt";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateTransferDA
      public class SPUpdateTransferDA
      {
         public string SPName = "SPUpdateTransferDA";
         public int ApplicationFormId = 0;
         public int OCADate = 1;
         public int OCAArea = 2;
         public int OCAFile = 3;
         public int FieldBookDate = 4;
         public int FieldBookArea = 5;
         public int FieldBookFile = 6;
         public int PossessionDate = 7;
         public int PossessionArea = 8;
         public int PossessionFile = 9;
         public int PossessionReceiptDate = 10;
         public int PossessionReceiptArea = 11;
         public int PossessionReceiptFile = 12;
         public int MoratoriumPeriod = 13;
         public int MoratoriumDate = 14;
         public int LeaseDeedDate = 15;
         public int LeaseDeedArea = 16;
         public int LeaseDeedFile = 17;
         public int IsOCAPresentTransferorGIDCRecord = 18;
         public int IsTransferDoneEarlier = 19;
         public int IsTransferDoneEarlierInformal = 20;
         public int TransferDoneEarlierInformalDetails = 21;
         public int IsPlotSubDividedOCALastFTO = 22;
         public int IsSubDivisionInCorporatedDDPlan = 23;
         public int SubDivisionInCorporatedDDPlanDetails = 24;
         public int IsSubLettingDone = 25;
         public int SubLettingOrderDate = 26;
         public int SubLettingCompletionDate = 27;
         public int IsSubLettingFeesCollected = 28;
         public int SubLettingPurpose = 29;
         public int IsAmalgamationDDPlan = 30;
         public int AmalgamationDDPlanOrderDate = 31;
         public int AmalgamationDDPlanIncorporationDate = 32;
         public int AmalgamationDDPlanRevisedPlotNo = 33;
         public int AmalgamationDDPlanRevisedArea = 34;
         public int IsProposedTransferAccepted = 35;
         public int ProposedTransferAcceptedRejectionReason = 36;
         public int ProposedTransferAcceptedRejectionOtherReason = 37;
         public int IsPropertyUnderMoratoriumPeriod = 38;
         public int IsPropertyUtilized = 39;
         public int IsTransferProposalUnderExitPolicy = 40;
         public int IsProposalUnderExitPolicyFormal = 41;
         public int IsProposalUnderExitPolicyFormalRemarks = 42;
         public int IsPropertyLateUtilized = 43;
         public int IsTimeLimitExtensionGranted = 44;
         public int TimeLimitExtensionGrantedOrderDate = 45;
         public int TimeLimitExtensionGrantedUptoDate = 46;
         public int IsPossessionGivenInTime = 47;
         public int PossessionGivenInTimeDate = 48;
         public int IsUnitClosedAfterUtilization = 49;
         public int IsProposedTransferIsFormal = 50;
         public int PeriodUtilizationTransfer = 51;
         public int ModifiedBy = 52;
         public int SectionType = 53;
         public int TransferDAId = 54;
         public int TransferDAFees = 55;
         public int UnitClosedClosureDate = 56;
         public int UnitClosedClosurePeriod = 57;
         public int ClosurePenalty = 58;
         public int NUPenalty = 59;
         public int TotalPaybleAmount = 60;
         public int IsChargesRemain = 61;
         public int TypeOfChargeRemain = 62;
         public int ChargeRemainAmt = 63;
         public int DateOfLateUtilized = 64;
         public int DateOfPartialutilization = 65;
         public int DateUtilized = 66;
         public int LatePossessionReson = 67;
         public int OCATransferDate = 68;
         public int TypeofTransferRemarksAM = 69;
         public int TypeofTransferRemarksRM = 70;
         public int IsTransferFeeRecovered = 71;
         public int TFRecoveredAmount = 72;
         public int TFRecoveredDate = 73;
         public int ISNUPenaltyRecovered = 74;
         public int NURecoveredAmount = 75;
         public int NURecoveredDate = 76;
         public int ConcessionRecoveredAmount = 77;
         public int ConcessionRecoveredInterest = 78;
         public int LicenseAgreementDate = 79;
         public int IsCommercialPlot = 80;
         public int NUACCHEAD_C = 81;
         public int NUACC_M = 82;
         public int NUFROM_D = 83;
         public int NUTO_D = 84;
         public int NUACC_NO = 85;
         public int NUSGST_A = 86;
         public int NUCGST_A = 87;
         public int NUACC_N = 88;
         public int NUSGSTAmount = 89;
         public int NUCGSTAmount = 90;
         public int TFACCHEAD_C = 91;
         public int TFACC_M = 92;
         public int TFFROM_D = 93;
         public int TFTO_D = 94;
         public int TFACC_NO = 95;
         public int TFSGST_A = 96;
         public int TFCGST_A = 97;
         public int TFACC_N = 98;
         public int TFSGSTAmount = 99;
         public int TFCGSTAmount = 100;
         public int UtilizationBy = 101;
         public int AddTransferFees = 102;
         public int AddTFSGSTAmount = 103;
         public int AddTFCGSTAmount = 104;
         public int AddTFACCHEAD_C = 105;
         public int AddTFACC_M = 106;
         public int AddTFFROM_D = 107;
         public int AddTFTO_D = 108;
         public int AddTFACC_NO = 109;
         public int AddTFSGST_A = 110;
         public int AddTFCGST_A = 111;
         public int AddTFACC_N = 112;
         public int PartialPeriodUseTable = 113;
         public int IsNUPenaltyApplicable = 114;
         public int UtilizedNUDatesTable = 115;
         public int UtilizedNUTotalPeriod = 116;
         public int IsUnderDeathCase = 117;
         public int IsConstructionLessThan20 = 118;
         public int DateOfBuildingPlanApproved = 119;
         public int DateOfPossessionToBeTaken = 120;
         public int TFPercentage = 121;
         public int NUPercentage = 122;
         public int AddTFPercentage = 123;
         public int PremiumPrice = 124;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDelayDesignation
      public class SPDelayDesignation
      {
         public string SPName = "SPDelayDesignation";
         public int ApplicationId = 0;
         public int RegionId = 1;
         public int ApplicationFormId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region GetAmalgationSummaryReportbyStatusNew
      public class GetAmalgationSummaryReportbyStatusNew
      {
         public string SPName = "GetAmalgationSummaryReportbyStatusNew";
         public int REGIONID = 0;
         public int ACTIONID = 1;
         public int ActionType = 2;
         public int BeforeAfter = 3;
         public int OldApplicationStatusId = 4;
         public int PTOIssueCMD = 5;
         public int StatusId = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectBuildingPlanApprovalApplicationInvoice
      public class SPSelectBuildingPlanApprovalApplicationInvoice
      {
         public string SPName = "SPSelectBuildingPlanApprovalApplicationInvoice";
         public int ApplicationFormId = 0;
         public int UserId = 1;
         public int TxId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateSurrenderAODetails
      public class SPInsertUpdateSurrenderAODetails
      {
         public string SPName = "SPInsertUpdateSurrenderAODetails";
         public int ActionName = 0;
         public int ApplicationFormId = 1;
         public int EstateName = 2;
         public int DateOfAllotment = 3;
         public int Party = 4;
         public int PlotNo = 5;
         public int PlotArea = 6;
         public int PPAtTimeOFAllotment = 7;
         public int PPAtPresent = 8;
         public int Difference = 9;
         public int Difference2 = 10;
         public int DelayOfferInterest = 11;
         public int NUPanelty = 12;
         public int LegalCharges = 13;
         public int OtherCharges = 14;
         public int BankCharges = 15;
         public int TotalOtherDues = 16;
         public int Interest = 17;
         public int IDP = 18;
         public int DuesOfRevenueCharges = 19;
         public int TotalDues = 20;
         public int NetRecoverableAmt = 21;
         public int PaidByTheParty = 22;
         public int RefundableAmt = 23;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertROU
      public class SPInsertROU
      {
         public string SPName = "SPInsertROU";
         public int ReferenceNo = 0;
         public int ApplicantName = 1;
         public int ApplicantLandline = 2;
         public int ApplicantMobileNo = 3;
         public int ApplicantEmailId = 4;
         public int ApplicantIdentityProof = 5;
         public int RegisteredOfficeAddress = 6;
         public int IsAllotteeOfGIDC = 7;
         public int RegionId = 8;
         public int EstateId = 9;
         public int TypeOfPlotShed = 10;
         public int PlotShedNo = 11;
         public int PlotArea = 12;
         public int DateofAllotment = 13;
         public int IsChemical = 14;
         public int NameofAllottee = 15;
         public int ApplicantConstitutionType = 16;
         public int NameOfContractor = 17;
         public int ContractorLandline = 18;
         public int ContractorMobile = 19;
         public int ContractorEmailId = 20;
         public int ContractorOfficeAddress = 21;
         public int StateConstitutionId = 22;
         public int StateModeofLaying = 23;
         public int StatetypeOfLine = 24;
         public int Statepurposeofproject = 25;
         public int LayingLine = 26;
         public int StateLocation = 27;
         public int PlotLayingLine = 28;
         public int SinglePlotNo = 29;
         public int SinglePlotPartyName = 30;
         public int MultiplePlotNoStart = 31;
         public int MultiplePlotNoEnd = 32;
         public int Depth = 33;
         public int Length = 34;
         public int TotalROU = 35;
         public int MapDetails = 36;
         public int OtherDocument = 37;
         public int IsActive = 38;
         public int CreatedBy = 39;
         public int ApplicationSubmissionDate = 40;
         public int SectionType = 41;
         public int IdentityProofOfOfficeYes = 42;
         public int RegisteredOfficeAddressYes = 43;
         public int IdentityProofOfOfficeNo = 44;
         public int NameOfAuthorizedPerson = 45;
         public int IdentityProofOfPerson = 46;
         public int OtherState = 47;
         public int ApprovalLetter = 48;
         public int ApplicantConstitutionType1 = 49;
         public int StatetypeOfLineOther = 50;
         public int UIDNo = 51;
         public int NameOfEstateId = 52;
         public int AdminKKC = 53;
         public int AdminSBC = 54;
         public int AdminST = 55;
         public int AdminCharge = 56;
         public int AdminTotalCharge = 57;
         public int AccountDues = 58;
         public int WaterDues = 59;
         public int OtherDues = 60;
         public int DrainageDues = 61;
         public int NDCAccount = 62;
         public int NDCEngineering = 63;
         public int PartyCode = 64;
         public int OSINST_A = 65;
         public int OSIDPPI_A = 66;
         public int OSSC_A = 67;
         public int OSSC_ST = 68;
         public int OSSC_EC = 69;
         public int OSSWCSC = 70;
         public int OSSCKKC = 71;
         public int OSNAA_A = 72;
         public int OSNAA_ST = 73;
         public int OSNAA_EC = 74;
         public int OSSWCNAA = 75;
         public int OSNAAKKC = 76;
         public int OSLR_A = 77;
         public int OSLR_ST = 78;
         public int OSLR_EC = 79;
         public int OSSWCLR = 80;
         public int OSLRKKC = 81;
         public int OSIR_A = 82;
         public int OSIUF_A = 83;
         public int OSIUF_ST = 84;
         public int OSIUF_EC = 85;
         public int OSFULLPAYMENT_A = 86;
         public int IsFromMobileApp = 87;
         public int LRCOSINST_A = 88;
         public int LRCOSIDP_A = 89;
         public int SGSTAmount = 90;
         public int CGSTAmount = 91;
         public int ACCHEAD_C = 92;
         public int ACC_M = 93;
         public int FROM_D = 94;
         public int TO_D = 95;
         public int ACC_NO = 96;
         public int SGST_A = 97;
         public int CGST_A = 98;
         public int ACC_N = 99;
         public int AC_SGSTAmount = 100;
         public int AC_CGSTAmount = 101;
         public int AC_ACCHEAD_C = 102;
         public int AC_ACC_M = 103;
         public int AC_FROM_D = 104;
         public int AC_TO_D = 105;
         public int AC_ACC_NO = 106;
         public int AC_SGST_A = 107;
         public int AC_CGST_A = 108;
         public int AC_ACC_N = 109;
         public int EN_SGSTAmount = 110;
         public int EN_CGSTAmount = 111;
         public int EN_ACCHEAD_C = 112;
         public int EN_ACC_M = 113;
         public int EN_FROM_D = 114;
         public int EN_TO_D = 115;
         public int EN_ACC_NO = 116;
         public int EN_SGST_A = 117;
         public int EN_CGST_A = 118;
         public int EN_ACC_N = 119;
         public int SC_SGSTAmount = 120;
         public int SC_CGSTAmount = 121;
         public int SC_ACCHEAD_C = 122;
         public int SC_ACC_M = 123;
         public int SC_FROM_D = 124;
         public int SC_TO_D = 125;
         public int SC_ACC_NO = 126;
         public int SC_SGST_A = 127;
         public int SC_CGST_A = 128;
         public int SC_ACC_N = 129;
         public int SC_BaseAmount = 130;
         public int NAA_SGSTAmount = 131;
         public int NAA_CGSTAmount = 132;
         public int NAA_ACCHEAD_C = 133;
         public int NAA_ACC_M = 134;
         public int NAA_FROM_D = 135;
         public int NAA_TO_D = 136;
         public int NAA_ACC_NO = 137;
         public int NAA_SGST_A = 138;
         public int NAA_CGST_A = 139;
         public int NAA_ACC_N = 140;
         public int NAA_BaseAmount = 141;
         public int LR_SGSTAmount = 142;
         public int LR_CGSTAmount = 143;
         public int LR_ACCHEAD_C = 144;
         public int LR_ACC_M = 145;
         public int LR_FROM_D = 146;
         public int LR_TO_D = 147;
         public int LR_ACC_NO = 148;
         public int LR_SGST_A = 149;
         public int LR_CGST_A = 150;
         public int LR_ACC_N = 151;
         public int LR_BaseAmount = 152;
         public int INT_SGSTAmount = 153;
         public int INT_CGSTAmount = 154;
         public int INT_ACCHEAD_C = 155;
         public int INT_ACC_M = 156;
         public int INT_FROM_D = 157;
         public int INT_TO_D = 158;
         public int INT_ACC_NO = 159;
         public int INT_SGST_A = 160;
         public int INT_CGST_A = 161;
         public int INT_ACC_N = 162;
         public int INT_BaseAmount = 163;
         public int SC_OS_CGST = 164;
         public int SC_OS_SGST = 165;
         public int NAA_OS_CGST = 166;
         public int NAA_OS_SGST = 167;
         public int LR_OS_CGST = 168;
         public int LR_OS_SGST = 169;
         public int INTREV_OS_CGST = 170;
         public int INTREV_OS_SGST = 171;
         public int IsSEZ = 172;
         public int REVINT_CSGST_OS = 173;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferModuleFTOConditionsByApplicationFormId
      public class SPSelectTransferModuleFTOConditionsByApplicationFormId
      {
         public string SPName = "SPSelectTransferModuleFTOConditionsByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectAmalgamationTechnicalScrutinyByApplicationFormId
      public class SPSelectAmalgamationTechnicalScrutinyByApplicationFormId
      {
         public string SPName = "SPSelectAmalgamationTechnicalScrutinyByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateDocumentMaster
      public class SPInsertUpdateDocumentMaster
      {
         public string SPName = "SPInsertUpdateDocumentMaster";
         public int DocumentId = 0;
         public int Document = 1;
         public int ApplicationId = 2;
         public int UserId = 3;
         public int IsActive = 4;
         public int Operation = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectLeaseApplicationByApplicationFormId
      public class SPSelectLeaseApplicationByApplicationFormId
      {
         public string SPName = "SPSelectLeaseApplicationByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertTransferDA
      public class SPInsertTransferDA
      {
         public string SPName = "SPInsertTransferDA";
         public int ApplicationFormId = 0;
         public int OCADate = 1;
         public int OCAArea = 2;
         public int OCAFile = 3;
         public int FieldBookDate = 4;
         public int FieldBookArea = 5;
         public int FieldBookFile = 6;
         public int PossessionDate = 7;
         public int PossessionArea = 8;
         public int PossessionFile = 9;
         public int PossessionReceiptDate = 10;
         public int PossessionReceiptArea = 11;
         public int PossessionReceiptFile = 12;
         public int MoratoriumPeriod = 13;
         public int MoratoriumDate = 14;
         public int LeaseDeedDate = 15;
         public int LeaseDeedArea = 16;
         public int LeaseDeedFile = 17;
         public int IsOCAPresentTransferorGIDCRecord = 18;
         public int IsTransferDoneEarlier = 19;
         public int IsTransferDoneEarlierInformal = 20;
         public int TransferDoneEarlierInformalDetails = 21;
         public int IsPlotSubDividedOCALastFTO = 22;
         public int IsSubDivisionInCorporatedDDPlan = 23;
         public int SubDivisionInCorporatedDDPlanDetails = 24;
         public int IsSubLettingDone = 25;
         public int SubLettingOrderDate = 26;
         public int SubLettingCompletionDate = 27;
         public int IsSubLettingFeesCollected = 28;
         public int SubLettingPurpose = 29;
         public int IsAmalgamationDDPlan = 30;
         public int AmalgamationDDPlanOrderDate = 31;
         public int AmalgamationDDPlanIncorporationDate = 32;
         public int AmalgamationDDPlanRevisedPlotNo = 33;
         public int AmalgamationDDPlanRevisedArea = 34;
         public int IsProposedTransferAccepted = 35;
         public int ProposedTransferAcceptedRejectionReason = 36;
         public int ProposedTransferAcceptedRejectionOtherReason = 37;
         public int IsPropertyUnderMoratoriumPeriod = 38;
         public int IsPropertyUtilized = 39;
         public int IsTransferProposalUnderExitPolicy = 40;
         public int IsProposalUnderExitPolicyFormal = 41;
         public int IsProposalUnderExitPolicyFormalRemarks = 42;
         public int IsPropertyLateUtilized = 43;
         public int IsTimeLimitExtensionGranted = 44;
         public int TimeLimitExtensionGrantedOrderDate = 45;
         public int TimeLimitExtensionGrantedUptoDate = 46;
         public int IsPossessionGivenInTime = 47;
         public int PossessionGivenInTimeDate = 48;
         public int IsUnitClosedAfterUtilization = 49;
         public int IsProposedTransferIsFormal = 50;
         public int PeriodUtilizationTransfer = 51;
         public int CreatedBy = 52;
         public int SectionType = 53;
         public int TransferDAId = 54;
         public int TransferDAFees = 55;
         public int UnitClosedClosureDate = 56;
         public int UnitClosedClosurePeriod = 57;
         public int ClosurePenalty = 58;
         public int NUPenalty = 59;
         public int TotalPaybleAmount = 60;
         public int IsChargesRemain = 61;
         public int TypeOfChargeRemain = 62;
         public int ChargeRemainAmt = 63;
         public int DateOfLateUtilized = 64;
         public int DateOfPartialutilization = 65;
         public int DateUtilized = 66;
         public int LatePossessionReson = 67;
         public int OCATransferDate = 68;
         public int TypeofTransferRemarksAM = 69;
         public int TypeofTransferRemarksRM = 70;
         public int IsTransferFeeRecovered = 71;
         public int TFRecoveredAmount = 72;
         public int TFRecoveredDate = 73;
         public int ISNUPenaltyRecovered = 74;
         public int NURecoveredAmount = 75;
         public int NURecoveredDate = 76;
         public int ConcessionRecoveredAmount = 77;
         public int ConcessionRecoveredInterest = 78;
         public int LicenseAgreementDate = 79;
         public int IsCommercialPlot = 80;
         public int NUACCHEAD_C = 81;
         public int NUACC_M = 82;
         public int NUFROM_D = 83;
         public int NUTO_D = 84;
         public int NUACC_NO = 85;
         public int NUSGST_A = 86;
         public int NUCGST_A = 87;
         public int NUACC_N = 88;
         public int NUSGSTAmount = 89;
         public int NUCGSTAmount = 90;
         public int TFACCHEAD_C = 91;
         public int TFACC_M = 92;
         public int TFFROM_D = 93;
         public int TFTO_D = 94;
         public int TFACC_NO = 95;
         public int TFSGST_A = 96;
         public int TFCGST_A = 97;
         public int TFACC_N = 98;
         public int TFSGSTAmount = 99;
         public int TFCGSTAmount = 100;
         public int UtilizationBy = 101;
         public int AddTransferFees = 102;
         public int AddTFSGSTAmount = 103;
         public int AddTFCGSTAmount = 104;
         public int AddTFACCHEAD_C = 105;
         public int AddTFACC_M = 106;
         public int AddTFFROM_D = 107;
         public int AddTFTO_D = 108;
         public int AddTFACC_NO = 109;
         public int AddTFSGST_A = 110;
         public int AddTFCGST_A = 111;
         public int AddTFACC_N = 112;
         public int PartialPeriodUseTable = 113;
         public int IsNUPenaltyApplicable = 114;
         public int UtilizedNUDatesTable = 115;
         public int UtilizedNUTotalPeriod = 116;
         public int IsUnderDeathCase = 117;
         public int IsConstructionLessThan20 = 118;
         public int DateOfBuildingPlanApproved = 119;
         public int DateOfPossessionToBeTaken = 120;
         public int TFPercentage = 121;
         public int NUPercentage = 122;
         public int AddTFPercentage = 123;
         public int PremiumPrice = 124;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SP_SelectDocumentMasterDataForSubdivision
      public class SP_SelectDocumentMasterDataForSubdivision
      {
         public string SPName = "SP_SelectDocumentMasterDataForSubdivision";
         public int ApplicationFormId = 0;
         public int mode = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPApplicationDelayDayReport
      public class SPApplicationDelayDayReport
      {
         public string SPName = "SPApplicationDelayDayReport";
         public int ApplicationId = 0;
         public int RegionId = 1;
         public int FromDate = 2;
         public int ToDate = 3;
         public int ReferenceNo = 4;
         public int SearchId = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPaymentDetailsROUModuleForTxId
      public class SPSelectPaymentDetailsROUModuleForTxId
      {
         public string SPName = "SPSelectPaymentDetailsROUModuleForTxId";
         public int ApplicationFormId = 0;
         public int PaymentType = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferApplicationPaymentDetailByTxId
      public class SPSelectTransferApplicationPaymentDetailByTxId
      {
         public string SPName = "SPSelectTransferApplicationPaymentDetailByTxId";
         public int TxId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateROU
      public class SPUpdateROU
      {
         public string SPName = "SPUpdateROU";
         public int ApplicationFormId = 0;
         public int ApplicantName = 1;
         public int ApplicantLandline = 2;
         public int ApplicantMobileNo = 3;
         public int ApplicantEmailId = 4;
         public int ApplicantIdentityProof = 5;
         public int RegisteredOfficeAddress = 6;
         public int IsAllotteeOfGIDC = 7;
         public int RegionId = 8;
         public int EstateId = 9;
         public int TypeOfPlotShed = 10;
         public int PlotShedNo = 11;
         public int PlotArea = 12;
         public int DateofAllotment = 13;
         public int IsChemical = 14;
         public int NameofAllottee = 15;
         public int ApplicantConstitutionType = 16;
         public int NameOfContractor = 17;
         public int ContractorLandline = 18;
         public int ContractorMobile = 19;
         public int ContractorEmailId = 20;
         public int ContractorOfficeAddress = 21;
         public int StateConstitutionId = 22;
         public int StateModeofLaying = 23;
         public int StatetypeOfLine = 24;
         public int Statepurposeofproject = 25;
         public int LayingLine = 26;
         public int StateLocation = 27;
         public int PlotLayingLine = 28;
         public int SinglePlotNo = 29;
         public int SinglePlotPartyName = 30;
         public int MultiplePlotNoStart = 31;
         public int MultiplePlotNoEnd = 32;
         public int Depth = 33;
         public int Length = 34;
         public int TotalROU = 35;
         public int MapDetails = 36;
         public int OtherDocument = 37;
         public int IsActive = 38;
         public int CreatedBy = 39;
         public int ApplicationSubmissionDate = 40;
         public int SectionType = 41;
         public int IdentityProofOfOfficeYes = 42;
         public int RegisteredOfficeAddressYes = 43;
         public int IdentityProofOfOfficeNo = 44;
         public int NameOfAuthorizedPerson = 45;
         public int IdentityProofOfPerson = 46;
         public int OtherState = 47;
         public int ApprovalLetter = 48;
         public int ApplicantConstitutionType1 = 49;
         public int StatetypeOfLineOther = 50;
         public int UIDNo = 51;
         public int NameOfEstateId = 52;
         public int AdminKKC = 53;
         public int AdminSBC = 54;
         public int AdminST = 55;
         public int AdminCharge = 56;
         public int AdminTotalCharge = 57;
         public int AccountDues = 58;
         public int WaterDues = 59;
         public int OtherDues = 60;
         public int DrainageDues = 61;
         public int NDCAccount = 62;
         public int NDCEngineering = 63;
         public int PartyCode = 64;
         public int OSINST_A = 65;
         public int OSIDPPI_A = 66;
         public int OSSC_A = 67;
         public int OSSC_ST = 68;
         public int OSSC_EC = 69;
         public int OSSWCSC = 70;
         public int OSSCKKC = 71;
         public int OSNAA_A = 72;
         public int OSNAA_ST = 73;
         public int OSNAA_EC = 74;
         public int OSSWCNAA = 75;
         public int OSNAAKKC = 76;
         public int OSLR_A = 77;
         public int OSLR_ST = 78;
         public int OSLR_EC = 79;
         public int OSSWCLR = 80;
         public int OSLRKKC = 81;
         public int OSIR_A = 82;
         public int OSIUF_A = 83;
         public int OSIUF_ST = 84;
         public int OSIUF_EC = 85;
         public int OSFULLPAYMENT_A = 86;
         public int IsFromMobileApp = 87;
         public int LRCOSINST_A = 88;
         public int LRCOSIDP_A = 89;
         public int SGSTAmount = 90;
         public int CGSTAmount = 91;
         public int ACCHEAD_C = 92;
         public int ACC_M = 93;
         public int FROM_D = 94;
         public int TO_D = 95;
         public int ACC_NO = 96;
         public int SGST_A = 97;
         public int CGST_A = 98;
         public int ACC_N = 99;
         public int AC_SGSTAmount = 100;
         public int AC_CGSTAmount = 101;
         public int AC_ACCHEAD_C = 102;
         public int AC_ACC_M = 103;
         public int AC_FROM_D = 104;
         public int AC_TO_D = 105;
         public int AC_ACC_NO = 106;
         public int AC_SGST_A = 107;
         public int AC_CGST_A = 108;
         public int AC_ACC_N = 109;
         public int EN_SGSTAmount = 110;
         public int EN_CGSTAmount = 111;
         public int EN_ACCHEAD_C = 112;
         public int EN_ACC_M = 113;
         public int EN_FROM_D = 114;
         public int EN_TO_D = 115;
         public int EN_ACC_NO = 116;
         public int EN_SGST_A = 117;
         public int EN_CGST_A = 118;
         public int EN_ACC_N = 119;
         public int SC_SGSTAmount = 120;
         public int SC_CGSTAmount = 121;
         public int SC_ACCHEAD_C = 122;
         public int SC_ACC_M = 123;
         public int SC_FROM_D = 124;
         public int SC_TO_D = 125;
         public int SC_ACC_NO = 126;
         public int SC_SGST_A = 127;
         public int SC_CGST_A = 128;
         public int SC_ACC_N = 129;
         public int SC_BaseAmount = 130;
         public int NAA_SGSTAmount = 131;
         public int NAA_CGSTAmount = 132;
         public int NAA_ACCHEAD_C = 133;
         public int NAA_ACC_M = 134;
         public int NAA_FROM_D = 135;
         public int NAA_TO_D = 136;
         public int NAA_ACC_NO = 137;
         public int NAA_SGST_A = 138;
         public int NAA_CGST_A = 139;
         public int NAA_ACC_N = 140;
         public int NAA_BaseAmount = 141;
         public int LR_SGSTAmount = 142;
         public int LR_CGSTAmount = 143;
         public int LR_ACCHEAD_C = 144;
         public int LR_ACC_M = 145;
         public int LR_FROM_D = 146;
         public int LR_TO_D = 147;
         public int LR_ACC_NO = 148;
         public int LR_SGST_A = 149;
         public int LR_CGST_A = 150;
         public int LR_ACC_N = 151;
         public int LR_BaseAmount = 152;
         public int INT_SGSTAmount = 153;
         public int INT_CGSTAmount = 154;
         public int INT_ACCHEAD_C = 155;
         public int INT_ACC_M = 156;
         public int INT_FROM_D = 157;
         public int INT_TO_D = 158;
         public int INT_ACC_NO = 159;
         public int INT_SGST_A = 160;
         public int INT_CGST_A = 161;
         public int INT_ACC_N = 162;
         public int INT_BaseAmount = 163;
         public int SC_OS_CGST = 164;
         public int SC_OS_SGST = 165;
         public int NAA_OS_CGST = 166;
         public int NAA_OS_SGST = 167;
         public int LR_OS_CGST = 168;
         public int LR_OS_SGST = 169;
         public int INTREV_OS_CGST = 170;
         public int INTREV_OS_SGST = 171;
         public int IsSEZ = 172;
         public int REVINT_CSGST_OS = 173;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTwoRApplicationOfficeUserDetailsByRoleIdForEmail
      public class SPSelectTwoRApplicationOfficeUserDetailsByRoleIdForEmail
      {
         public string SPName = "SPSelectTwoRApplicationOfficeUserDetailsByRoleIdForEmail";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateTransferModuleFTOConditionsByFTOId
      public class SPUpdateTransferModuleFTOConditionsByFTOId
      {
         public string SPName = "SPUpdateTransferModuleFTOConditionsByFTOId";
         public int FTOConditionId = 0;
         public int ModifiedBy = 1;
         public int mode = 2;
         public int FTOCondition = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDAUpdateStatus
      public class SPDAUpdateStatus
      {
         public string SPName = "SPDAUpdateStatus";
         public int ApplicationFormId = 0;
         public int ApplicationStatusId = 1;
         public int LeaseDeedDate = 2;
         public int LeaseDeedOrder = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectLeaseApplicationDDByLeaseAppDDId
      public class SPSelectLeaseApplicationDDByLeaseAppDDId
      {
         public string SPName = "SPSelectLeaseApplicationDDByLeaseAppDDId";
         public int LeaseAppDDId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferModuleHOFlowUserByBranchAndRole
      public class SPSelectTransferModuleHOFlowUserByBranchAndRole
      {
         public string SPName = "SPSelectTransferModuleHOFlowUserByBranchAndRole";
         public int BranchId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPApplicationProcessReport
      public class SPApplicationProcessReport
      {
         public string SPName = "SPApplicationProcessReport";
         public int ApplicationId = 0;
         public int RegionId = 1;
         public int FromDate = 2;
         public int ToDate = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdatePaymentDetailsRou
      public class SPUpdatePaymentDetailsRou
      {
         public string SPName = "SPUpdatePaymentDetailsRou";
         public int ApplicationFormId = 0;
         public int TxId = 1;
         public int TxRefNo = 2;
         public int TxStatus = 3;
         public int TxAmount = 4;
         public int TxMsg = 5;
         public int pgTxnNo = 6;
         public int issuerRefNo = 7;
         public int authIdCode = 8;
         public int firstName = 9;
         public int lastName = 10;
         public int pgRespCode = 11;
         public int addressZip = 12;
         public int signature = 13;
         public int Head = 14;
         public int paymentMode = 15;
         public int TxGateway = 16;
         public int cardType = 17;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region M_SPUpdateTransfer
      public class M_SPUpdateTransfer
      {
         public string SPName = "M_SPUpdateTransfer";
         public int ApplicationFormId = 0;
         public int ApplicantName = 1;
         public int ApplicantAddress = 2;
         public int RegionId = 3;
         public int EstateId = 4;
         public int TypeOfPlotShed = 5;
         public int PlotShedNo = 6;
         public int PlotArea = 7;
         public int NameofIndividualTransferor = 8;
         public int CinTransferor = 9;
         public int AuthorisedPersonTransferor = 10;
         public int ContactNoTransferor = 11;
         public int EmailIdTransferor = 12;
         public int NameofIndividualTransferee = 13;
         public int CinTransferee = 14;
         public int AuthorisedPersonTransferee = 15;
         public int ContactNoTransferee = 16;
         public int EmailIdTransferee = 17;
         public int NameofAllottee = 18;
         public int AddressofAllottee = 19;
         public int DateofAllotment = 20;
         public int DateofAgreement = 21;
         public int DateofPossession = 22;
         public int DateofLeaseDeed = 23;
         public int DateofCorrigendum = 24;
         public int NameofTrasferee = 25;
         public int AddressofTrasferee = 26;
         public int NameofProduct = 27;
         public int NameofRawMaterials = 28;
         public int RequirementofRawMaterialsperMonth = 29;
         public int ProductioninMonth = 30;
         public int WaterRequirement1stYear = 31;
         public int WaterRequirement2ndYear = 32;
         public int WaterRequirement3rdYear = 33;
         public int WaterRequirement4thYear = 34;
         public int PowerRequirement1stYear = 35;
         public int PowerRequirement2ndYear = 36;
         public int PowerRequirement3rdYear = 37;
         public int PowerRequirement4thYear = 38;
         public int TotalInvestmentInyourProject = 39;
         public int NoofManPowerRequired = 40;
         public int FormalTrasferOrInFormalTrasfer = 41;
         public int ModifiedBy = 42;
         public int IsSubmitted = 43;
         public int DocumentXML = 44;
         public int tblTransferor = 45;
         public int tblTransferee = 46;
         public int ConstitutionTypeId = 47;
         public int DeathCaseTransfer = 48;
         public int DeathWillType = 49;
         public int DeathCaseTransferWill = 50;
         public int NOC2RPermissionTaken = 51;
         public int NOCAttachment = 52;
         public int TrasferGSFC = 53;
         public int TrasferCoOperative = 54;
         public int FTOName = 55;
         public int FTOFile = 56;
         public int ConstitutionTypeIdTransferee = 57;
         public int UndertakingTransfer = 58;
         public int UndertakingTransferee = 59;
         public int SectionId = 60;
         public int LeaseDeed = 61;
         public int LeaseDeedDocument = 62;
         public int NOC2RReferenceNo = 63;
         public int IsExistingAllottee = 64;
         public int tblUTransferor = 65;
         public int tblUTransferee = 66;
         public int IsIssuedCorrigendum = 67;
         public int CorrigendumArea = 68;
         public int CorrigendumFile = 69;
         public int LeaseDeedPlotArea = 70;
         public int ProductioninDate = 71;
         public int IsCarriedOutPlot = 72;
         public int PlanPassingDate = 73;
         public int PlanPassedFile = 74;
         public int ConcernedAuthority = 75;
         public int ConcernedAuthorityName = 76;
         public int ConstructionCarriedArea = 77;
         public int GroundCoveragePercentage = 78;
         public int IsTransferSubDivision = 79;
         public int IsAmalgamation = 80;
         public int IsFamilyMembers = 81;
         public int FamilyRelation = 82;
         public int FamilyRelationDocument = 83;
         public int TransferExitPolicy = 84;
         public int ExitPolicyBuildingPlanFile = 85;
         public int ExitPolicyGPDBFile = 86;
         public int ExitPolicyNotorizedFile = 87;
         public int IsChemical = 88;
         public int PossessionReceiptFile = 89;
         public int IsUtilized = 90;
         public int DateOfConveyanceDeed = 91;
         public int ConveyanceDeedPlotArea = 92;
         public int ConveyanceDeedDocument = 93;
         public int CorrigendumTypeArea = 94;
         public int CorrigendumTypeName = 95;
         public int DateofCorrigendumName = 96;
         public int CorrigendumValueName = 97;
         public int CorrigendumFileName = 98;
         public int CorrigendumTypeProperty = 99;
         public int DateofCorrigendumProperty = 100;
         public int CorrigendumValueProperty = 101;
         public int CorrigendumFileProperty = 102;
         public int PartyCode = 103;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDocumentMasterByDocument
      public class SPSelectDocumentMasterByDocument
      {
         public string SPName = "SPSelectDocumentMasterByDocument";
         public int Document = 0;
         public int ApplicationId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateSurrenderApplicationByAdmin
      public class SpUpdateSurrenderApplicationByAdmin
      {
         public string SPName = "SpUpdateSurrenderApplicationByAdmin";
         public int ApplicationFormId = 0;
         public int NewAssinedActionId = 1;
         public int UserID = 2;
         public int DocumentXML = 3;
         public int ConstructionValue = 4;
         public int Remarks = 5;
         public int SurrenderSiteVerificationReport = 6;
         public int QueryDocumentsReply = 7;
         public int IsPlotOROpenConstructed = 8;
         public int ProcessApplicationType = 9;
         public int PossessionAdviceLetterDate = 10;
         public int PossessionAdviceLetterNo = 11;
         public int SurrenderecindmentAllotment = 12;
         public int possessionTakenBackDate = 13;
         public int RefundOrderDocument = 14;
         public int completedConstructionReport = 15;
         public int tblPhoto = 16;
         public int IsPhysicalPossessionTaken = 17;
         public int DateOfAllotment = 18;
         public int LicenceAgreementDate = 19;
         public int AllotmentLetterDate = 20;
         public int PhysicalPossessionDate = 21;
         public int AdditionalDoc = 22;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region Sp_InsertUpdateDMSMaster
      public class Sp_InsertUpdateDMSMaster
      {
         public string SPName = "Sp_InsertUpdateDMSMaster";
         public int Mode = 0;
         public int BarcodeNo = 1;
         public int FileType = 2;
         public int EstateId = 3;
         public int EstateName = 4;
         public int RegionId = 5;
         public int RegionName = 6;
         public int PlottypeId = 7;
         public int PlotType = 8;
         public int PlotShedNo = 9;
         public int PartyName = 10;
         public int GroupId = 11;
         public int GroupName = 12;
         public int FolderName = 13;
         public int FileName = 14;
         public int IsActive = 15;
         public int CreatedOn = 16;
         public int UserId = 17;
         public int Id = 18;
         public int DocumentTypeId = 19;
         public int DocumentType = 20;
         public int DocumentDate = 21;
         public int OfficetypeId = 22;
         public int BranchId = 23;
         public int DivisionId = 24;
         public int ShortCode = 25;
         public int BranchCode = 26;
         public int PartyCode = 27;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectLeaseApplicationDemandDraftByApplicationFormId
      public class SPSelectLeaseApplicationDemandDraftByApplicationFormId
      {
         public string SPName = "SPSelectLeaseApplicationDemandDraftByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferModuleHOFlowAllBranch
      public class SPSelectTransferModuleHOFlowAllBranch
      {
         public string SPName = "SPSelectTransferModuleHOFlowAllBranch";
         public int BranchId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPCRReportViewHistoryByApplicationFormId
      public class SPCRReportViewHistoryByApplicationFormId
      {
         public string SPName = "SPCRReportViewHistoryByApplicationFormId";
         public int applicationid = 0;
         public int EmpCode = 1;
         public int applicationformid = 2;
         public int ReplyFrom = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectAllRegionSummaryReport
      public class SPSelectAllRegionSummaryReport
      {
         public string SPName = "SPSelectAllRegionSummaryReport";
         public int ApplicationId = 0;
         public int FromDate = 1;
         public int ToDate = 2;
         public int RegionId = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetPendingDayAtGIDCendForAmalgamation
      public class SPGetPendingDayAtGIDCendForAmalgamation
      {
         public string SPName = "SPGetPendingDayAtGIDCendForAmalgamation";
         public int ApplicationFormId = 0;
         public int Days = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertTransactionReferenceNoPaymentDetailsForRou
      public class SPInsertTransactionReferenceNoPaymentDetailsForRou
      {
         public string SPName = "SPInsertTransactionReferenceNoPaymentDetailsForRou";
         public int TxId = 0;
         public int ApplicationFormId = 1;
         public int PaymentType = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertMailReminderForBuildingPlanApproval04102016
      public class SPInsertMailReminderForBuildingPlanApproval04102016
      {
         public string SPName = "SPInsertMailReminderForBuildingPlanApproval04102016";
         public int ApplicationFormId = 0;
         public int ToEmailId = 1;
         public int CCEmailId = 2;
         public int PendingDays = 3;
         public int IsMailSend = 4;
         public int Body = 5;
         public int FromEmailId = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region M_SPUpdateTransfer_FORSECONDSECTION
      public class M_SPUpdateTransfer_FORSECONDSECTION
      {
         public string SPName = "M_SPUpdateTransfer_FORSECONDSECTION";
         public int ApplicationFormId = 0;
         public int RegionId = 1;
         public int EstateId = 2;
         public int TypeOfPlotShed = 3;
         public int PlotShedNo = 4;
         public int PlotArea = 5;
         public int TransferorConsititutionTypeId = 6;
         public int TransfereeConsititutionTypeId = 7;
         public int NameofAllottee = 8;
         public int AddressofAllottee = 9;
         public int DateofAllotment = 10;
         public int DateofAgreement = 11;
         public int DateofPossession = 12;
         public int DateofLeaseDeed = 13;
         public int LeaseDeed = 14;
         public int LeaseDeedDocument = 15;
         public int LeaseDeedPlotArea = 16;
         public int IsChemical = 17;
         public int PossessionReceiptFile = 18;
         public int AlloteeName = 19;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDocumentMasterByDocumentId
      public class SPSelectDocumentMasterByDocumentId
      {
         public string SPName = "SPSelectDocumentMasterByDocumentId";
         public int DocumentId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubdivisionModuleDetailsListForViewByApplicationFormId
      public class SPSelectSubdivisionModuleDetailsListForViewByApplicationFormId
      {
         public string SPName = "SPSelectSubdivisionModuleDetailsListForViewByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetUserIdFromRoleRegion
      public class SPGetUserIdFromRoleRegion
      {
         public string SPName = "SPGetUserIdFromRoleRegion";
         public int RoleId = 0;
         public int RegionId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSublettingDetailByApplicationFormId
      public class SPSelectSublettingDetailByApplicationFormId
      {
         public string SPName = "SPSelectSublettingDetailByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPlotShedNoByEstateIdAndPlotTypeId
      public class SPSelectPlotShedNoByEstateIdAndPlotTypeId
      {
         public string SPName = "SPSelectPlotShedNoByEstateIdAndPlotTypeId";
         public int EstateId = 0;
         public int PlotTypeId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferApplicationPaymentDetailByApplicationFormId14042017
      public class SPSelectTransferApplicationPaymentDetailByApplicationFormId14042017
      {
         public string SPName = "SPSelectTransferApplicationPaymentDetailByApplicationFormId14042017";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPaymentRecieptDetailsRou
      public class SPSelectPaymentRecieptDetailsRou
      {
         public string SPName = "SPSelectPaymentRecieptDetailsRou";
         public int txnId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region M_SPUpdateTransfer_FORTHIRDSECTION
      public class M_SPUpdateTransfer_FORTHIRDSECTION
      {
         public string SPName = "M_SPUpdateTransfer_FORTHIRDSECTION";
         public int ApplicationFormId = 0;
         public int RegionId = 1;
         public int EstateId = 2;
         public int TypeOfPlotShed = 3;
         public int PlotShedNo = 4;
         public int PlotArea = 5;
         public int TransferorConsititutionTypeId = 6;
         public int TransfereeConsititutionTypeId = 7;
         public int NameofAllottee = 8;
         public int AddressofAllottee = 9;
         public int DateofAllotment = 10;
         public int IsChemical = 11;
         public int ContactNoTransferee = 12;
         public int EmailIdTransferee = 13;
         public int NameofTrasferee = 14;
         public int AddressofTrasferee = 15;
         public int NameofProduct = 16;
         public int NameofRawMaterials = 17;
         public int RequirementofRawMaterialsperMonth = 18;
         public int WaterRequirement1stYear = 19;
         public int WaterRequirement2ndYear = 20;
         public int WaterRequirement3rdYear = 21;
         public int WaterRequirement4thYear = 22;
         public int PowerRequirement1stYear = 23;
         public int PowerRequirement2ndYear = 24;
         public int PowerRequirement3rdYear = 25;
         public int PowerRequirement4thYear = 26;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetPendingDayAtGIDCendForBuildingPlanApprovalForIFP
      public class SPGetPendingDayAtGIDCendForBuildingPlanApprovalForIFP
      {
         public string SPName = "SPGetPendingDayAtGIDCendForBuildingPlanApprovalForIFP";
         public int ReferenceNo = 0;
         public int Days = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSublettingApplicationPaymentDetailByApplicationFormId
      public class SPSelectSublettingApplicationPaymentDetailByApplicationFormId
      {
         public string SPName = "SPSelectSublettingApplicationPaymentDetailByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectLeaseApplicationList
      public class SPSelectLeaseApplicationList
      {
         public string SPName = "SPSelectLeaseApplicationList";
         public int UserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region GetAmalgationSummaryReportbyStatusforAllRegionNew
      public class GetAmalgationSummaryReportbyStatusforAllRegionNew
      {
         public string SPName = "GetAmalgationSummaryReportbyStatusforAllRegionNew";
         public int ACTIONID = 0;
         public int ActionType = 1;
         public int BeforeAfter = 2;
         public int OldApplicationStatusId = 3;
         public int PTOIssueCMD = 4;
         public int StatusId = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPlotShedByPlotShedNo
      public class SPSelectPlotShedByPlotShedNo
      {
         public string SPName = "SPSelectPlotShedByPlotShedNo";
         public int PlotShedNo = 0;
         public int EstateId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferPaymentRecieptDetails
      public class SPSelectTransferPaymentRecieptDetails
      {
         public string SPName = "SPSelectTransferPaymentRecieptDetails";
         public int txnId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSublettingModuleFormalReport
      public class SPSelectSublettingModuleFormalReport
      {
         public string SPName = "SPSelectSublettingModuleFormalReport";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectrouApplicationListDetails
      public class SPSelectrouApplicationListDetails
      {
         public string SPName = "SPSelectrouApplicationListDetails";
         public int AssignedRoleId = 0;
         public int SearchValue = 1;
         public int SearchId = 2;
         public int RegionId = 3;
         public int UserId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPaymentRecieptDetailsSubletting
      public class SPSelectPaymentRecieptDetailsSubletting
      {
         public string SPName = "SPSelectPaymentRecieptDetailsSubletting";
         public int txnId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectLeaseDeedApplication
      public class SPSelectLeaseDeedApplication
      {
         public string SPName = "SPSelectLeaseDeedApplication";
         public int AssignedRoleId = 0;
         public int SearchValue = 1;
         public int SearchId = 2;
         public int RegionId = 3;
         public int UserId = 4;
         public int ActionId = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferModuleHOFlowUserRoleCount
      public class SPSelectTransferModuleHOFlowUserRoleCount
      {
         public string SPName = "SPSelectTransferModuleHOFlowUserRoleCount";
         public int BranchId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectApplicationTransactionHistory
      public class SPSelectApplicationTransactionHistory
      {
         public string SPName = "SPSelectApplicationTransactionHistory";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region spPlainthSelfCertificationReportDetail
      public class spPlainthSelfCertificationReportDetail
      {
         public string SPName = "spPlainthSelfCertificationReportDetail";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateSublettingModuleForApplicationStatus
      public class SPUpdateSublettingModuleForApplicationStatus
      {
         public string SPName = "SPUpdateSublettingModuleForApplicationStatus";
         public int ApplicationFormId = 0;
         public int ApplicationStatusId = 1;
         public int DateOfSubletting = 2;
         public int SublettingOrderDocument = 3;
         public int ModifiedBy = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetSubdivisionModuleRejected
      public class SPGetSubdivisionModuleRejected
      {
         public string SPName = "SPGetSubdivisionModuleRejected";
         public int RegionId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSurrenderRefundOrderDetails
      public class SPSelectSurrenderRefundOrderDetails
      {
         public string SPName = "SPSelectSurrenderRefundOrderDetails";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectROUModuleByApplicationFormIdForView
      public class SPSelectROUModuleByApplicationFormIdForView
      {
         public string SPName = "SPSelectROUModuleByApplicationFormIdForView";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectApplicantCategoryMasterByApplicantCategoryId
      public class SPSelectApplicantCategoryMasterByApplicantCategoryId
      {
         public string SPName = "SPSelectApplicantCategoryMasterByApplicantCategoryId";
         public int ApplicantCategoryId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdatePaymentDetailsSubLetting
      public class SPUpdatePaymentDetailsSubLetting
      {
         public string SPName = "SPUpdatePaymentDetailsSubLetting";
         public int ApplicationFormId = 0;
         public int TxId = 1;
         public int TxRefNo = 2;
         public int TxStatus = 3;
         public int TxAmount = 4;
         public int TxMsg = 5;
         public int pgTxnNo = 6;
         public int issuerRefNo = 7;
         public int authIdCode = 8;
         public int firstName = 9;
         public int lastName = 10;
         public int pgRespCode = 11;
         public int addressZip = 12;
         public int signature = 13;
         public int Head = 14;
         public int paymentMode = 15;
         public int TxGateway = 16;
         public int cardType = 17;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectUserFromRegionRole
      public class SPSelectUserFromRegionRole
      {
         public string SPName = "SPSelectUserFromRegionRole";
         public int RegionId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateAmalgamationDACalculation
      public class SPInsertUpdateAmalgamationDACalculation
      {
         public string SPName = "SPInsertUpdateAmalgamationDACalculation";
         public int Mode = 0;
         public int ApplicationFormId = 1;
         public int userId = 2;
         public int IsProposedAmalgamationAccepted = 3;
         public int ProposedAcceptedRejectionReason = 4;
         public int ProposedAcceptedRejectionOtherReason = 5;
         public int IsmoreThanSingleAllotmentLatter = 6;
         public int AllotmentLatterNo = 7;
         public int AllotmentDate = 8;
         public int IstransferSubdivideDoneEarlier = 9;
         public int trasnferSubdivisionDetails = 10;
         public int IsTimeLimitGrantedEarlier = 11;
         public int timeLimitDetails = 12;
         public int IsAmalgamationFeeRecoverEarlier = 13;
         public int Recoverdate = 14;
         public int RecoverAmount = 15;
         public int IsNUPenaltyRecoverEarlier = 16;
         public int NURecoverDate = 17;
         public int NURecoverAmount = 18;
         public int IsPlotRegularizedAndApproved = 19;
         public int IsPlotRegularizedBefore = 20;
         public int regularizedDetails = 21;
         public int IsNupenaltyApplicable = 22;
         public int NuPenaltyDetails = 23;
         public int IsPraposalFormalInformal = 24;
         public int AM_ACCHEAD_C = 25;
         public int AM_ACC_M = 26;
         public int AM_FROM_D = 27;
         public int AM_TO_D = 28;
         public int AM_ACC_NO = 29;
         public int AM_SGST_A = 30;
         public int AM_CGST_A = 31;
         public int AM_ACC_N = 32;
         public int NU_ACCHEAD_C = 33;
         public int NU_ACC_M = 34;
         public int NU_FROM_D = 35;
         public int NU_TO_D = 36;
         public int NU_ACC_NO = 37;
         public int NU_SGST_A = 38;
         public int NU_CGST_A = 39;
         public int NU_ACC_N = 40;
         public int AccountDues = 41;
         public int WaterDues = 42;
         public int DrainageDues = 43;
         public int OtherDues = 44;
         public int AmalgamationDAFees = 45;
         public int AmalgamationDAFeesSGST = 46;
         public int AmalgamationDAFeesCGST = 47;
         public int NUPenalty = 48;
         public int NUPenaltySGST = 49;
         public int NUPenaltyCGST = 50;
         public int Penalty = 51;
         public int PenaltySGST = 52;
         public int PenaltyCGST = 53;
         public int ConcessionRevertAmount = 54;
         public int InterestonConcessionAmount = 55;
         public int TotalPaybleAmount = 56;
         public int IsAgreeAM = 57;
         public int RemarksAM = 58;
         public int IsAgreeRM = 59;
         public int RemarksRM = 60;
         public int Penalty_ACCHEAD_C = 61;
         public int Penalty_ACC_M = 62;
         public int Penalty_FROM_D = 63;
         public int Penalty_TO_D = 64;
         public int Penalty_ACC_NO = 65;
         public int Penalty_SGST_A = 66;
         public int Penalty_CGST_A = 67;
         public int Penalty_ACC_N = 68;
         public int IsSubmitted = 69;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectApplicationPaymentDetailByTxId
      public class SPSelectApplicationPaymentDetailByTxId
      {
         public string SPName = "SPSelectApplicationPaymentDetailByTxId";
         public int TxId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubLettingModuleDocumentTransactionByApplicationFormId
      public class SPSelectSubLettingModuleDocumentTransactionByApplicationFormId
      {
         public string SPName = "SPSelectSubLettingModuleDocumentTransactionByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPlinthCertificationInvoiceForCancel
      public class SPSelectPlinthCertificationInvoiceForCancel
      {
         public string SPName = "SPSelectPlinthCertificationInvoiceForCancel";
         public int ApplicationFormId = 0;
         public int UserId = 1;
         public int TxId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectMenuMasterByMenuText
      public class SPSelectMenuMasterByMenuText
      {
         public string SPName = "SPSelectMenuMasterByMenuText";
         public int MenuText = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectROUModuleByApplicationFormId
      public class SPSelectROUModuleByApplicationFormId
      {
         public string SPName = "SPSelectROUModuleByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateSurrenderModuleForApplicationStatus
      public class SPUpdateSurrenderModuleForApplicationStatus
      {
         public string SPName = "SPUpdateSurrenderModuleForApplicationStatus";
         public int ApplicationFormId = 0;
         public int ApplicationStatusId = 1;
         public int DateofSurrender = 2;
         public int SurrenderOrderDocument = 3;
         public int DateOfNOCIssued = 4;
         public int NOCDocument = 5;
         public int ModifiedBy = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubLettingApplicationPaymentDetailByTxId
      public class SPSelectSubLettingApplicationPaymentDetailByTxId
      {
         public string SPName = "SPSelectSubLettingApplicationPaymentDetailByTxId";
         public int TxId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertCRDailyApplicationDetailsForSubdivision
      public class SPInsertCRDailyApplicationDetailsForSubdivision
      {
         public string SPName = "SPInsertCRDailyApplicationDetailsForSubdivision";
         public int ApplicationId = 0;
         public int ApplicationFormId = 1;
         public int AppForwardDate = 2;
         public int AppActualForwardDate = 3;
         public int ActionId = 4;
         public int AssignRoleId = 5;
         public int EstateId = 6;
         public int Remark = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region Sp_InsertUpdateSubDivisionDocumentTransaction
      public class Sp_InsertUpdateSubDivisionDocumentTransaction
      {
         public string SPName = "Sp_InsertUpdateSubDivisionDocumentTransaction";
         public int Mode = 0;
         public int ApplicationFormId = 1;
         public int Documentmasterid = 2;
         public int AssignedRoleId = 3;
         public int ActionId = 4;
         public int Remark = 5;
         public int UserId = 6;
         public int DocumentOKorNotOK = 7;
         public int DocumentRemarks = 8;
         public int DocumentOKorNotOKAE = 9;
         public int DocumentRemarksAE = 10;
         public int DocumentOKorNotOKDEE = 11;
         public int DocumentRemarksDEE = 12;
         public int DocumentOKorNotOKXEN = 13;
         public int DocumentRemarksXEN = 14;
         public int DocumentOKorNotOKDA = 15;
         public int DocumentRemarksDA = 16;
         public int DocumentOKorNotOKAM = 17;
         public int DocumentRemarksAM = 18;
         public int DocumentOKorNotOKRM = 19;
         public int DocumentRemarksRM = 20;
         public int DocumentOKorNotOKDM = 21;
         public int DocumentRemarksDM = 22;
         public int DocumentOKorNotOKVCMD = 23;
         public int DocumentRemarksVCMD = 24;
         public int Document = 25;
         public int ApplicationFormId2 = 26;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelect2RApplicationReport
      public class SPSelect2RApplicationReport
      {
         public string SPName = "SPSelect2RApplicationReport";
         public int ApplicationId = 0;
         public int RegionId = 1;
         public int EstateId = 2;
         public int ReportId = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdatePaymentDetails11042017
      public class SPUpdatePaymentDetails11042017
      {
         public string SPName = "SPUpdatePaymentDetails11042017";
         public int ApplicationFormId = 0;
         public int TxId = 1;
         public int TxRefNo = 2;
         public int TxStatus = 3;
         public int TxAmount = 4;
         public int TxMsg = 5;
         public int pgTxnNo = 6;
         public int issuerRefNo = 7;
         public int authIdCode = 8;
         public int firstName = 9;
         public int lastName = 10;
         public int pgRespCode = 11;
         public int addressZip = 12;
         public int signature = 13;
         public int Head = 14;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectBuildingCompletionInvoiceForCancel
      public class SPSelectBuildingCompletionInvoiceForCancel
      {
         public string SPName = "SPSelectBuildingCompletionInvoiceForCancel";
         public int ApplicationFormId = 0;
         public int UserId = 1;
         public int TxId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectMenuMasterByMenuId
      public class SPSelectMenuMasterByMenuId
      {
         public string SPName = "SPSelectMenuMasterByMenuId";
         public int MenuId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSurrenderModuleDocumentTransactionByApplicationFormId
      public class SPSelectSurrenderModuleDocumentTransactionByApplicationFormId
      {
         public string SPName = "SPSelectSurrenderModuleDocumentTransactionByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertTransactionReferenceNoPaymentDetailsForSubletting
      public class SPInsertTransactionReferenceNoPaymentDetailsForSubletting
      {
         public string SPName = "SPInsertTransactionReferenceNoPaymentDetailsForSubletting";
         public int TxId = 0;
         public int ApplicationFormId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateApplicationWiseBranchForUser
      public class SPInsertUpdateApplicationWiseBranchForUser
      {
         public string SPName = "SPInsertUpdateApplicationWiseBranchForUser";
         public int UserId = 0;
         public int ApplicationTypeId = 1;
         public int UserBranchId = 2;
         public int CreatedBy = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectPlotTypeMasterSelectByLeaseDeed
      public class SPSelectPlotTypeMasterSelectByLeaseDeed
      {
         public string SPName = "SPSelectPlotTypeMasterSelectByLeaseDeed";
         public int LeaseDeed = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateSubDivisionApplicationByApplicationFormId_OLD
      public class SPUpdateSubDivisionApplicationByApplicationFormId_OLD
      {
         public string SPName = "SPUpdateSubDivisionApplicationByApplicationFormId_OLD";
         public int ApplicationFormId = 0;
         public int EstateId = 1;
         public int RegionId = 2;
         public int TypeOfPlotShed = 3;
         public int PlotShedNo = 4;
         public int PlotArea = 5;
         public int DateofAllotment = 6;
         public int IsChemical = 7;
         public int NameofApplicant = 8;
         public int ConstitutionTypeId = 9;
         public int ApplicantLandlineNo = 10;
         public int ApplicantMobileNo = 11;
         public int ApplicantEmailId = 12;
         public int IsPlotLessThan250 = 13;
         public int IsPlotMin9MtrGIDC = 14;
         public int IsPlotSubDivisionOpen = 15;
         public int IsPlotSubDivisionUtilized = 16;
         public int IsExistingEntryPointGIDC = 17;
         public int IsCOPOriginalPlot = 18;
         public int IsInternalRoadInSubDivision = 19;
         public int IsProDataCommonAreaDone = 20;
         public int IsAssociationMembersPlot = 21;
         public int IsProposedBetweenFamilyMembers = 22;
         public int FamilyRelationId = 23;
         public int FamilyRelationDocument = 24;
         public int IsExistingPartnerWithExistingGIDC = 25;
         public int ExistingGIDCFamilyRelationId = 26;
         public int ExistingGIDCFamilyRelationDocument = 27;
         public int IsBuildingPlanPlotApproved = 28;
         public int BuldingApprovedDate = 29;
         public int BuldingPlanPassingAuthority = 30;
         public int BuldingPlanDocument = 31;
         public int IsRevisedBuildingPlanPlotApproved = 32;
         public int RevisedBuldingApprovedDate = 33;
         public int RevisedBuldingPlanPassingAuthority = 34;
         public int RevisedBuldingPlanDocument = 35;
         public int IsGIDCInformedPlanApproval = 36;
         public int GIDCInformedDateOfLetter = 37;
         public int GIDCInformedLetterNo = 38;
         public int IsViolativeConstructionPlot = 39;
         public int ViolativeConstructionPlotArea = 40;
         public int IsOriginalPlotSubDivision = 41;
         public int OriginalPlotSubDivisionDateOfSubdivision = 42;
         public int OriginalPlotSubDivisionApprovalAuthority = 43;
         public int OriginalPlotSubDivisionDocument = 44;
         public int IsNocSubDivisionGIDC = 45;
         public int NOCDateApproval = 46;
         public int NOCLetterNo = 47;
         public int NOCDocument = 48;
         public int IsNOCPaidGIDC = 49;
         public int NOCPaidGIDCPaymentDate = 50;
         public int NOCPaidGIDCAmount = 51;
         public int NOCPaidGIDCDocument = 52;
         public int IsIncorporatedGIDCDDPlan = 53;
         public int IncorporatedDate = 54;
         public int IncorporatedDocument = 55;
         public int IsLegalMatterPendingPlot = 56;
         public int CaseNo = 57;
         public int PresentStatus = 58;
         public int DirectionGiven = 59;
         public int NoOfSubDivisionPlot = 60;
         public int PurposeOfSubDivision = 61;
         public int AreaCalculationSheet = 62;
         public int SketchOfSubDivisionDocument = 63;
         public int UndertakingFacilitiesAndAreaDocument = 64;
         public int UndertakingLessThan50GCPlotDocument = 65;
         public int UtilisationElectricityBillDocument = 66;
         public int UtilisationWaterSupplyBillDocument = 67;
         public int SectionType = 68;
         public int ModifiedBy = 69;
         public int ApplicantIdentity = 70;
         public int IsSubmitted = 71;
         public int AdminTotalCharge = 72;
         public int AdminKKC = 73;
         public int AdminSBC = 74;
         public int AdminST = 75;
         public int AdminCharge = 76;
         public int COPArea = 77;
         public int IntarnalArea = 78;
         public int AvailableArea = 79;
         public int UndertakingOfCreation = 80;
         public int TotalAreaper = 81;
         public int COPAreaper = 82;
         public int InternalRoadAreaper = 83;
         public int Availableplotareaper = 84;
         public int IsNocObtained = 85;
         public int NOCApprovalLetterNo = 86;
         public int NOCApprovalDate = 87;
         public int UploadNOC = 88;
         public int IsProposalApproved = 89;
         public int NameofLocalAuthority = 90;
         public int PlanPassingLetterNo = 91;
         public int PlanPassingLetterDate = 92;
         public int UploadPlanPassingLetter = 93;
         public int UploadApprovedSketch = 94;
         public int AccountDues = 95;
         public int WaterDues = 96;
         public int OtherDues = 97;
         public int DrainageDues = 98;
         public int NDCAccount = 99;
         public int NDCEngineering = 100;
         public int OSINST_A = 101;
         public int OSIDPPI_A = 102;
         public int OSSC_A = 103;
         public int OSSC_ST = 104;
         public int OSSC_EC = 105;
         public int OSSWCSC = 106;
         public int OSSCKKC = 107;
         public int OSNAA_A = 108;
         public int OSNAA_ST = 109;
         public int OSNAA_EC = 110;
         public int OSSWCNAA = 111;
         public int OSNAAKKC = 112;
         public int OSLR_A = 113;
         public int OSLR_ST = 114;
         public int OSLR_EC = 115;
         public int OSSWCLR = 116;
         public int OSLRKKC = 117;
         public int OSIR_A = 118;
         public int OSIUF_A = 119;
         public int OSIUF_ST = 120;
         public int OSIUF_EC = 121;
         public int OSFULLPAYMENT_A = 122;
         public int PartyCode = 123;
         public int IsFromMobileApp = 124;
         public int LRCOSINST_A = 125;
         public int LRCOSIDP_A = 126;
         public int SGSTAmount = 127;
         public int CGSTAmount = 128;
         public int ACCHEAD_C = 129;
         public int ACC_M = 130;
         public int FROM_D = 131;
         public int TO_D = 132;
         public int ACC_NO = 133;
         public int SGST_A = 134;
         public int CGST_A = 135;
         public int ACC_N = 136;
         public int AC_SGSTAmount = 137;
         public int AC_CGSTAmount = 138;
         public int AC_ACCHEAD_C = 139;
         public int AC_ACC_M = 140;
         public int AC_FROM_D = 141;
         public int AC_TO_D = 142;
         public int AC_ACC_NO = 143;
         public int AC_SGST_A = 144;
         public int AC_CGST_A = 145;
         public int AC_ACC_N = 146;
         public int EN_SGSTAmount = 147;
         public int EN_CGSTAmount = 148;
         public int EN_ACCHEAD_C = 149;
         public int EN_ACC_M = 150;
         public int EN_FROM_D = 151;
         public int EN_TO_D = 152;
         public int EN_ACC_NO = 153;
         public int EN_SGST_A = 154;
         public int EN_CGST_A = 155;
         public int EN_ACC_N = 156;
         public int AlloteeGSTNo = 157;
         public int AlloteeName = 158;
         public int SC_OS_CGST = 159;
         public int SC_OS_SGST = 160;
         public int NAA_OS_CGST = 161;
         public int NAA_OS_SGST = 162;
         public int LR_OS_CGST = 163;
         public int LR_OS_SGST = 164;
         public int INTREV_OS_CGST = 165;
         public int INTREV_OS_SGST = 166;
         public int SC_BASE = 167;
         public int SC_SGSTAmount = 168;
         public int SC_CGSTAmount = 169;
         public int SC_ACCHEAD_C = 170;
         public int SC_ACC_M = 171;
         public int SC_FROM_D = 172;
         public int SC_TO_D = 173;
         public int SC_ACC_NO = 174;
         public int SC_SGST_A = 175;
         public int SC_CGST_A = 176;
         public int SC_ACC_N = 177;
         public int NAA_BASE = 178;
         public int NAA_SGSTAmount = 179;
         public int NAA_CGSTAmount = 180;
         public int NAA_ACCHEAD_C = 181;
         public int NAA_ACC_M = 182;
         public int NAA_FROM_D = 183;
         public int NAA_TO_D = 184;
         public int NAA_ACC_NO = 185;
         public int NAA_SGST_A = 186;
         public int NAA_CGST_A = 187;
         public int NAA_ACC_N = 188;
         public int LR_BASE = 189;
         public int LR_SGSTAmount = 190;
         public int LR_CGSTAmount = 191;
         public int LR_ACCHEAD_C = 192;
         public int LR_ACC_M = 193;
         public int LR_FROM_D = 194;
         public int LR_TO_D = 195;
         public int LR_ACC_NO = 196;
         public int LR_SGST_A = 197;
         public int LR_CGST_A = 198;
         public int LR_ACC_N = 199;
         public int INT_BASE = 200;
         public int INT_SGSTAmount = 201;
         public int INT_CGSTAmount = 202;
         public int INT_ACCHEAD_C = 203;
         public int INT_ACC_M = 204;
         public int INT_FROM_D = 205;
         public int INT_TO_D = 206;
         public int INT_ACC_NO = 207;
         public int INT_SGST_A = 208;
         public int INT_CGST_A = 209;
         public int INT_ACC_N = 210;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region GetMonthandYearWiseCRPointBalance
      public class GetMonthandYearWiseCRPointBalance
      {
         public string SPName = "GetMonthandYearWiseCRPointBalance";
         public int Empcode = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDelayReport
      public class SPSelectDelayReport
      {
         public string SPName = "SPSelectDelayReport";
         public int ApplicationId = 0;
         public int RegionId = 1;
         public int EstateId = 2;
         public int ReportId = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdatePaymentDetailsByServerResponse
      public class SPUpdatePaymentDetailsByServerResponse
      {
         public string SPName = "SPUpdatePaymentDetailsByServerResponse";
         public int TxId = 0;
         public int TxRefNo = 1;
         public int TxStatus = 2;
         public int TxAmount = 3;
         public int TxMsg = 4;
         public int pgTxnNo = 5;
         public int issuerRefNo = 6;
         public int authIdCode = 7;
         public int firstName = 8;
         public int lastName = 9;
         public int pgRespCode = 10;
         public int addressZip = 11;
         public int signature = 12;
         public int Head = 13;
         public int paymentMode = 14;
         public int TxGateway = 15;
         public int cardType = 16;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetSublettingModuleRejected
      public class SPGetSublettingModuleRejected
      {
         public string SPName = "SPGetSublettingModuleRejected";
         public int RegionId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertBuildingPlanApprovalActionTransaction04102016
      public class SPInsertBuildingPlanApprovalActionTransaction04102016
      {
         public string SPName = "SPInsertBuildingPlanApprovalActionTransaction04102016";
         public int ApplicationFormId = 0;
         public int ActionId = 1;
         public int Remark = 2;
         public int CreatedBy = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSurrenderModuleByApplicationFormIdForView
      public class SPSelectSurrenderModuleByApplicationFormIdForView
      {
         public string SPName = "SPSelectSurrenderModuleByApplicationFormIdForView";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateSubLettingModule02022017
      public class SPUpdateSubLettingModule02022017
      {
         public string SPName = "SPUpdateSubLettingModule02022017";
         public int Mode = 0;
         public int ApplicationFormId = 1;
         public int UserId = 2;
         public int ApplicationFormDate = 3;
         public int ApplicantName = 4;
         public int ApplicantLandlineNo = 5;
         public int ApplicantMobileNo = 6;
         public int ApplicantEmailId = 7;
         public int ApplicantIdentity = 8;
         public int RegisterOfficeAddress = 9;
         public int RegOfficeIdentity = 10;
         public int RegionId = 11;
         public int RegionName = 12;
         public int EstateId = 13;
         public int EstateName = 14;
         public int TypeOfPlotShed = 15;
         public int PlotShedNo = 16;
         public int PlotArea = 17;
         public int ShedArea = 18;
         public int DateofAllotment = 19;
         public int IsChemical = 20;
         public int NameofAllottee = 21;
         public int ConstitutionTypeId = 22;
         public int SubletteeConstitutionTypeId = 23;
         public int IsPlotShedLandLooserCat = 24;
         public int IsPlanPassed = 25;
         public int PlanPassedDate = 26;
         public int PlanPassAuthority = 27;
         public int AreaApprovedGF = 28;
         public int AreaApprovedFF = 29;
         public int AreaApprovedSF = 30;
         public int AreaApprovedOther = 31;
         public int AreaApprovedTotal = 32;
         public int AreaConstructedGF = 33;
         public int AreaConstructedFF = 34;
         public int AreaConstructedSF = 35;
         public int AreaConstructedOther = 36;
         public int AreaConstructedTotal = 37;
         public int AreaSubLettedGF = 38;
         public int AreaSubLettedFF = 39;
         public int AreaSubLettedSF = 40;
         public int AreaSubLettedOther = 41;
         public int AreaSubLettedTotal = 42;
         public int IsUnAuthoConsDone = 43;
         public int UnAuthoConsArea = 44;
         public int IsUnAuthoUsageDone = 45;
         public int PurposeOfUsage = 46;
         public int PeriodOfUsage = 47;
         public int PurposeOfSubletting = 48;
         public int PurposeOfSublettingValue = 49;
         public int PeriodOfSubLeetingFromDate = 50;
         public int PeriodOfSubLeetingToDate = 51;
         public int PeriodOfSubLeetingYears = 52;
         public int SubLettingFees = 53;
         public int IsFuelStation = 54;
         public int IsPetrolPumpOwned = 55;
         public int IsSubletLandPetrolPump = 56;
         public int SubletLandPetrolPump = 57;
         public int SubletPetrolPumpArea = 58;
         public int IsPeriodSubMorethanYear = 59;
         public int SubletYear = 60;
         public int IsFrontageChargeApplicable = 61;
         public int AreaForFrontageCharge = 62;
         public int AmountOfFrontageCharge = 63;
         public int SublettingCharge = 64;
         public int TotalSubLetChargeFiveYear = 65;
         public int SubLettingAgreeDoc = 66;
         public int UndPetrolComHandoverDoc = 67;
         public int UndPetrolComTransferDoc = 68;
         public int UndPetrolComNotUsingSubLettedDoc = 69;
         public int UndAllotteeNotUsingSubLettedDoc = 70;
         public int UndPetrolComSecurityDoc = 71;
         public int UndAllotteeSecuritySafetyDoc = 72;
         public int CommercialActivity = 73;
         public int CommercialActivityValue = 74;
         public int IsSubletCompanyChemical = 75;
         public int DocumentXML = 76;
         public int OtherAuthorityName = 77;
         public int HazardousItem = 78;
         public int IsEntirePlotSubLetted = 79;
         public int ProvidePlotArea = 80;
         public int CopyofAgreement = 81;
         public int Is2RPermissionTakenPast = 82;
         public int 2rReferenceNo = 83;
         public int NDC = 84;
         public int IsHazardousItem = 85;
         public int PropertyIdentificationNo = 86;
         public int IsEntirePlotSubLettedForLanLooserYes = 87;
         public int ProvidePlotAreaForLanLooserYes = 88;
         public int CopyofAgreementForLanLooserYes = 89;
         public int PeriodOfSubLeetingFromDateForLanLooserYes = 90;
         public int PeriodOfSubLeetingToDateForLanLooserYes = 91;
         public int ChemicalItemDetail = 92;
         public int AdminFees = 93;
         public int AdminST = 94;
         public int AdminSBC = 95;
         public int AdminKKC = 96;
         public int AccountDues = 97;
         public int WaterDues = 98;
         public int OtherDues = 99;
         public int DrainageDues = 100;
         public int NDCAccount = 101;
         public int NDCEngineering = 102;
         public int NameOfSubLetting = 103;
         public int OraPartyCode = 104;
         public int OSINST_A = 105;
         public int OSIDPPI_A = 106;
         public int OSSC_A = 107;
         public int OSSC_ST = 108;
         public int OSSC_EC = 109;
         public int OSSWCSC = 110;
         public int OSSCKKC = 111;
         public int OSNAA_A = 112;
         public int OSNAA_ST = 113;
         public int OSNAA_EC = 114;
         public int OSSWCNAA = 115;
         public int OSNAAKKC = 116;
         public int OSLR_A = 117;
         public int OSLR_ST = 118;
         public int OSLR_EC = 119;
         public int OSSWCLR = 120;
         public int OSLRKKC = 121;
         public int OSIR_A = 122;
         public int OSIUF_A = 123;
         public int OSIUF_ST = 124;
         public int OSIUF_EC = 125;
         public int OSFULLPAYMENT_A = 126;
         public int LRCOSINST_A = 127;
         public int LRCOSIDP_A = 128;
         public int SGSTAmount = 129;
         public int CGSTAmount = 130;
         public int ACCHEAD_C = 131;
         public int ACC_M = 132;
         public int FROM_D = 133;
         public int TO_D = 134;
         public int ACC_NO = 135;
         public int SGST_A = 136;
         public int CGST_A = 137;
         public int ACC_N = 138;
         public int AC_SGSTAmount = 139;
         public int AC_CGSTAmount = 140;
         public int AC_ACCHEAD_C = 141;
         public int AC_ACC_M = 142;
         public int AC_FROM_D = 143;
         public int AC_TO_D = 144;
         public int AC_ACC_NO = 145;
         public int AC_SGST_A = 146;
         public int AC_CGST_A = 147;
         public int AC_ACC_N = 148;
         public int EN_SGSTAmount = 149;
         public int EN_CGSTAmount = 150;
         public int EN_ACCHEAD_C = 151;
         public int EN_ACC_M = 152;
         public int EN_FROM_D = 153;
         public int EN_TO_D = 154;
         public int EN_ACC_NO = 155;
         public int EN_SGST_A = 156;
         public int EN_CGST_A = 157;
         public int EN_ACC_N = 158;
         public int AlloteeGSTNo = 159;
         public int SC_SGSTAmount = 160;
         public int SC_CGSTAmount = 161;
         public int SC_ACCHEAD_C = 162;
         public int SC_ACC_M = 163;
         public int SC_FROM_D = 164;
         public int SC_TO_D = 165;
         public int SC_ACC_NO = 166;
         public int SC_SGST_A = 167;
         public int SC_CGST_A = 168;
         public int SC_ACC_N = 169;
         public int SC_BaseAmount = 170;
         public int NAA_SGSTAmount = 171;
         public int NAA_CGSTAmount = 172;
         public int NAA_ACCHEAD_C = 173;
         public int NAA_ACC_M = 174;
         public int NAA_FROM_D = 175;
         public int NAA_TO_D = 176;
         public int NAA_ACC_NO = 177;
         public int NAA_SGST_A = 178;
         public int NAA_CGST_A = 179;
         public int NAA_ACC_N = 180;
         public int NAA_BaseAmount = 181;
         public int LR_SGSTAmount = 182;
         public int LR_CGSTAmount = 183;
         public int LR_ACCHEAD_C = 184;
         public int LR_ACC_M = 185;
         public int LR_FROM_D = 186;
         public int LR_TO_D = 187;
         public int LR_ACC_NO = 188;
         public int LR_SGST_A = 189;
         public int LR_CGST_A = 190;
         public int LR_ACC_N = 191;
         public int LR_BaseAmount = 192;
         public int INT_SGSTAmount = 193;
         public int INT_CGSTAmount = 194;
         public int INT_ACCHEAD_C = 195;
         public int INT_ACC_M = 196;
         public int INT_FROM_D = 197;
         public int INT_TO_D = 198;
         public int INT_ACC_NO = 199;
         public int INT_SGST_A = 200;
         public int INT_CGST_A = 201;
         public int INT_ACC_N = 202;
         public int INT_BaseAmount = 203;
         public int SC_OS_CGST = 204;
         public int SC_OS_SGST = 205;
         public int NAA_OS_CGST = 206;
         public int NAA_OS_SGST = 207;
         public int LR_OS_CGST = 208;
         public int LR_OS_SGST = 209;
         public int INTREV_OS_CGST = 210;
         public int INTREV_OS_SGST = 211;
         public int TwoRDate = 212;
         public int IsAgreeThirdsave = 213;
         public int LicenseAgreementDate = 214;
         public int LeaseDeedDate = 215;
         public int IsSEZ = 216;
         public int REVINT_CSGST_OS = 217;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectRemarksHistoryByApplicationFormId
      public class SPSelectRemarksHistoryByApplicationFormId
      {
         public string SPName = "SPSelectRemarksHistoryByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSubDivisionUpdateApplicationForTechnicalScrutiny05012016_OLD
      public class SPSubDivisionUpdateApplicationForTechnicalScrutiny05012016_OLD
      {
         public string SPName = "SPSubDivisionUpdateApplicationForTechnicalScrutiny05012016_OLD";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int RoleId = 2;
         public int CurrentApplicationActionId = 3;
         public int AssignedRoleId = 4;
         public int ActionId = 5;
         public int IsPlotRegularShape = 6;
         public int IsTheirAnyMarginRelaxation = 7;
         public int MarginSketch = 8;
         public int MarginAreaTable = 9;
         public int Islocated9Mtr = 10;
         public int IsPlotFacingGIDCRoad500sqrMtr = 11;
         public int IsWidthDepthRatiomaintained = 12;
         public int IsCOPKeptMaintained = 13;
         public int IsWidthOfRoadMaintained = 14;
         public int IsCommonArea = 15;
         public int IsAnyAdditionalInfrastructure = 16;
         public int IsAnyAdditionalEntryPoint = 17;
         public int IsMinimum50PerConstruction = 18;
         public int Udertakingof50Per = 19;
         public int IsCommonFacilityCpo = 20;
         public int IsPreventingGDCR = 21;
         public int UploadSketchAcceptance = 22;
         public int UploadSketchofGDCR = 23;
         public int DDPlanShowingLocation = 24;
         public int Remark = 25;
         public int GCDocument = 26;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPHelpdeskDeshboardReport
      public class SPHelpdeskDeshboardReport
      {
         public string SPName = "SPHelpdeskDeshboardReport";
         public int ApplicationId = 0;
         public int RegionId = 1;
         public int EstateId = 2;
         public int ReportId = 3;
         public int FromDate = 4;
         public int ToDate = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPBuildingPlanApprovalApplicationRemarksHistory
      public class SPBuildingPlanApprovalApplicationRemarksHistory
      {
         public string SPName = "SPBuildingPlanApprovalApplicationRemarksHistory";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetROUModuleRejected
      public class SPGetROUModuleRejected
      {
         public string SPName = "SPGetROUModuleRejected";
         public int RegionId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateMenuMaster
      public class SPInsertUpdateMenuMaster
      {
         public string SPName = "SPInsertUpdateMenuMaster";
         public int MenuId = 0;
         public int MenuText = 1;
         public int MenuUrl = 2;
         public int Order = 3;
         public int UserId = 4;
         public int IsActive = 5;
         public int Operation = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectROUFillDetailByPropertyIdentificationNo
      public class SPSelectROUFillDetailByPropertyIdentificationNo
      {
         public string SPName = "SPSelectROUFillDetailByPropertyIdentificationNo";
         public int PropertyIdentiNo = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPHelpDeskForwardToDATwoRApplication
      public class SPHelpDeskForwardToDATwoRApplication
      {
         public string SPName = "SPHelpDeskForwardToDATwoRApplication";
         public int ApplicationFormId = 0;
         public int AssignedRoleId = 1;
         public int ModifiedBy = 2;
         public int StatusId = 3;
         public int BackwardRemark = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateBuildingPlanApprovalApplicationForAutoRejectBySystem04102016
      public class SPUpdateBuildingPlanApprovalApplicationForAutoRejectBySystem04102016
      {
         public string SPName = "SPUpdateBuildingPlanApprovalApplicationForAutoRejectBySystem04102016";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertSubLettingModule02022017
      public class SPInsertSubLettingModule02022017
      {
         public string SPName = "SPInsertSubLettingModule02022017";
         public int Mode = 0;
         public int ReferenceNo = 1;
         public int UserId = 2;
         public int ApplicationFormDate = 3;
         public int ApplicantName = 4;
         public int ApplicantLandlineNo = 5;
         public int ApplicantMobileNo = 6;
         public int ApplicantEmailId = 7;
         public int ApplicantIdentity = 8;
         public int RegisterOfficeAddress = 9;
         public int RegOfficeIdentity = 10;
         public int RegionId = 11;
         public int RegionName = 12;
         public int EstateId = 13;
         public int EstateName = 14;
         public int TypeOfPlotShed = 15;
         public int PlotShedNo = 16;
         public int PlotArea = 17;
         public int ShedArea = 18;
         public int DateofAllotment = 19;
         public int IsChemical = 20;
         public int NameofAllottee = 21;
         public int ConstitutionTypeId = 22;
         public int SubletteeConstitutionTypeId = 23;
         public int IsPlotShedLandLooserCat = 24;
         public int IsPlanPassed = 25;
         public int PlanPassedDate = 26;
         public int PlanPassAuthority = 27;
         public int AreaApprovedGF = 28;
         public int AreaApprovedFF = 29;
         public int AreaApprovedSF = 30;
         public int AreaApprovedOther = 31;
         public int AreaApprovedTotal = 32;
         public int AreaConstructedGF = 33;
         public int AreaConstructedFF = 34;
         public int AreaConstructedSF = 35;
         public int AreaConstructedOther = 36;
         public int AreaConstructedTotal = 37;
         public int AreaSubLettedGF = 38;
         public int AreaSubLettedFF = 39;
         public int AreaSubLettedSF = 40;
         public int AreaSubLettedOther = 41;
         public int AreaSubLettedTotal = 42;
         public int IsUnAuthoConsDone = 43;
         public int UnAuthoConsArea = 44;
         public int IsUnAuthoUsageDone = 45;
         public int PurposeOfUsage = 46;
         public int PeriodOfUsage = 47;
         public int PurposeOfSubletting = 48;
         public int PurposeOfSublettingValue = 49;
         public int PeriodOfSubLeetingFromDate = 50;
         public int PeriodOfSubLeetingToDate = 51;
         public int PeriodOfSubLeetingYears = 52;
         public int SubLettingFees = 53;
         public int IsFuelStation = 54;
         public int IsPetrolPumpOwned = 55;
         public int IsSubletLandPetrolPump = 56;
         public int SubletLandPetrolPump = 57;
         public int SubletPetrolPumpArea = 58;
         public int IsPeriodSubMorethanYear = 59;
         public int SubletYear = 60;
         public int IsFrontageChargeApplicable = 61;
         public int AreaForFrontageCharge = 62;
         public int AmountOfFrontageCharge = 63;
         public int SublettingCharge = 64;
         public int TotalSubLetChargeFiveYear = 65;
         public int SubLettingAgreeDoc = 66;
         public int UndPetrolComHandoverDoc = 67;
         public int UndPetrolComTransferDoc = 68;
         public int UndPetrolComNotUsingSubLettedDoc = 69;
         public int UndAllotteeNotUsingSubLettedDoc = 70;
         public int UndPetrolComSecurityDoc = 71;
         public int UndAllotteeSecuritySafetyDoc = 72;
         public int CommercialActivity = 73;
         public int CommercialActivityValue = 74;
         public int IsSubletCompanyChemical = 75;
         public int DocumentXML = 76;
         public int OtherAuthorityName = 77;
         public int HazardousItem = 78;
         public int IsEntirePlotSubLetted = 79;
         public int ProvidePlotArea = 80;
         public int CopyofAgreement = 81;
         public int Is2RPermissionTakenPast = 82;
         public int 2rReferenceNo = 83;
         public int NDC = 84;
         public int IsHazardousItem = 85;
         public int PropertyIdentificationNo = 86;
         public int IsEntirePlotSubLettedForLanLooserYes = 87;
         public int ProvidePlotAreaForLanLooserYes = 88;
         public int CopyofAgreementForLanLooserYes = 89;
         public int PeriodOfSubLeetingFromDateForLanLooserYes = 90;
         public int PeriodOfSubLeetingToDateForLanLooserYes = 91;
         public int ChemicalItemDetail = 92;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSublettingApplicationSummaryReportNew
      public class SPSublettingApplicationSummaryReportNew
      {
         public string SPName = "SPSublettingApplicationSummaryReportNew";
         public int BeforeAfter = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectUserBranchApplicationTypeMappingByApplicationId
      public class SPSelectUserBranchApplicationTypeMappingByApplicationId
      {
         public string SPName = "SPSelectUserBranchApplicationTypeMappingByApplicationId";
         public int UserId = 0;
         public int ApplicationId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSubDivisionUpdateSubdivisionApplicationByDEEXEN05012017_OLD
      public class SPSubDivisionUpdateSubdivisionApplicationByDEEXEN05012017_OLD
      {
         public string SPName = "SPSubDivisionUpdateSubdivisionApplicationByDEEXEN05012017_OLD";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int UserRoleId = 2;
         public int CurrentApplicationActionId = 3;
         public int AssignedRoleId = 4;
         public int AssignedActionId = 5;
         public int IsPlotRegularShapeDEE = 6;
         public int IsTheirAnyMarginRelaxationDEE = 7;
         public int Islocated9MtrDEE = 8;
         public int IsPlotFacingGIDCRoad500sqrMtrDEE = 9;
         public int IsWidthDepthRatiomaintainedDEE = 10;
         public int IsCOPKeptMaintainedDEE = 11;
         public int IsWidthOfRoadMaintainedDEE = 12;
         public int IsCommonAreaDEE = 13;
         public int IsAnyAdditionalInfrastructureDEE = 14;
         public int IsAnyAdditionalEntryPointDEE = 15;
         public int IsMinimum50PerConstructionDEE = 16;
         public int IsCommonFacilityCpoDEE = 17;
         public int IsPreventingGDCRDEE = 18;
         public int IsPlotRegularShapeXEN = 19;
         public int IsTheirAnyMarginRelaxationXEN = 20;
         public int Islocated9MtrXEN = 21;
         public int IsPlotFacingGIDCRoad500sqrMtrXEN = 22;
         public int IsWidthDepthRatiomaintainedXEN = 23;
         public int IsCOPKeptMaintainedXEN = 24;
         public int IsWidthOfRoadMaintainedXEN = 25;
         public int IsCommonAreaXEN = 26;
         public int IsAnyAdditionalInfrastructureXEN = 27;
         public int IsAnyAdditionalEntryPointXEN = 28;
         public int IsMinimum50PerConstructionXEN = 29;
         public int IsCommonFacilityCpoXEN = 30;
         public int IsPreventingGDCRXEN = 31;
         public int Remark = 32;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region GetCRPointMonthwiseReport
      public class GetCRPointMonthwiseReport
      {
         public string SPName = "GetCRPointMonthwiseReport";
         public int EMPCode = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDEEDashboardReport
      public class SPDEEDashboardReport
      {
         public string SPName = "SPDEEDashboardReport";
         public int ApplicationId = 0;
         public int RegionId = 1;
         public int EstateId = 2;
         public int ReportId = 3;
         public int FromDate = 4;
         public int ToDate = 5;
         public int UserId = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteGeneralApplicationandBuildingPlanApprovalFormByApplicationFormId
      public class SPDeleteGeneralApplicationandBuildingPlanApprovalFormByApplicationFormId
      {
         public string SPName = "SPDeleteGeneralApplicationandBuildingPlanApprovalFormByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteMenuMasterByMenuId
      public class SPDeleteMenuMasterByMenuId
      {
         public string SPName = "SPDeleteMenuMasterByMenuId";
         public int MenuId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSublettingModuleSelectDocumentTransactionByApplicationIdPublic02022017NewTemp
      public class SPSublettingModuleSelectDocumentTransactionByApplicationIdPublic02022017NewTemp
      {
         public string SPName = "SPSublettingModuleSelectDocumentTransactionByApplicationIdPublic02022017NewTemp";
         public int ApplicationFormId = 0;
         public int IsChemical = 1;
         public int IsPlotShedType = 2;
         public int Ishazardious = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSublettingApplicationDetailsReportNew
      public class SPSublettingApplicationDetailsReportNew
      {
         public string SPName = "SPSublettingApplicationDetailsReportNew";
         public int REGIONID = 0;
         public int ACTIONID = 1;
         public int ActionType = 2;
         public int BeforeAfter = 3;
         public int OldApplicationStatusId = 4;
         public int PTOIssueCMD = 5;
         public int StatusId = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSurveyorForwardToAOLeaseApplication
      public class SPSurveyorForwardToAOLeaseApplication
      {
         public string SPName = "SPSurveyorForwardToAOLeaseApplication";
         public int ApplicationFormId = 0;
         public int AssignedRoleId = 1;
         public int ModifiedBy = 2;
         public int BackwardRemark = 3;
         public int Path = 4;
         public int Count = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSubDivisionUpdateRoleWiseByAdmin05012016_OLD
      public class SPSubDivisionUpdateRoleWiseByAdmin05012016_OLD
      {
         public string SPName = "SPSubDivisionUpdateRoleWiseByAdmin05012016_OLD";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int ActionId = 2;
         public int AssignedRoleId = 3;
         public int RemarksCommon = 4;
         public int EstablishingDA = 5;
         public int ExistingPartnersDA = 6;
         public int BuildingPlanDA = 7;
         public int OriginalPlotDA = 8;
         public int OriginalPlotSubDA = 9;
         public int NOCDA = 10;
         public int FeesDA = 11;
         public int DDPlanDA = 12;
         public int SketchDA = 13;
         public int UndertakingDA = 14;
         public int GCDA = 15;
         public int ElectricityDA = 16;
         public int WaterSupplyDA = 17;
         public int EstablishingAM = 18;
         public int ExistingPartnersAM = 19;
         public int BuildingPlanAM = 20;
         public int OriginalPlotAM = 21;
         public int OriginalPlotSubAM = 22;
         public int NOCAM = 23;
         public int FeesAM = 24;
         public int DDPlanAM = 25;
         public int SketchAM = 26;
         public int UndertakingAM = 27;
         public int GCAM = 28;
         public int ElectricityAM = 29;
         public int WaterSupplyAM = 30;
         public int EstablishingRM = 31;
         public int ExistingPartnersRM = 32;
         public int BuildingPlanRM = 33;
         public int OriginalPlotRM = 34;
         public int OriginalPlotSubRM = 35;
         public int NOCRM = 36;
         public int FeesRM = 37;
         public int DDPlanRM = 38;
         public int SketchRM = 39;
         public int UndertakingRM = 40;
         public int GCRM = 41;
         public int ElectricityRM = 42;
         public int WaterSupplyRM = 43;
         public int EstablishingDM = 44;
         public int ExistingPartnersDM = 45;
         public int BuildingPlanDM = 46;
         public int OriginalPlotDM = 47;
         public int OriginalPlotSubDM = 48;
         public int NOCDM = 49;
         public int FeesDM = 50;
         public int DDPlanDM = 51;
         public int SketchDM = 52;
         public int UndertakingDM = 53;
         public int GCDM = 54;
         public int ElectricityDM = 55;
         public int WaterSupplyDM = 56;
         public int EstablishingVCMD = 57;
         public int ExistingPartnersVCMD = 58;
         public int BuildingPlanVCMD = 59;
         public int OriginalPlotVCMD = 60;
         public int OriginalPlotSubVCMD = 61;
         public int NOCVCMD = 62;
         public int FeesVCMD = 63;
         public int DDPlanVCMD = 64;
         public int SketchVCMD = 65;
         public int UndertakingVCMD = 66;
         public int GCVCMD = 67;
         public int ElectricityVCMD = 68;
         public int WaterSupplyVCMD = 69;
         public int RoleId = 70;
         public int AssignActionId = 71;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region GetCRPointBalanceMonthWise
      public class GetCRPointBalanceMonthWise
      {
         public string SPName = "GetCRPointBalanceMonthWise";
         public int EMPCode = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDADeshboardReport
      public class SPDADeshboardReport
      {
         public string SPName = "SPDADeshboardReport";
         public int ApplicationId = 0;
         public int RegionId = 1;
         public int EstateId = 2;
         public int ReportId = 3;
         public int FromDate = 4;
         public int ToDate = 5;
         public int UserId = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateBuildingPlanApprovalApplication
      public class SPInsertUpdateBuildingPlanApprovalApplication
      {
         public string SPName = "SPInsertUpdateBuildingPlanApprovalApplication";
         public int ApplicationFormId = 0;
         public int ApplicationId = 1;
         public int ReferenceNo = 2;
         public int CreatedBy = 3;
         public int IsActive = 4;
         public int Operation = 5;
         public int SEZ = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectROUApplications
      public class SPSelectROUApplications
      {
         public string SPName = "SPSelectROUApplications";
         public int UserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteApplicantCategoryMasterByApplicantCategoryId
      public class SPDeleteApplicantCategoryMasterByApplicantCategoryId
      {
         public string SPName = "SPDeleteApplicantCategoryMasterByApplicantCategoryId";
         public int ApplicantCategoryId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSublettingApplicationDetailsReportFooter
      public class SPSublettingApplicationDetailsReportFooter
      {
         public string SPName = "SPSublettingApplicationDetailsReportFooter";
         public int StatusId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertCRDailyApplicationDetailsForSurrender
      public class SPInsertCRDailyApplicationDetailsForSurrender
      {
         public string SPName = "SPInsertCRDailyApplicationDetailsForSurrender";
         public int ApplicationId = 0;
         public int ApplicationFormId = 1;
         public int AppForwardDate = 2;
         public int AppActualForwardDate = 3;
         public int ActionId = 4;
         public int AssignRoleId = 5;
         public int EstateId = 6;
         public int Remark = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSurveyorForwardToDALeaseApplication
      public class SPSurveyorForwardToDALeaseApplication
      {
         public string SPName = "SPSurveyorForwardToDALeaseApplication";
         public int ApplicationFormId = 0;
         public int AssignedRoleId = 1;
         public int ModifiedBy = 2;
         public int BackwardRemark = 3;
         public int SurveyorDiff = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region Sp_InsertUpdateSubDivisionDocumentTransaction_OLD
      public class Sp_InsertUpdateSubDivisionDocumentTransaction_OLD
      {
         public string SPName = "Sp_InsertUpdateSubDivisionDocumentTransaction_OLD";
         public int Mode = 0;
         public int ApplicationFormId = 1;
         public int Documentmasterid = 2;
         public int AssignedRoleId = 3;
         public int ActionId = 4;
         public int Remark = 5;
         public int UserId = 6;
         public int DocumentOKorNotOK = 7;
         public int DocumentRemarks = 8;
         public int DocumentOKorNotOKAE = 9;
         public int DocumentRemarksAE = 10;
         public int DocumentOKorNotOKDEE = 11;
         public int DocumentRemarksDEE = 12;
         public int DocumentOKorNotOKXEN = 13;
         public int DocumentRemarksXEN = 14;
         public int DocumentOKorNotOKDA = 15;
         public int DocumentRemarksDA = 16;
         public int DocumentOKorNotOKAM = 17;
         public int DocumentRemarksAM = 18;
         public int DocumentOKorNotOKRM = 19;
         public int DocumentRemarksRM = 20;
         public int DocumentOKorNotOKDM = 21;
         public int DocumentRemarksDM = 22;
         public int DocumentOKorNotOKVCMD = 23;
         public int DocumentRemarksVCMD = 24;
         public int Document = 25;
         public int ApplicationFormId2 = 26;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region GetCRPointMonthwiseforallApplication
      public class GetCRPointMonthwiseforallApplication
      {
         public string SPName = "GetCRPointMonthwiseforallApplication";
         public int EMPCode = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDEEDashboard
      public class SPDEEDashboard
      {
         public string SPName = "SPDEEDashboard";
         public int ApplicationId = 0;
         public int RegionId = 1;
         public int EstateId = 2;
         public int FromDate = 3;
         public int ToDate = 4;
         public int UserId = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSaveBuildingPlanApprovalApplicationInspectionDetails
      public class SPSaveBuildingPlanApprovalApplicationInspectionDetails
      {
         public string SPName = "SPSaveBuildingPlanApprovalApplicationInspectionDetails";
         public int ApplicationFormId = 0;
         public int InspectionDatetime = 1;
         public int UserId = 2;
         public int ActionId = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGet2RModuleRejected
      public class SPGet2RModuleRejected
      {
         public string SPName = "SPGet2RModuleRejected";
         public int RegionId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPCheckUniqueRandomReferenceNoForROUModule
      public class SPCheckUniqueRandomReferenceNoForROUModule
      {
         public string SPName = "SPCheckUniqueRandomReferenceNoForROUModule";
         public int ReferenceNo = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSublettingApplicationDetailsReport
      public class SPSublettingApplicationDetailsReport
      {
         public string SPName = "SPSublettingApplicationDetailsReport";
         public int REGIONID = 0;
         public int StatusId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSublettingApplicationDetailsReportFooterNew
      public class SPSublettingApplicationDetailsReportFooterNew
      {
         public string SPName = "SPSublettingApplicationDetailsReportFooterNew";
         public int ACTIONID = 0;
         public int ActionType = 1;
         public int BeforeAfter = 2;
         public int OldApplicationStatusId = 3;
         public int PTOIssueCMD = 4;
         public int StatusId = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateLeaseApplicationDemandDraftByApplicationFormId
      public class SPUpdateLeaseApplicationDemandDraftByApplicationFormId
      {
         public string SPName = "SPUpdateLeaseApplicationDemandDraftByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDADeshboard
      public class SPDADeshboard
      {
         public string SPName = "SPDADeshboard";
         public int ApplicationId = 0;
         public int RegionId = 1;
         public int EstateId = 2;
         public int FromDate = 3;
         public int ToDate = 4;
         public int UserId = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectBuildingPlanApprovalApplication
      public class SPSelectBuildingPlanApprovalApplication
      {
         public string SPName = "SPSelectBuildingPlanApprovalApplication";
         public int AssignedRoleId = 0;
         public int SearchValue = 1;
         public int SearchId = 2;
         public int RegionId = 3;
         public int UserId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetSubdivisionModulePendingWithApplicant
      public class SPGetSubdivisionModulePendingWithApplicant
      {
         public string SPName = "SPGetSubdivisionModulePendingWithApplicant";
         public int RegionId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateSublettingModuleforGeneratePO_OutwardNo
      public class SpUpdateSublettingModuleforGeneratePO_OutwardNo
      {
         public string SPName = "SpUpdateSublettingModuleforGeneratePO_OutwardNo";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectApplicantCategoryMasterByApplicantCategoryType
      public class SPSelectApplicantCategoryMasterByApplicantCategoryType
      {
         public string SPName = "SPSelectApplicantCategoryMasterByApplicantCategoryType";
         public int ApplicantCategoryType = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpUpdateAmalgamationModuleforGeneratePO_OutwardNo
      public class SpUpdateAmalgamationModuleforGeneratePO_OutwardNo
      {
         public string SPName = "SpUpdateAmalgamationModuleforGeneratePO_OutwardNo";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPCRReportSelectEmployeeCodeByUserId
      public class SPCRReportSelectEmployeeCodeByUserId
      {
         public string SPName = "SPCRReportSelectEmployeeCodeByUserId";
         public int UserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPAMDashboardReport
      public class SPAMDashboardReport
      {
         public string SPName = "SPAMDashboardReport";
         public int ApplicationId = 0;
         public int RegionId = 1;
         public int EstateId = 2;
         public int ReportId = 3;
         public int FromDate = 4;
         public int ToDate = 5;
         public int UserId = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectBuildingPlanApprovalApplicationByApplicationFormId
      public class SPSelectBuildingPlanApprovalApplicationByApplicationFormId
      {
         public string SPName = "SPSelectBuildingPlanApprovalApplicationByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectAmalgamationModuleApplicationListDetails
      public class SPSelectAmalgamationModuleApplicationListDetails
      {
         public string SPName = "SPSelectAmalgamationModuleApplicationListDetails";
         public int AssignedRoleId = 0;
         public int SearchValue = 1;
         public int SearchId = 2;
         public int RegionId = 3;
         public int UserId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetROULineTypebyLineTypeId
      public class SPGetROULineTypebyLineTypeId
      {
         public string SPName = "SPGetROULineTypebyLineTypeId";
         public int LineTypeId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPROUApplicationDetailsReportFooter
      public class SPROUApplicationDetailsReportFooter
      {
         public string SPName = "SPROUApplicationDetailsReportFooter";
         public int ACTIONID = 0;
         public int ActionType = 1;
         public int Flag = 2;
         public int ApplicationStatusId = 3;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSubLettingCheckUniqueReferenceNo02022017
      public class SPSubLettingCheckUniqueReferenceNo02022017
      {
         public string SPName = "SPSubLettingCheckUniqueReferenceNo02022017";
         public int ReferenceNo = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectAmalgamationModuleFormalReport
      public class SPSelectAmalgamationModuleFormalReport
      {
         public string SPName = "SPSelectAmalgamationModuleFormalReport";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPRMDashboardReport
      public class SPRMDashboardReport
      {
         public string SPName = "SPRMDashboardReport";
         public int ApplicationId = 0;
         public int RegionId = 1;
         public int EstateId = 2;
         public int ReportId = 3;
         public int FromDate = 4;
         public int ToDate = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectBuildingPlanApprovalApplicationByIFPApplicationId
      public class SPSelectBuildingPlanApprovalApplicationByIFPApplicationId
      {
         public string SPName = "SPSelectBuildingPlanApprovalApplicationByIFPApplicationId";
         public int IFPApplicationId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetSublettingModulePendingWithApplicant
      public class SPGetSublettingModulePendingWithApplicant
      {
         public string SPName = "SPGetSublettingModulePendingWithApplicant";
         public int RegionId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubDivisionModuleApplicationListDetails31082017
      public class SPSelectSubDivisionModuleApplicationListDetails31082017
      {
         public string SPName = "SPSelectSubDivisionModuleApplicationListDetails31082017";
         public int AssignedRoleId = 0;
         public int SearchValue = 1;
         public int SearchId = 2;
         public int RegionId = 3;
         public int UserId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPROUApplicationDetailsReport
      public class SPROUApplicationDetailsReport
      {
         public string SPName = "SPROUApplicationDetailsReport";
         public int REGIONID = 0;
         public int ACTIONID = 1;
         public int ActionType = 2;
         public int Flag = 3;
         public int ApplicationStatusId = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateApplicantCategoryMaster
      public class SPInsertUpdateApplicantCategoryMaster
      {
         public string SPName = "SPInsertUpdateApplicantCategoryMaster";
         public int ApplicantCategoryId = 0;
         public int ApplicantCategoryType = 1;
         public int UserId = 2;
         public int IsActive = 3;
         public int Operation = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSubLettingSelectFillDetailByPropertyIdentificationNo02022017
      public class SPSubLettingSelectFillDetailByPropertyIdentificationNo02022017
      {
         public string SPName = "SPSubLettingSelectFillDetailByPropertyIdentificationNo02022017";
         public int PropertyIdentiNo = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateAmalgamationPaymentPO
      public class SPUpdateAmalgamationPaymentPO
      {
         public string SPName = "SPUpdateAmalgamationPaymentPO";
         public int ApplicationFormid = 0;
         public int ModifiedBy = 1;
         public int PSOPaymentDocument = 2;
         public int Remarks = 3;
         public int NDCAccount = 4;
         public int NDCEngineering = 5;
         public int FSOOutwardNo = 6;
         public int FSODate = 7;
         public int FSODocument = 8;
         public int PSOOutwardNo = 9;
         public int PSODate = 10;
         public int PSODocument = 11;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpApproveDrainageApplicationDemandDraftByDEE
      public class SpApproveDrainageApplicationDemandDraftByDEE
      {
         public string SPName = "SpApproveDrainageApplicationDemandDraftByDEE";
         public int UserId = 0;
         public int ApplicationFormId = 1;
         public int UserRoleId = 2;
         public int CurrentApplicationActionId = 3;
         public int CurrentApplicationStatusId = 4;
         public int AssignedRoleId = 5;
         public int AssignedActionId = 6;
         public int PaymentRemarks = 7;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPAODashboardReport
      public class SPAODashboardReport
      {
         public string SPName = "SPAODashboardReport";
         public int ApplicationId = 0;
         public int RegionId = 1;
         public int EstateId = 2;
         public int ReportId = 3;
         public int FromDate = 4;
         public int ToDate = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectBuildingPlanApprovalApplicationList
      public class SPSelectBuildingPlanApprovalApplicationList
      {
         public string SPName = "SPSelectBuildingPlanApprovalApplicationList";
         public int IFP_PersonId = 0;
         public int IFP_ProjectId = 1;
         public int SearchText = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPGetROUModulePendingWithApplicant
      public class SPGetROUModulePendingWithApplicant
      {
         public string SPName = "SPGetROUModulePendingWithApplicant";
         public int RegionId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectSubdivisionModuleHOFlowUserRoleCount
      public class SPSelectSubdivisionModuleHOFlowUserRoleCount
      {
         public string SPName = "SPSelectSubdivisionModuleHOFlowUserRoleCount";
         public int BranchId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferModuleInvoice
      public class SPSelectTransferModuleInvoice
      {
         public string SPName = "SPSelectTransferModuleInvoice";
         public int ApplicationFormId = 0;
         public int UserId = 1;
         public int TxId = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSublettingModuleSelectDocumentTransactionByApplicationIdPublic02022017New
      public class SPSublettingModuleSelectDocumentTransactionByApplicationIdPublic02022017New
      {
         public string SPName = "SPSublettingModuleSelectDocumentTransactionByApplicationIdPublic02022017New";
         public int ApplicationFormId = 0;
         public int IsChemical = 1;
         public int IsPlotShedType = 2;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPDeleteGeneralApplicationandDrainageApplicationFormByApplicationFormId
      public class SPDeleteGeneralApplicationandDrainageApplicationFormByApplicationFormId
      {
         public string SPName = "SPDeleteGeneralApplicationandDrainageApplicationFormByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPRMDashboard
      public class SPRMDashboard
      {
         public string SPName = "SPRMDashboard";
         public int ApplicationId = 0;
         public int RegionId = 1;
         public int EstateId = 2;
         public int FromDate = 3;
         public int ToDate = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectBuildingPlanApprovalIFPDetials03112017
      public class SPSelectBuildingPlanApprovalIFPDetials03112017
      {
         public string SPName = "SPSelectBuildingPlanApprovalIFPDetials03112017";
         public int ReferenceNo = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateAmalgamtionModuleForApplicationStatus
      public class SPUpdateAmalgamtionModuleForApplicationStatus
      {
         public string SPName = "SPUpdateAmalgamtionModuleForApplicationStatus";
         public int ApplicationFormId = 0;
         public int ApplicationStatusId = 1;
         public int DateOfAmalgamation = 2;
         public int AmalgamationOrderDocument = 3;
         public int DateOfNOCIssued = 4;
         public int NOCDocument = 5;
         public int ModifiedBy = 6;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectDelayTwoRApplication
      public class SPSelectDelayTwoRApplication
      {
         public string SPName = "SPSelectDelayTwoRApplication";
         public int RoleId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferModuleDocumentTransactionByApplicationFormId
      public class SPSelectTransferModuleDocumentTransactionByApplicationFormId
      {
         public string SPName = "SPSelectTransferModuleDocumentTransactionByApplicationFormId";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPCheckUniqueReferenceNoForROUModule
      public class SPCheckUniqueReferenceNoForROUModule
      {
         public string SPName = "SPCheckUniqueReferenceNoForROUModule";
         public int ReferenceNo = 0;
         public int EstateId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectTransferModuleInvoiceByHeader
      public class SPSelectTransferModuleInvoiceByHeader
      {
         public string SPName = "SPSelectTransferModuleInvoiceByHeader";
         public int ApplicationFormId = 0;
         public int TxId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSublettingModuleSelectDocumentTransactionByApplicationIdPublic02022017
      public class SPSublettingModuleSelectDocumentTransactionByApplicationIdPublic02022017
      {
         public string SPName = "SPSublettingModuleSelectDocumentTransactionByApplicationIdPublic02022017";
         public int ApplicationFormId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateAmalgamationFeeDetail
      public class SPUpdateAmalgamationFeeDetail
      {
         public string SPName = "SPUpdateAmalgamationFeeDetail";
         public int Mode = 0;
         public int ApplicationFormId = 1;
         public int AccountDues = 2;
         public int WaterDues = 3;
         public int OtherDues = 4;
         public int DrainageDues = 5;
         public int POPaymentDocument = 6;
         public int Remarks = 7;
         public int ModifiedBy = 8;
         public int GstNumber = 9;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertBuildingPlanApprovalDWGTest
      public class SPInsertBuildingPlanApprovalDWGTest
      {
         public string SPName = "SPInsertBuildingPlanApprovalDWGTest";
         public int DWGdata = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPInsertUpdateAmalgamationQueryCount
      public class SPInsertUpdateAmalgamationQueryCount
      {
         public string SPName = "SPInsertUpdateAmalgamationQueryCount";
         public int ApplicationFormId = 0;
         public int ActionId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SpDrainageApplicationRemarksHistory
      public class SpDrainageApplicationRemarksHistory
      {
         public string SPName = "SpDrainageApplicationRemarksHistory";
         public int ApplicationFormId = 0;
         public int RoleId = 1;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPAMDashboard
      public class SPAMDashboard
      {
         public string SPName = "SPAMDashboard";
         public int ApplicationId = 0;
         public int RegionId = 1;
         public int EstateId = 2;
         public int FromDate = 3;
         public int ToDate = 4;
         public int UserId = 5;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectBuilDingPlanApprovalInspectionListByInspectorUserId
      public class SPSelectBuilDingPlanApprovalInspectionListByInspectorUserId
      {
         public string SPName = "SPSelectBuilDingPlanApprovalInspectionListByInspectorUserId";
         public int InspectorUserId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateROUModuleStatus
      public class SPUpdateROUModuleStatus
      {
         public string SPName = "SPUpdateROUModuleStatus";
         public int ApplicationFormId = 0;
         public int ApplicationStatusId = 1;
         public int DateROUIssued = 2;
         public int ROUOrderDocument = 3;
         public int ModifiedBy = 4;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPSelectROUModuleForReferenceNo
      public class SPSelectROUModuleForReferenceNo
      {
         public string SPName = "SPSelectROUModuleForReferenceNo";
         public int EstateId = 0;
     }
     #endregion

  /// <summary>
  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails
  /// Create By : Parth Bhavsar
  /// Date : 31-May-2018
  /// </summary>
      #region SPUpdateROUApplicationForGSTbyApplicationFormId
      public class SPUpdateROUApplicationForGSTbyApplicationFormId
      {
         public string SPName = "SPUpdateROUApplicationForGSTbyApplicationFormId";
         public int ApplicationFormId = 0;
         public int GST = 1;
         public int NameOfEstateId = 2;
     }
     #endregion
}

