namespace UserModels 
{
  using System;

      public class SPSelectGrievanceApplicationListByUserId
      {
         public String GrievanceSubject  { get; set; }
         public Nullable<Int32> GrievanceApplicationId  { get; set; }
         public String GrievanceNumber  { get; set; }
         public Nullable<Int32> GrievanceStatusId  { get; set; }
         public Nullable<Int32> AssignedRoleId  { get; set; }
         public String GrievanceLanguage  { get; set; }
         public String CommunicationAddress  { get; set; }
         public Nullable<Int32> GrievanceSubjectId  { get; set; }
         public String GrievanceDiscription  { get; set; }
         public String GrievanceDocPath  { get; set; }
         public Nullable<Boolean> IsParticularEstate  { get; set; }
         public Nullable<Int32> EstateId  { get; set; }
         public Nullable<Int32> PropertyTypeId  { get; set; }
         public String PlotShedNo  { get; set; }
         public Nullable<Int32> GrievanceSupportDocumentsId  { get; set; }
         public String RMRemarks  { get; set; }
         public Nullable<DateTime> RMForwardDate  { get; set; }
         public String EXNRemarks  { get; set; }
         public Nullable<DateTime> EXNForwardDate  { get; set; }
         public String HORemarks  { get; set; }
         public Nullable<Int32> CreatedBy  { get; set; }
         public Nullable<DateTime> CreatedOn  { get; set; }
         public Nullable<Int32> ModifiedBy  { get; set; }
         public Nullable<DateTime> ModifiedOn  { get; set; }
         public Nullable<Boolean> IsActive  { get; set; }
         public String GrievanceApplicantName  { get; set; }
         public String ApplicantContactNo  { get; set; }
         public String ApplicantMobileNo  { get; set; }
         public String ApplicantEmailId  { get; set; }
         public String ApplicantPincode  { get; set; }
         public String LandMark  { get; set; }
         public String City  { get; set; }
         public String SuperHORemarks  { get; set; }
         public Nullable<DateTime> SuperHOFrowardDate  { get; set; }
         public Nullable<Int32> GrievanceStatusId1  { get; set; }
         public String GrievanceStatus  { get; set; }
         public Nullable<Int32> CreatedBy1  { get; set; }
         public Nullable<DateTime> CreatedOn1  { get; set; }
         public Nullable<Int32> ModifiedBy1  { get; set; }
         public Nullable<DateTime> ModifiedOn1  { get; set; }
         public Nullable<Boolean> IsActive1  { get; set; }
         public Nullable<Int32> GrievanceSubjectMasterId  { get; set; }
         public String GrievanceSubject1  { get; set; }
         public Nullable<Int32> CreatedBy2  { get; set; }
         public Nullable<DateTime> CreatedOn2  { get; set; }
         public Nullable<Int32> ModifiedBy2  { get; set; }
         public Nullable<DateTime> ModifiedOn2  { get; set; }
         public Nullable<Boolean> IsActive2  { get; set; }
         public Nullable<Boolean> IsReletedEstate  { get; set; }
         public String Department  { get; set; }
         public String GrievanceSubjectGuj  { get; set; }
         public Nullable<Int32> SortOrder  { get; set; }
     }
}

