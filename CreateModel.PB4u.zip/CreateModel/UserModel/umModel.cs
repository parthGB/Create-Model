﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CreateModel.UserModel
{
    public class umModel
    {
        public String Query { get; set; }
        public String DataBaseName { get; set; }
        public String Process { get; set; }
        public String ClassName { get; set; }
        public List<BindDdl> DataBase { get; set; }
        public List<BindDdl> ExeProcess { get; set; }

        public umModel()
        {
            Query = "";
            DataBaseName = "";
            Process = "";
            ClassName = "";
            DataBase = new List<BindDdl>();
            ExeProcess = new List<BindDdl>();
        }
    }

    public class BindDdl
    {
        public string Text { get; set; }
        public string Value { get; set; }

        public BindDdl()
        {
            Text = "";
            Value = "";
        }
    }
}