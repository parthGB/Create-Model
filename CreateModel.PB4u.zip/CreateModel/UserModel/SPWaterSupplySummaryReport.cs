namespace UserModels 
{
  using System;

      public class SPWaterSupplySummaryReport
      {
         public String Region  { get; set; }
         public Nullable<Int32> RegionId  { get; set; }
         public String RegionAddress  { get; set; }
         public Nullable<Int32> Total  { get; set; }
         public Nullable<Int32> Pending30  { get; set; }
         public Nullable<Int32> Pending3145  { get; set; }
         public Nullable<Int32> Pending4660  { get; set; }
         public Nullable<Int32> pending60  { get; set; }
         public Nullable<Int32> Reject  { get; set; }
         public Nullable<Int32> Approved  { get; set; }
         public Nullable<Int32> TotalReceived  { get; set; }
         public Nullable<Int32> Applicant  { get; set; }
     }
}

