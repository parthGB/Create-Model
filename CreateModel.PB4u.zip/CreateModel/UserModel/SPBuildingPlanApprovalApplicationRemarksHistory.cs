namespace UserModels 
{
  using System;

      public class SPBuildingPlanApprovalApplicationRemarksHistory
      {
         public String Role  { get; set; }
         public String Remark  { get; set; }
         public Nullable<DateTime> CreatedOn  { get; set; }
         public String ActionName  { get; set; }
     }
}

