namespace UserModels 
{
  using System;

      public class SPSelectLandApplicationDetailMIS
      {
         public Nullable<Int64> Id  { get; set; }
         public Nullable<Int64> Id1  { get; set; }
         public String DC_NO  { get; set; }
         public String Region_Name  { get; set; }
         public String Estate_Name  { get; set; }
         public String Applicant_Name  { get; set; }
         public String Application_Date  { get; set; }
         public String Address  { get; set; }
         public String Email_Id  { get; set; }
         public String FromDate  { get; set; }
         public String ToDate  { get; set; }
         public String SchemeName  { get; set; }
         public Nullable<Decimal> AllottedArea  { get; set; }
         public Nullable<Decimal> ApplicationArea  { get; set; }
         public String OCAGeneratedDate  { get; set; }
         public String PlotNo  { get; set; }
         public String ConfirmDate  { get; set; }
         public String MeetingNo  { get; set; }
         public String MeetingDate  { get; set; }
         public String PendingScreeningDay  { get; set; }
         public Nullable<Decimal> TotalInvestment  { get; set; }
         public Nullable<Int64> TotalEmployment  { get; set; }
         public String nature  { get; set; }
         public String MFG_ACTIVITY  { get; set; }
         public String Date  { get; set; }
         public String DateName  { get; set; }
         public String FinalRemarks  { get; set; }
     }
}

