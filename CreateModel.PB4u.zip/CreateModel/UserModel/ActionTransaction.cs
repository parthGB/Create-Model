namespace UserModels 
{
  using System;

      public class ActionTransaction
      {
         public Nullable<Int32> ActionId  { get; set; }
         public Nullable<Int32> ApplicationFormId  { get; set; }
         public Nullable<Int32> ApplicationId  { get; set; }
         public String BackwardRemark  { get; set; }
         public Nullable<Int32> CreatedBy  { get; set; }
         public Nullable<DateTime> CreatedOn  { get; set; }
     }
}

