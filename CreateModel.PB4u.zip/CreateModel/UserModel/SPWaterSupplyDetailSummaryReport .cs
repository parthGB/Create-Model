namespace UserModels 
{
  using System;

      public class SPWaterSupplyDetailSummaryReport 
      {
         public String ReferenceNo  { get; set; }
         public Nullable<Int32> ApplicationFormId  { get; set; }
         public Nullable<Boolean> IsSubmitted  { get; set; }
         public String ApplicationDate  { get; set; }
         public String Name  { get; set; }
         public String Region  { get; set; }
         public String Estate  { get; set; }
         public String PlotShedNumber  { get; set; }
         public String PendingUser  { get; set; }
         public Nullable<Int32> SinceLastAction  { get; set; }
     }
}

