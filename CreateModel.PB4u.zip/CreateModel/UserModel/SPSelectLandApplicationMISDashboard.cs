namespace UserModels 
{
  using System;

      public class SPSelectLandApplicationMISDashboard
      {
         public String REGION_CD  { get; set; }
         public String RegionName  { get; set; }
         public String ESTATE_CD  { get; set; }
         public String EstateName  { get; set; }
         public String FromDate  { get; set; }
         public String ToDate  { get; set; }
         public String SchemeName  { get; set; }
         public Nullable<Int32> TotalApplication  { get; set; }
         public Nullable<Int32> TotalConfirmRM  { get; set; }
         public Nullable<Int32> VCMDApprove  { get; set; }
         public Nullable<Int32> CommitteeReject  { get; set; }
         public Nullable<Int32> CommitteeCall  { get; set; }
         public Nullable<Int32> PendingScreening  { get; set; }
         public Nullable<Int32> GenerateOCA  { get; set; }
         public Nullable<Int32> PendingOCA  { get; set; }
         public Nullable<Int32> OCAPaymentReceived  { get; set; }
         public Nullable<Int32> PossessionAdviceGenerated  { get; set; }
         public Nullable<Int32> PossessionReceiptGenerated  { get; set; }
     }
}

