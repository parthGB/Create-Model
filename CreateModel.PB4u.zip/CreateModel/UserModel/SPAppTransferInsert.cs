namespace UserModels 
{
  using System;

      public class SPAppTransferInsert
      {
         public String ColName  { get; set; }
         public Nullable<Int16> ColIndex  { get; set; }
         public String ColDbType  { get; set; }
         public Nullable<Int32> IsOutPut  { get; set; }
         public Nullable<Int32> IsAutoId  { get; set; }
         public Nullable<Int16> Length  { get; set; }
     }
}

