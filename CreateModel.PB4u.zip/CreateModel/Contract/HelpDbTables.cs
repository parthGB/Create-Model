﻿using CreateModel.UserModel;
using GGDTO.DBContracts;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;
namespace GGDTO.Contract
{
    public class HelpDbTables
    {
        SqlHelper objSqlHelper = new SqlHelper();

        #region ExecuteQuery
        public static umModel GetModelDtl()
        {
            umModel obj = new umModel();
            obj.DataBase.Add(new BindDdl { Text = "Land", Value = "Land" });
            obj.DataBase.Add(new BindDdl { Text = "GIDCGG", Value = "GIDCGG" });

            obj.ExeProcess.Add(new BindDdl { Text = "Table", Value = "1" });
            obj.ExeProcess.Add(new BindDdl { Text = "Procedure", Value = "2" });

            return obj;
        }

        public static umModel GetParameterDtl()
        {
            umModel obj = new umModel();
            obj.DataBase.Add(new BindDdl { Text = "Land", Value = "Land" });
            obj.DataBase.Add(new BindDdl { Text = "GIDCGG", Value = "GIDCGG" });

            return obj;
        }
        #endregion

        #region ExecuteQuery
        public DataTable RetuExecuteQueryGG(string SQLQuery)
        {
            DataTable Sql_DtTbl = new DataTable();
            try
            {
                Sql_DtTbl = objSqlHelper.ExecuteQuery_DataSet(SQLQuery).Tables[0];
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return Sql_DtTbl;
        }
        public DataTable RetuExecuteQueryLand(string SQLQuery)
        {
            DataTable Sql_DtTbl = new DataTable();
            try
            {
                Sql_DtTbl = objSqlHelper.ExecuteQueryLand_DataSet(SQLQuery).Tables[0];
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return Sql_DtTbl;
        }
        #endregion
    }
}
