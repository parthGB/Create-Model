﻿using System;
using System.Collections.Generic;
using System.Web;
using System.IO;
using context = System.Web.HttpContext;
using System.Data.SqlClient;
using System.Data;
using CreateModel.UserModel;
using GGDTO.Contract;
/// <summary>
/// Summary description for LogErrorToLogFile
/// </summary>
public class LogErrorToLogFile
{

    #region Properties
    public System.Int64 ErrorId { get; set; }
    public System.String Exception { get; set; }
    public System.String ClassName { get; set; }
    public System.String FunctionName { get; set; }
    #endregion

    public void LogError(Exception ex)
    {
        try
        {
            string path = context.Current.Server.MapPath("~/ErrorLog/");
            // check if directory exists
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            path = path + DateTime.Today.ToString("dd-MMM-yy") + ".log";
            // check if file exist
            if (!File.Exists(path))
            {
                File.Create(path).Dispose();
            }
            // log the error now
            using (StreamWriter writer = File.AppendText(path))
            {
                string error = "\r\nLog written at : " + DateTime.Now.ToString() +
                "\r\nError occured on page : " + context.Current.Request.Url.ToString();
                error += Environment.NewLine;
                error += string.Format("Message: {0}", ex.Message);
                error += Environment.NewLine;
                error += string.Format("StackTrace: {0}", ex.StackTrace);
                error += Environment.NewLine;
                error += string.Format("Source: {0}", ex.Source);
                error += Environment.NewLine;
                error += string.Format("TargetSite: {0}", ex.TargetSite.ToString());
                error += Environment.NewLine;
                writer.WriteLine(error);
                writer.WriteLine("==========================================");
                writer.Flush();
                writer.Close();
            }
        }
        catch
        {
            throw;
        }
    }

    public void LogError(string strError)
    {
        try
        {
            string path = context.Current.Server.MapPath("~/ErrorLog/");
            // check if directory exists
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            path = path + DateTime.Today.ToString("dd-MMM-yy") + ".log";
            // check if file exist
            if (!File.Exists(path))
            {
                File.Create(path).Dispose();
            }
            // log the error now
            using (StreamWriter writer = File.AppendText(path))
            {
                string error = "\r\nLog written at : " + DateTime.Now.ToString() +
                "\r\nError occured on page : " + context.Current.Request.Url.ToString() +
                "\r\n\r\nHere is the actual error :\n" + strError.ToString();
                writer.WriteLine(error);
                writer.WriteLine("==========================================");
                writer.Flush();
                writer.Close();
            }
        }
        catch
        {
            throw;
        }
    }

    public void DbModel(umModel objModel)
    {
        try
        {
            string path = context.Current.Server.MapPath("~/UserModel/");
            string qStr = "";
            HelpDbTables objHelp = new HelpDbTables();
            DataTable dt = new DataTable();

            if (objModel.Process == "1")
            {
                qStr = "Select * from " + objModel.Query + " Where 1=2";
            }
            else if (objModel.Process == "2")
            {
                qStr = objModel.Query;
            }
            else if (objModel.Process == "3")
            {
                qStr = "Get_SPHaseValue '" + objModel.ClassName + "'";
            }

            if (objModel.DataBaseName == "Land")
            {
                dt = objHelp.RetuExecuteQueryLand(qStr);
            }
            else
            {
                dt = objHelp.RetuExecuteQueryGG(qStr);
            }

            // check if directory exists
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }

            path = path + objModel.ClassName + ".cs";
            // check if file exist
            if (!File.Exists(path))
            {
                File.Create(path).Dispose();
            }
            else
            {
                File.Delete(path);
                File.Create(path).Dispose();
            }

            // log the error now
            using (StreamWriter writer = File.AppendText(path))
            {
                string getset = " { get; set; }";
                string spublic = " public";
                string Content = "namespace UserModels ";
                Content += Environment.NewLine;
                Content += "{";
                Content += Environment.NewLine;
                Content += "  using System;";
                Content += Environment.NewLine;
                Content += Environment.NewLine;
                Content += "      public class " + objModel.ClassName;
                Content += Environment.NewLine;
                Content += "      {";
                foreach (DataColumn cols in dt.Columns)
                {
                    Content += Environment.NewLine;
                    Content += string.Format("        {0} {1} {2} {3}", spublic, getType(cols), cols.ColumnName.ToString().Replace(" ", "_"), getset);
                }

                Content += Environment.NewLine;
                Content += "     }";
                Content += Environment.NewLine;
                Content += "}";
                Content += Environment.NewLine;
                writer.WriteLine(Content);
                writer.Flush();
                writer.Close();
            }
        }
        catch
        {
            throw;
        }
    }

    public void DbParameter(umModel objModel)
    {
        try
        {
            string path = context.Current.Server.MapPath("~/UserModel/");
            string qStr = "";
            string qProcedureStr = "";

            HelpDbTables objHelp = new HelpDbTables();
            DataTable dt = new DataTable();
            DataTable dtDbProcedure = new DataTable();

            qStr = "Select Name From Sys.Procedures";

            if (objModel.DataBaseName == "Land")
            {
                dt = objHelp.RetuExecuteQueryLand(qStr);
            }
            else
            {
                dt = objHelp.RetuExecuteQueryGG(qStr);
            }

            // check if directory exists
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }

            path = path + "SPParameter.cs";
            // check if file exist
            if (!File.Exists(path))
            {
                File.Create(path).Dispose();
            }
            else
            {
                File.Delete(path);
                File.Create(path).Dispose();
            }

            // log the error now
            using (StreamWriter writer = File.AppendText(path))
            {
                // string getset = " { get; set; }";
                string spublic = " public";
                string Content = "namespace UserModels ";
                Content += Environment.NewLine;
                Content += "{";
                Content += Environment.NewLine;
                Content += "  using System;";

                foreach (DataRow item in dt.Rows)
                {
                    qProcedureStr = "Get_SPHaseValue '" + item["Name"].ToString() + "'";
                    if (objModel.DataBaseName == "Land")
                    {
                        dtDbProcedure = objHelp.RetuExecuteQueryLand(qProcedureStr);
                    }
                    else
                    {
                        dtDbProcedure = objHelp.RetuExecuteQueryGG(qProcedureStr);
                    }

                    if (dtDbProcedure.Rows.Count > 0)
                    {
                        Content += Environment.NewLine;
                        Content += "  /// <summary>";
                        Content += Environment.NewLine;
                        Content += "  /// Name : SpSelectWaterDrainagePlanApplicationQueryDetails";
                        Content += Environment.NewLine;
                        Content += "  /// Create By : Parth Bhavsar";
                        Content += Environment.NewLine;
                        Content += "  /// Date : "+ DateTime.Now.ToString("dd-MMM-yyyy");
                        Content += Environment.NewLine;
                        Content += "  /// </summary>";
                        Content += Environment.NewLine;
                        Content += "      #region " + item["Name"].ToString();
                        Content += Environment.NewLine;
                        Content += "      public class " + item["Name"].ToString();
                        Content += Environment.NewLine;
                        Content += "      {";
                        Content += Environment.NewLine;
                        Content += string.Format("        {0} {1} {2} {3} {4}", spublic, "string", "SPName", "=", "\"" + item["Name"].ToString() + "\";");
                        foreach (DataRow Parameter in dtDbProcedure.Rows)
                        {
                            Content += Environment.NewLine;
                            Content += string.Format("        {0} {1} {2} {3} {4}", spublic, "int", Parameter["ColName"].ToString().Replace("@", ""), "=", Parameter["ColIndex"].ToString() + ";");
                        }
                        Content += Environment.NewLine;
                        Content += "     }";
                        Content += Environment.NewLine;
                        Content += "     #endregion";
                        Content += Environment.NewLine;
                    }
                }

                Content += "}";
                Content += Environment.NewLine;
                writer.WriteLine(Content);
                writer.Flush();
                writer.Close();
            }
        }
        catch
        {
            throw;
        }
    }



    private string getType(DataColumn col)
    {
        string returnSr = "";
        if (col.AllowDBNull == true && col.DataType.Name != "String" && col.AutoIncrement == false)
        {
            returnSr = "Nullable<" + col.DataType.Name.ToString() + ">";
        }
        else
        {
            returnSr = col.DataType.Name.ToString();
        }
        return returnSr;
    }
}
